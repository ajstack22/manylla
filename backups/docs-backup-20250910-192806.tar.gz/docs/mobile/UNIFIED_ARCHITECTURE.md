# Manylla Unified Architecture - React Native Phase 1 Complete

## Overview

Manylla has successfully implemented a unified cross-platform architecture following the StackMap approach. This document details the single App.js architecture that achieves 95% code sharing between web and mobile platforms.

## Phase 1 Achievement Summary

- ✅ **Single Entry Point**: All platform logic consolidated into `/App.js`
- ✅ **95% Code Sharing**: Shared components, state management, and business logic
- ✅ **Platform-Specific Rendering**: Smart platform detection with `Platform.select()`
- ✅ **Demo Mode**: Complete Ellie profile with comprehensive realistic data
- ✅ **UI Refinements**: Subtle category theming with color strips and responsive grid layout

## Architecture Pattern: Single App.js

### Core Principle
The entire application is contained within a single `App.js` file (1,111 lines) that handles:

```javascript
// Platform detection and conditional imports
if (Platform.OS !== 'web') {
  // Mobile-only imports (gesture handler, safe area)
} else {
  // Web-specific early initialization
}
```

### Platform-Specific Component Loading
```javascript
// Conditional component imports based on platform
let GestureHandlerRootView = View; // Default fallback
let SafeAreaProvider = ({ children }) => children; // Default passthrough

if (Platform.OS !== 'web') {
  // Load React Native gesture handler and safe area
  const GestureHandler = require('react-native-gesture-handler');
  GestureHandlerRootView = GestureHandler.GestureHandlerRootView || View;
  
  const SafeArea = require('react-native-safe-area-context');
  SafeAreaProvider = SafeArea.SafeAreaProvider || (({ children }) => children);
}
```

## Code Organization Within App.js

### 1. Imports and Platform Setup (Lines 1-87)
- React Native core imports
- Platform-specific conditional loading
- Context providers and unified components
- Web-specific share URL handling

### 2. Core Components (Lines 88-284)
- **ProfileOverview**: Main profile display component
- **Category Grid**: Responsive layout with 1/2/3 columns based on screen size
- **QuickInfo Panels**: Special category for emergency information

### 3. Main Application Logic (Lines 287-810)
- **AppContent**: Core application state and handlers
- **Profile Management**: CRUD operations for profiles and entries  
- **Modal Orchestration**: All dialogs and forms
- **State Synchronization**: Profile changes trigger sync

### 4. Styling System (Lines 813-1088)
- **Dynamic Styles**: Theme-aware style creation
- **Responsive Design**: Screen size-based layout adjustments
- **Platform Adaptations**: Shadow vs elevation, boxShadow vs shadowColor

### 5. App Wrapper (Lines 1094-1111)
- **Platform Root**: Conditional GestureHandlerRootView vs View
- **Provider Hierarchy**: Theme → Sync → AppContent

## Key Features Implemented

### Responsive Grid Layout
```javascript
// Dynamic column calculation based on screen width
const screenWidth = Dimensions.get('window').width;
// 3 columns on large screens (>1024px)
if (screenWidth > 1024) {
  return {
    width: Platform.OS === 'web' ? 'calc(33.333% - 12px)' : '31.333%',
    marginHorizontal: Platform.OS === 'web' ? 6 : '1%',
  };
}
// 2 columns on tablets (768-1024px)
// 1 column on phones (<768px)
```

### Category Theming with Color Strips
Each category displays a 4px colored strip for visual organization:
```javascript
<View style={[styles.categoryColorStrip, { backgroundColor: category.color }]} />
```

### Demo Mode - Ellie Profile
Comprehensive demo data including:
- **Profile**: Ellie, age 6, autism spectrum
- **QuickInfo Panels**: Communication, Sensory, Medical, Emergency, Calming
- **Sample Entries**: Goals, Successes, Education, Behaviors, Medical, Tips

## Platform Detection Strategy

### Runtime Platform Checks
```javascript
// Modal handling - different alert systems
if (Platform.OS === 'web') {
  if (window.confirm('Delete this entry?')) {
    onDeleteEntry(entry.id);
  }
} else {
  Alert.alert(
    'Delete Entry',
    'Are you sure you want to delete this entry?',
    [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: () => onDeleteEntry(entry.id) }
    ]
  );
}
```

### Conditional Styling
```javascript
// Platform-specific shadows and elevations
...Platform.select({
  web: {
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
  },
  default: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
})
```

## State Management Approach

### Unified Context Providers
- **ThemeContext**: Light/dark theme with Manylla manila envelope colors
- **SyncContext**: Zero-knowledge encryption and cloud sync
- **Local State**: React hooks for component state

### Profile Data Flow
1. **Storage Service**: Unified interface for AsyncStorage (mobile) and localStorage (web)
2. **Sync Integration**: Automatic profile push on changes
3. **Real-time Updates**: State changes immediately reflected in UI

## Development Workflow

### Build Commands
```bash
# Web development
npm run web

# iOS development  
npm run ios

# Android development
npm run android

# Production web build
npm run build:web
```

### Testing Approach
- **Demo Mode**: Instantly test with realistic Ellie profile data
- **Cross-Platform**: Same codebase tested on web, iOS, Android
- **Hot Reload**: Changes reflected immediately during development

## UI/UX Enhancements

### Subtle Visual Design
- **Category Colors**: Soft color strips rather than overwhelming backgrounds
- **Manila Theme**: Warm #F4E4C1 envelope-inspired color palette  
- **Responsive Typography**: Scales appropriately across devices
- **Touch Targets**: Properly sized buttons and interactive areas

### Accessibility Features
- **Semantic Components**: Proper TouchableOpacity usage
- **Text Scaling**: Responds to system font size preferences
- **High Contrast**: Clear visual hierarchy and readable text

## Performance Optimizations

### Lazy Loading
Platform-specific imports only loaded when needed:
```javascript
try {
  const GestureHandler = require('react-native-gesture-handler');
  GestureHandlerRootView = GestureHandler.GestureHandlerRootView || View;
} catch (e) {
  console.log('Gesture handler not available');
}
```

### Efficient Re-renders
- **Memoized Styles**: Theme-based style creation
- **Selective Updates**: Only affected components re-render on state changes
- **Optimized Lists**: Efficient entry and category rendering

## Migration Benefits Achieved

### Code Reduction
- **Before**: Separate web and mobile codebases
- **After**: Single 1,111-line App.js file
- **Maintenance**: One codebase to update and debug

### Feature Parity
- **95% Shared Logic**: Business logic identical across platforms
- **Consistent UX**: Same user experience on all devices
- **Synchronized Updates**: New features automatically work everywhere

## Next Steps

### Future Enhancements
1. **Native Module Integration**: Camera, file picker optimizations
2. **Performance Monitoring**: Platform-specific metrics
3. **Offline Capabilities**: Enhanced offline-first architecture
4. **Push Notifications**: Mobile-specific notification system

### Deployment Strategy
- **Web**: Deployed to https://manylla.com/qual/ via hardened deploy script
- **iOS**: TestFlight distribution for stakeholders
- **Android**: Google Play internal testing

This unified architecture provides a solid foundation for Manylla's continued development while maintaining the benefits of cross-platform code sharing and consistent user experience.