# Peer Review Process Learnings

## Overview
This document captures learnings from peer reviews, common issues caught, and patterns to watch for in future reviews.

## Common Architecture Violations

### 1. Primary Color Violations
**Issue**: Using wrong primary color #8B7355 instead of #A08670
**Detection**:
```bash
grep -n "#8B7355" src/**/*.js
```
**Impact**: Brand inconsistency, violates design standards
**Fix**: Always use theme constants, never hardcode colors

### 2. Test Files in Production
**Issue**: Creating test HTML files in public/ directory
**Examples**:
- `public/test-demo-data.html`
- `public/test-*.html`

**Detection**:
```bash
find public -name "*.html" -not -name "index.html"
```
**Impact**: Exposes test utilities to production users
**Fix**: Use development-only test tools, never commit test files

### 3. Console.log Pollution
**Issue**: Debug console.logs left in production code
**Detection**:
```bash
grep -r "console\.log" src/ --include="*.js" | grep -v '^\s*//'
```
**Limits**: Maximum 5 allowed in src/
**Fix**: Remove or use proper logging service

## Root Cause Analysis Patterns

### Pattern 1: Component Confusion
**Example**: OnboardingScreen vs OnboardingWizard
- Multiple components with similar names
- Different implementations for same feature
- Comments referring to wrong component

**Red Flags**:
- "Component X should handle this" comments
- Disabled code with `if (false && ...)`
- Duplicate implementations

**Prevention**:
- Document which component is canonical
- Remove or deprecate duplicate implementations
- Clear naming conventions

### Pattern 2: State Management Issues
**Example**: Profile data being overwritten on load
```javascript
// BAD: Overwrites complete data
const updatedProfile = {
  ...storedProfile,
  categories: unifiedCategories  // Loses entries!
};

// GOOD: Preserve complete data
setProfile(storedProfile);
```

**Red Flags**:
- Spread operators that partially override data
- Missing data after page refresh
- Initialization code that runs on every load

## Peer Review Checklist

### Pre-Review Validation
```bash
# Architecture compliance
find src -name "*.tsx" -o -name "*.ts" | wc -l          # Must be 0
find src -name "*.native.*" -o -name "*.web.*" | wc -l  # Must be 0

# Code quality
npm run build:web                                        # Must succeed
npx prettier --check 'src/**/*.js'                      # Must pass
grep -r "@mui/material" src/ | wc -l                    # Goal: 0

# Technical debt
grep -r "console.log" src/ | wc -l                      # Max: 5
grep -r "TODO" src/ | wc -l                             # Max: 20
```

### Asset Verification
**Critical**: Always verify referenced assets exist
```bash
# Example: Profile photo verification
ls -la public/ellie.png
ls -la public/sarah.png
```

### Import Pattern Compliance
Correct order:
1. React imports
2. React Native imports
3. Third-party libraries
4. Context/Hooks
5. Components

### Documentation Requirements
Every PR must update:
- [ ] `docs/RELEASE_NOTES.md` - Version entry
- [ ] `package.json` - Version number
- [ ] JSDoc comments - If API changed
- [ ] Architecture docs - If structure changed

## Review Response Types

### 1. REJECTED - Critical Violations
Use when:
- Architecture standards violated
- Build failures
- Wrong colors/branding
- Test files in production

### 2. CONDITIONAL PASS
Use when:
- Core functionality works
- Minor issues remain
- Technical debt documented
- Clear conditions for deployment

### 3. PASS (Rare)
Use when:
- Perfect compliance
- No issues found
- All tests pass
- Documentation complete

## Deployment Verification

### Pre-Deployment
```bash
# Verify critical assets
ls -la public/*.png public/*.jpg

# Check for test files
find public -name "test-*" -o -name "*-test.*"

# Verify build directory
ls -la web/build/  # Must exist
ls -la build/      # Old, should not deploy
```

### Post-Deployment Testing
1. Clear browser cache
2. Test in incognito mode
3. Verify all features work
4. Check browser console for errors
5. Test on multiple browsers

## Common Mistakes to Catch

### 1. Assuming Libraries Exist
**Wrong**: Using a library without checking
**Right**: Verify in package.json first

### 2. Creating Unnecessary Files
**Wrong**: Creating test/helper files
**Right**: Use existing utilities or inline code

### 3. Incomplete Testing
**Wrong**: "It works on my machine"
**Right**: Provide test output and evidence

### 4. Missing Root Cause
**Wrong**: "Fixed the bug"
**Right**: Explain WHY the bug occurred

### 5. Bypassing Validation
**Wrong**: Disabling checks to pass
**Right**: Fix the actual issues

## Technical Debt Tracking

When accepting with technical debt:
1. Document the specific issue
2. Create prompt pack for future fix
3. Add to TODO list with priority
4. Set timeline for resolution

Example:
```markdown
### TECHNICAL DEBT NOTED
1. **Issue**: Dual onboarding components
   - Components: OnboardingScreen.js, OnboardingWizard.js
   - Action: Consolidate to single component
   - Priority: Medium
   - Timeline: Next sprint
```

## Fury Mode Triggers

Activate maximum scrutiny for:
- Production hotfixes
- Security-related changes
- Architecture modifications
- Payment/billing features
- User data handling

## Review Time Guidelines

- **Critical (01)**: 30-60 minutes thorough review
- **High (02)**: 20-30 minutes detailed review
- **Medium (03)**: 10-20 minutes standard review
- **Low (04)**: 5-10 minutes basic review

## Lessons from Recent Reviews

### September 2025 Demo Data Fix
**Issue**: Missing demo categories in production
**Root Causes**:
1. Profile data overwritten on load
2. Demo creation disabled
3. Component confusion (OnboardingScreen vs OnboardingWizard)

**Lessons**:
- Always verify demo mode end-to-end
- Check for disabled code (`if (false && ...)`)
- Verify asset files exist
- Test with cleared localStorage

**Red Flags Caught**:
- Wrong primary color (#8B7355)
- Test file in public/
- Insufficient testing evidence
- Console.log pollution

## Review Communication

### Being Constructive Yet Firm
- Point to specific line numbers
- Provide exact commands to verify
- Explain impact of violations
- Offer clear fix instructions

### Escalation Path
1. First violation: Educational tone
2. Repeated violation: Firm correction
3. Pattern of violations: Fury mode
4. Consistent issues: Process review

## Continuous Improvement

### Monthly Review Metrics
- Violations caught per review
- Most common issues
- Time to fix violations
- Deployment success rate

### Process Updates
- Update this document with new patterns
- Share learnings in team meetings
- Create automation for common checks
- Build pre-commit hooks for violations

---

*Last Updated: 2025-09-10*
*Version: 1.0*