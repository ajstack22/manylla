# Manylla Mobile Architecture Analysis

## Executive Summary

Manylla is a zero-knowledge encrypted medical information management application built for parents of children with special needs. The current web application is built with React 19, Material-UI v7, and TypeScript, implementing client-side encryption with TweetNaCl.js and cloud-based synchronization. This document provides a comprehensive analysis of the existing architecture to inform the React Native mobile development strategy.

## 1. Architecture Analysis

### 1.1 Directory Structure

```
src/
├── components/          # UI Components
│   ├── Dialogs/        # Unified modal dialogs
│   ├── ErrorBoundary/  # Error handling
│   ├── Forms/          # Form inputs & editors
│   ├── Layout/         # App layout components
│   ├── Loading/        # Loading states
│   ├── Onboarding/     # First-time user experience
│   ├── Profile/        # Profile management
│   ├── Settings/       # Category & settings management
│   ├── Sharing/        # Share functionality
│   ├── Sync/           # Multi-device sync
│   └── Toast/          # Notifications
├── context/            # React Context providers
│   ├── SyncContext.tsx # Sync state management
│   ├── ThemeContext.tsx# Theme management
│   └── ToastContext.tsx# Toast notifications
├── services/           # Business logic
│   ├── storageService.ts
│   └── sync/
│       ├── manyllaEncryptionService.js
│       ├── manyllaMinimalSyncService.js
│       └── conflictResolver.js
├── types/              # TypeScript definitions
├── utils/              # Utility functions
├── hooks/              # Custom React hooks
├── theme/              # Material-UI theme
└── config/             # Configuration files
```

### 1.2 Core Business Logic Components

#### Primary Services
- **manyllaEncryptionService.js**: Core encryption using TweetNaCl, manual UTF-8 encoding for iOS compatibility
- **manyllaMinimalSyncService.js**: Cloud sync with 60-second pull intervals, recovery phrase management
- **storageService.ts**: LocalStorage abstraction layer for data persistence
- **conflictResolver.js**: Last-write-wins conflict resolution strategy

#### State Management
- **Context API**: Primary state management solution
  - SyncContext: Manages sync state, recovery phrases, and sync operations
  - ThemeContext: Handles light/dark theme preferences
  - ToastContext: Manages notification display
- **Local State**: Component-level state for UI interactions
- **No Redux/MobX**: Simplified state management approach

### 1.3 Data Flow Patterns

```
User Action → Component → Context/Service → Encryption → API/Storage
                              ↓
                        State Update
                              ↓
                      Component Re-render
```

Key patterns:
- Unidirectional data flow
- Context-based state updates
- Service layer for business logic
- Encryption at service boundary
- LocalStorage for persistence with cloud sync

### 1.4 Component Hierarchy

```
App.tsx
├── ManyllaThemeProvider
├── SyncProvider
├── ToastProvider
└── Main Content
    ├── Header
    ├── ProfileOverview
    │   └── CategorySection (multiple)
    │       └── Entry cards
    ├── Dialogs (conditionally rendered)
    │   ├── UnifiedAddDialog
    │   ├── ShareDialogOptimized
    │   ├── SyncDialog
    │   └── ProfileCreateDialog
    └── Onboarding (first-time users)
```

## 2. Encryption Implementation Review

### 2.1 Key Technologies
- **TweetNaCl.js**: Primary encryption library
- **XSalsa20-Poly1305**: Symmetric encryption algorithm
- **100,000 iterations**: Key derivation using nacl.hash (matching StackMap)
- **Manual UTF-8**: Custom encoding/decoding for iOS compatibility

### 2.2 Key Derivation Method
```javascript
// 32-character hex recovery phrase generation
const bytes = nacl.randomBytes(16);
const recoveryPhrase = Array.from(bytes)
  .map(b => b.toString(16).padStart(2, '0'))
  .join('');

// Key derivation with nacl.hash iterations
let key = phraseBytes;
for (let i = 0; i < 100000; i++) {
  key = nacl.hash(key);
}
```

### 2.3 iOS UTF-8 Compatibility
Critical finding: Manual UTF-8 encoding/decoding implementation to avoid iOS TextEncoder issues:
- `encodeUTF8()`: Custom UTF-8 encoder at lines 109-130
- `decodeUTF8()`: Custom UTF-8 decoder at lines 135-158
- **Mobile Impact**: Must replicate this exact implementation in React Native

### 2.4 Encryption Touchpoints
1. **Profile Data**: All profile data encrypted before storage/sync
2. **Recovery Phrases**: Device-specific encryption for stored phrases
3. **Share Links**: Temporary encrypted shares with URL-based keys
4. **Sync Payloads**: All cloud sync data encrypted client-side
5. **HMAC Integrity**: Additional integrity verification for medical data

## 3. Data Models & Types

### 3.1 Core Types (from ChildProfile.ts)

```typescript
interface ChildProfile {
  id: string;
  name: string;
  dateOfBirth: Date;
  preferredName?: string;
  pronouns?: string;
  photo?: string;
  entries: Entry[];
  categories: CategoryConfig[];
  quickInfoPanels: QuickInfoConfig[]; // Legacy, being phased out
  createdAt: Date;
  updatedAt: Date;
  themeMode?: 'light' | 'dark';
}

interface Entry {
  id: string;
  category: string;
  title: string;
  description: string; // Supports Markdown/HTML
  date: Date;
  attachments?: string[];
  visibility?: string[]; // ['family', 'medical', 'education', 'all', 'private']
}

interface CategoryConfig {
  id: string;
  name: string;
  displayName: string;
  icon?: string;
  color: string;
  order: number;
  isVisible: boolean;
  isCustom: boolean;
  isQuickInfo?: boolean;
}
```

### 3.2 Data Validation Patterns
- TypeScript interfaces for compile-time checking
- Runtime validation in service layers
- Date handling with native Date objects
- Visibility arrays for granular sharing control

### 3.3 LocalStorage Usage
Current storage keys:
- `manylla_profile`: Main profile data
- `manylla_sync_enabled`: Sync status flag
- `manylla_recovery_phrase`: Encrypted recovery phrase
- `manylla_sync_id`: Device sync identifier
- `secure_*`: Encrypted sensitive data prefix
- `manylla_theme_mode`: Theme preference

## 4. API Integration Points

### 4.1 Endpoint Structure
Base URL configuration supports multiple environments:
- Production: `https://manylla.com/api`
- Staging: `https://manylla.com/qual/api`
- Development: `http://localhost:3000/api`

### 4.2 Core Endpoints
```javascript
sync: {
  push: '/sync_push.php',
  pull: '/sync_pull.php',
  health: '/sync_health.php',
  createInvite: '/sync_create_invite.php',
  validateInvite: '/sync_validate_invite.php'
}
share: {
  create: '/share_create.php',
  access: '/share_access.php'
}
```

### 4.3 Authentication Mechanism
- **No traditional auth**: Zero-knowledge design
- **Recovery phrase**: 32-char hex serves as authentication
- **Sync ID**: Derived from recovery phrase via key derivation
- **Device ID**: Unique identifier per device

### 4.4 Error Handling Patterns
- Try-catch blocks at service boundaries
- Toast notifications for user feedback
- Fallback to local storage on sync failure
- Automatic retry with exponential backoff

## 5. UI Components Analysis

### 5.1 Material-UI Components Used
Core MUI components requiring React Native equivalents:
- **Container/Box**: Layout containers
- **Typography**: Text styling
- **Button/IconButton**: Interactive elements
- **TextField**: Form inputs
- **Dialog/Modal**: Overlays
- **Card/Paper**: Content containers
- **List/ListItem**: Data display
- **Tabs**: Navigation
- **Accordion**: Collapsible sections
- **DatePicker**: Date selection
- **Snackbar**: Toast notifications
- **Skeleton**: Loading states

### 5.2 Custom Components Requiring Port
Critical custom components:
- **MarkdownField**: Rich text editor with markdown support
- **EntryForm**: Complex form with visibility controls
- **CategorySection**: Draggable/sortable category display
- **ShareDialogOptimized**: Multi-step share wizard
- **SyncDialog**: Recovery phrase management
- **ProfileOverview**: Main profile display
- **ProgressiveOnboarding**: Step-by-step wizard

### 5.3 Modal/Dialog Patterns
- **UnifiedAddDialog**: Single dialog for all add operations
- Material-UI Dialog with custom theming
- Mobile-responsive with useMobileDialog hook
- Keyboard avoidance with useMobileKeyboard hook

### 5.4 Responsive Design Breakpoints
```javascript
breakpoints: {
  xs: 0,    // Mobile
  sm: 600,  // Tablet portrait
  md: 900,  // Tablet landscape
  lg: 1200, // Desktop
  xl: 1536  // Large desktop
}
```

## 6. Critical Features to Port

### 6.1 Priority 1 - Core Functionality
1. **Profile Management**
   - Create/edit child profiles
   - Photo upload/display
   - Basic information fields

2. **Entry Management**
   - CRUD operations for entries
   - Category organization
   - Markdown support for descriptions
   - Date tracking

3. **Encryption Services**
   - TweetNaCl implementation
   - Manual UTF-8 encoding
   - Key derivation
   - Secure storage

### 6.2 Priority 2 - Essential Features
4. **Category Management**
   - Default categories
   - Custom category creation
   - Drag-and-drop reordering
   - Visibility toggles

5. **Data Synchronization**
   - Recovery phrase generation
   - Multi-device sync
   - Conflict resolution
   - 60-second pull interval

6. **Offline Support**
   - Local data storage
   - Queue for pending changes
   - Automatic sync on reconnection

### 6.3 Priority 3 - Advanced Features
7. **Sharing System**
   - Temporary encrypted shares
   - QR code generation
   - Share link creation
   - Visibility controls

8. **Theme Support**
   - Light/dark mode toggle
   - Manila envelope theme
   - System preference detection

9. **Onboarding**
   - Progressive disclosure
   - Sample data
   - Feature tutorials

### 6.4 Web-Specific Features Needing Adaptation

**Features requiring mobile alternatives:**
- File upload → Camera/document picker integration
- Print preview → Native print/PDF generation
- Browser localStorage → AsyncStorage
- URL-based sharing → Deep linking + share sheet
- Keyboard shortcuts → Gesture navigation
- Hover states → Long press actions
- Multi-window support → Navigation stack

**Features not applicable to mobile:**
- Browser extensions
- Desktop-specific keyboard navigation
- Right-click context menus
- Browser history manipulation

## 7. Security Considerations

### 7.1 Current Security Implementation
- Zero-knowledge encryption (server never sees plaintext)
- Client-side key derivation
- HMAC integrity verification
- No user accounts or PII storage
- Encrypted recovery phrases

### 7.2 Mobile Security Requirements
- **Keychain/Keystore**: Secure storage for recovery phrases
- **Biometric Auth**: Optional additional security layer
- **Memory Management**: Clear sensitive data from memory
- **Background Security**: Lock app when backgrounded
- **Screenshot Prevention**: Option to prevent screenshots
- **Jailbreak/Root Detection**: Warning for compromised devices

## 8. Performance Characteristics

### 8.1 Current Web Performance
- Initial load: ~2-3 seconds
- Encryption/decryption: <100ms for typical profile
- Sync operations: Throttled to 60-second intervals
- LocalStorage operations: Instant
- Share generation: <500ms

### 8.2 Mobile Performance Targets
- App launch: <2 seconds
- Screen transitions: <300ms
- Encryption operations: <200ms
- Sync operations: Background with minimal battery impact
- Memory usage: <100MB typical
- Battery drain: <2% per hour active use

## 9. Development Practices

### 9.1 Code Quality Standards
- TypeScript for type safety
- ESLint for code consistency
- Component-based architecture
- Service layer abstraction
- Comprehensive error handling

### 9.2 Testing Approach
- React Testing Library for component tests
- Service layer unit tests
- Integration tests for sync operations
- Manual testing for encryption consistency

## 10. Migration Considerations

### 10.1 Data Migration Path
1. Export from web localStorage
2. Encrypt with recovery phrase
3. Transfer via QR code or sync service
4. Import and decrypt on mobile
5. Verify data integrity

### 10.2 Feature Parity Timeline
- Phase 1 (Weeks 1-4): Core profile and entry management
- Phase 2 (Weeks 5-8): Sync and encryption
- Phase 3 (Weeks 9-10): Sharing and advanced features
- Phase 4 (Weeks 11-12): Polish and platform optimization

### 10.3 Backward Compatibility
- Maintain encryption algorithm compatibility
- Support existing recovery phrases
- Preserve data structure
- Enable cross-platform sync

## Conclusion

The Manylla web application demonstrates a well-architected, security-first approach to medical information management. The modular component structure, clear separation of concerns, and robust encryption implementation provide a solid foundation for mobile development. Key challenges for the React Native port will include:

1. Replicating the exact UTF-8 encoding for iOS compatibility
2. Implementing secure storage with Keychain/Keystore
3. Adapting Material-UI patterns to React Native components
4. Maintaining encryption compatibility across platforms
5. Optimizing sync for mobile battery and data usage

The existing codebase's clean architecture and comprehensive type definitions will significantly ease the mobile development process, allowing for substantial code reuse in the service and business logic layers.