# Prompt Pack 3: Android Native Development Master Plan

## Context for LLM
You are creating a comprehensive Android development plan for Manylla using React Native. The app must maintain zero-knowledge encryption while leveraging Android-specific features. You have access to the web codebase and the pre-work analysis from Prompt Pack 1.

## Prompt 1: Android Platform Deep Dive

```
Create a comprehensive Android platform analysis and implementation plan for Manylla:

1. **Android Version & Device Support Matrix**
   - Minimum SDK: API 24 (Android 7.0 Nougat - covers 95%+ devices)
   - Target SDK: API 34 (Android 14)
   - Document features by API level (24-34)
   - Device categories: phones, tablets, foldables, Chromebooks
   - Android TV and Wear OS considerations

2. **Android-Specific Security Implementation**
   - Android Keystore for recovery phrase
   - Biometric API implementation (BiometricPrompt)
   - App signing and verification
   - Network Security Configuration
   - SafetyNet/Play Integrity API
   - Storage encryption and scoped storage

3. **Critical Android Libraries & Dependencies**
   Required Gradle dependencies:
   ```gradle
   - react-native-keychain (Android Keystore wrapper)
   - react-native-biometrics (fingerprint/face)
   - react-native-share (ACTION_SEND intents)
   - react-native-document-picker (SAF integration)
   - WorkManager for background sync
   - Firebase Cloud Messaging (optional)
   ```

4. **Android App Architecture**
   - Multi-window support (Android 7+)
   - App Bundles vs APK
   - Dynamic Feature Modules consideration
   - Content Providers for data sharing
   - Android App Links for deep linking

Create "MANYLLA_ANDROID_PLATFORM_GUIDE.md" with implementation details.
```

## Prompt 2: Android UI/UX Implementation

```
Design Android-native UI patterns following Material Design 3:

1. **Navigation Architecture**
   - Bottom Navigation vs Navigation Drawer
   - Material You (Android 12+) theming
   - Predictive back gesture (Android 14+)
   - Edge-to-edge display support
   - Foldable device continuity

2. **Material Design 3 Compliance**
   - Dynamic color extraction (Android 12+)
   - Material Components usage
   - Motion and animation patterns
   - Elevation and shadows
   - Ripple effects and touch feedback

3. **Android-Specific UI Components**
   - Bottom sheets vs dialogs
   - Snackbars for notifications
   - Floating Action Button patterns
   - Android date/time pickers
   - Chips for tag selection
   - Navigation rail for tablets

4. **Accessibility Features**
   - TalkBack support
   - Switch Access compatibility
   - Magnification gestures
   - Color correction modes
   - Font size preferences
   - RTL language support

Create "MANYLLA_ANDROID_UI_SPECIFICATIONS.md" with Material Design guidelines.
```

## Prompt 3: Android Data & Storage Strategy

```
Implement Android-specific data management:

1. **Android Keystore Implementation**
   ```java
   // Keystore configuration
   - AES encryption for recovery phrase
   - User authentication requirement
   - Validity duration settings
   - Hardware-backed keys (when available)
   ```

2. **Storage Options Analysis**
   - SharedPreferences for settings
   - Room database for structured data
   - Scoped storage for documents
   - MediaStore for images
   - Cache directory management

3. **Background Processing**
   - WorkManager for periodic sync (15-minute minimum)
   - Foreground Service for active sync
   - JobScheduler for older devices
   - Doze mode and App Standby handling
   - Battery optimization exemption request

4. **Android Memory Management**
   - Memory leak prevention (LeakCanary)
   - Bitmap memory optimization
   - Background limits handling
   - Process death recovery
   - Large heap request consideration

Create "MANYLLA_ANDROID_DATA_ARCHITECTURE.md" with code examples.
```

## Prompt 4: Android-Specific Features Implementation

```
Develop Android-exclusive features enhancing Manylla:

1. **Android Widgets**
   - Home screen widgets (resizable)
   - Lock screen widgets (Android 4.2-4.4)
   - Widget preview and configuration
   - Widget update strategies
   - Glance API for Jetpack Compose widgets

2. **Google Assistant Integration**
   - App Actions implementation
   - Voice shortcuts
   - Built-in Intents (BIIs)
   - Slices for quick information display
   - Conversational Actions

3. **Wear OS Companion App**
   - Standalone vs companion app
   - Data synchronization via Data Layer API
   - Complications for watch faces
   - Tiles for quick access
   - Voice input support

4. **Android-Specific Sharing**
   - Direct Share targets
   - Sharesheet customization
   - Nearby Share integration
   - Quick Share (Samsung devices)
   - Intent filters for medical file types

5. **Notification Channels & Features**
   - Notification channels by importance
   - Expandable notifications
   - Action buttons
   - Notification bubbles (Android 11+)
   - Conversation notifications

Create "MANYLLA_ANDROID_FEATURES_ROADMAP.md" with priorities.
```

## Prompt 5: Android Testing & Deployment Strategy

```
Create comprehensive Android testing and deployment plan:

1. **Testing Strategy**
   - JUnit tests for business logic
   - Espresso for UI testing
   - Robolectric for unit tests
   - Firebase Test Lab for device testing
   - Monkey testing for stability

2. **Performance Targets**
   - App startup time (< 2 seconds)
   - APK size optimization (< 30MB base)
   - Frame rate (60 fps target)
   - Network usage optimization
   - Battery usage profiling
   - Memory footprint targets

3. **Google Play Console Setup**
   - App Bundle configuration
   - Play App Signing enrollment
   - Release tracks (internal, alpha, beta, production)
   - Staged rollout strategy
   - Pre-launch reports analysis

4. **Play Store Optimization**
   - Store listing optimization
   - Screenshot requirements (phone, tablet, TV)
   - Feature graphic design
   - Promotional video
   - Localization strategy
   - A/B testing for store listing

5. **Android Manifest Configuration**
   ```xml
   Required permissions:
   - USE_BIOMETRIC
   - CAMERA (optional)
   - WRITE_EXTERNAL_STORAGE (legacy)
   - FOREGROUND_SERVICE
   - RECEIVE_BOOT_COMPLETED
   ```

Create "MANYLLA_ANDROID_DEPLOYMENT_GUIDE.md" with checklist.
```

## Prompt 6: Android Security Hardening

```
Implement Android-specific security measures:

1. **Root Detection**
   - Root detection implementation
   - SafetyNet/Play Integrity API
   - Response strategy (warn vs block)
   - Magisk Hide detection

2. **Anti-Tampering Measures**
   - APK signature verification
   - Code obfuscation with R8/ProGuard
   - Native code protection
   - Anti-debugging techniques
   - String encryption

3. **Secure Communication**
   - Certificate pinning with OkHttp
   - Network Security Config
   - Clear text traffic prevention
   - VPN detection (if needed)

4. **App Security Features**
   - App pinning support
   - Screen recording prevention
   - Screenshot blocking for sensitive screens
   - Clipboard protection
   - Overlay attack prevention

Create "MANYLLA_ANDROID_SECURITY_CHECKLIST.md" with implementation.
```

## Prompt 7: Android Device Compatibility

```
Address Android fragmentation and device-specific issues:

1. **Manufacturer-Specific Adaptations**
   - Samsung One UI optimizations
   - Xiaomi MIUI considerations
   - OnePlus OxygenOS features
   - Pixel-exclusive features
   - Amazon Fire tablet support

2. **Screen Size & Density Support**
   - Phone layouts (compact, medium, expanded)
   - Tablet layouts (7", 10", 12"+)
   - Foldable layouts (folded, unfolded, tabletop)
   - Desktop mode (Samsung DeX, Desktop mode)
   - TV interface (if applicable)

3. **Performance Tiers**
   - Low-end device optimizations (1GB RAM)
   - Mid-range targeting (2-4GB RAM)
   - High-end features (6GB+ RAM)
   - Android Go edition support

4. **Hardware Feature Detection**
   - Fingerprint sensor types
   - NFC availability
   - Camera capabilities
   - Stylus support (S Pen, etc.)

Create "MANYLLA_ANDROID_COMPATIBILITY_MATRIX.md" with test scenarios.
```

## Critical Android Considerations

Point the LLM to these Android-specific issues:

1. **Doze Mode**: Aggressive battery optimization can delay syncs. Need to request battery optimization exemption.

2. **Scoped Storage**: Android 11+ restricts file access. Must use Storage Access Framework.

3. **Background Execution Limits**: Android 8+ restricts background services. Use WorkManager with constraints.

4. **WebView Variations**: Different manufacturers ship different WebView versions. Test thoroughly.

5. **64-bit Requirement**: Google Play requires 64-bit support. Ensure all native libraries comply.

## Key Android Files to Reference

From existing implementation:
- `/android/app/build.gradle` - Build configuration
- `/android/app/src/main/AndroidManifest.xml` - Permissions
- WorkManager setup for background sync
- Keystore integration patterns

## Expected Android Deliverables

The LLM should create:
1. MANYLLA_ANDROID_PLATFORM_GUIDE.md
2. MANYLLA_ANDROID_UI_SPECIFICATIONS.md
3. MANYLLA_ANDROID_DATA_ARCHITECTURE.md
4. MANYLLA_ANDROID_FEATURES_ROADMAP.md
5. MANYLLA_ANDROID_DEPLOYMENT_GUIDE.md
6. MANYLLA_ANDROID_SECURITY_CHECKLIST.md
7. MANYLLA_ANDROID_COMPATIBILITY_MATRIX.md

## Android Success Metrics

- APK size under 30MB (base)
- Cold start under 2 seconds
- 60 FPS scrolling performance
- Battery drain less than 3% per hour
- ANR rate below 0.1%
- Crash rate below 0.5%
- 4.0+ Google Play rating target

## ProGuard/R8 Configuration

```
# Critical rules for Manylla
-keep class com.manylla.** { *; }
-keep class net.sqlcipher.** { *; }
-keep class com.facebook.react.** { *; }
-keepclassmembers class * {
    @com.facebook.react.uimanager.annotations.ReactProp <methods>;
}
```