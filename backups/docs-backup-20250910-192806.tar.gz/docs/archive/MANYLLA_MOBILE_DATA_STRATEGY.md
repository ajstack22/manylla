# Manylla Mobile Data Migration & Sync Strategy

## Executive Summary

This document outlines the comprehensive strategy for data storage, migration, and synchronization in Manylla's React Native mobile applications. The strategy maintains zero-knowledge encryption while optimizing for mobile constraints including battery life, data usage, and offline functionality.

## 1. Current Web Implementation Analysis

### 1.1 LocalStorage Structure
```javascript
// Current web storage keys
localStorage keys:
├── manylla_profile                 // Main profile data (encrypted)
├── manylla_sync_enabled            // Boolean flag
├── manylla_recovery_phrase         // Encrypted recovery phrase
├── manylla_sync_id                 // 32-char sync identifier
├── manylla_theme_mode              // Theme preference
├── manylla_device_key              // Device-specific encryption key
├── secure_manylla_salt             // Encryption salt
├── secure_manylla_recovery         // Backup of recovery phrase
└── secure_manylla_sync_id          // Backup of sync ID
```

### 1.2 Data Size Estimates
```
Average profile size:
- Basic profile info: ~2 KB
- 50 entries: ~100 KB
- 10 categories: ~5 KB
- Photos (base64): ~500 KB per photo
- Total typical profile: ~200-500 KB
- Maximum expected: ~5 MB
```

### 1.3 Current Sync Implementation
- **Pull Interval**: 60 seconds (vs StackMap's 30)
- **Push Strategy**: Immediate on changes
- **Conflict Resolution**: Last-write-wins
- **Recovery Phrase**: 32-char hex string
- **Sync ID**: Derived from recovery phrase

## 2. Mobile Storage Architecture

### 2.1 Storage Layer Design
```
AsyncStorage (Primary)
├── Profile Data
│   ├── Encrypted profile blob
│   ├── Metadata (version, timestamps)
│   └── Quick access cache
├── Sync Configuration
│   ├── Recovery phrase (Keychain/Keystore)
│   ├── Sync settings
│   └── Device registration
├── Offline Queue
│   ├── Pending changes
│   ├── Failed sync attempts
│   └── Retry metadata
└── App Configuration
    ├── Theme preferences
    ├── Notification settings
    └── Feature flags
```

### 2.2 AsyncStorage Schema
```typescript
interface MobileStorageSchema {
  // Profile Data
  'manylla:profile:current': EncryptedProfile;
  'manylla:profile:metadata': ProfileMetadata;
  'manylla:profile:cache': QuickAccessCache;
  
  // Sync Data
  'manylla:sync:config': SyncConfiguration;
  'manylla:sync:lastPull': number;
  'manylla:sync:lastPush': number;
  'manylla:sync:queue': OfflineQueue[];
  
  // App Settings
  'manylla:settings:theme': ThemeMode;
  'manylla:settings:biometric': boolean;
  'manylla:settings:notifications': NotificationPrefs;
  
  // Migration
  'manylla:migration:version': number;
  'manylla:migration:status': MigrationStatus;
}
```

### 2.3 Secure Storage Strategy

**Sensitive Data (Keychain/Keystore):**
```typescript
interface SecureStorage {
  'manylla:secure:recoveryPhrase': string;
  'manylla:secure:deviceKey': string;
  'manylla:secure:salt': string;
  'manylla:secure:biometricKey': string;
}
```

**Implementation:**
```javascript
import * as Keychain from 'react-native-keychain';

class SecureStorageService {
  async storeRecoveryPhrase(phrase: string) {
    await Keychain.setInternetCredentials(
      'manylla.com',
      'recoveryPhrase',
      phrase,
      {
        accessible: Keychain.ACCESSIBLE.WHEN_UNLOCKED_THIS_DEVICE_ONLY,
        authenticatePrompt: 'Access your Manylla data',
        authenticationPromptBiometry: true
      }
    );
  }
}
```

## 3. Data Migration Strategy

### 3.1 Web to Mobile Migration Paths

**Option 1: QR Code Transfer (Recommended)**
```
Web                          Mobile
┌─────────────┐             ┌─────────────┐
│ Export Data │ ──QR Code──>│ Import Data │
│  Encrypt    │             │  Decrypt    │
│  Generate QR│             │  Scan QR    │
└─────────────┘             └─────────────┘
```

**Implementation:**
```javascript
// Web: Generate migration bundle
async function exportForMobile() {
  const profile = await getProfile();
  const recoveryPhrase = await getRecoveryPhrase();
  
  const bundle = {
    version: 1,
    timestamp: Date.now(),
    profile: encryptionService.encryptData(profile),
    checksum: generateChecksum(profile)
  };
  
  // Split into multiple QR codes if needed
  return splitIntoQRCodes(bundle, MAX_QR_SIZE);
}

// Mobile: Import migration bundle
async function importFromWeb(qrCodes: string[]) {
  const bundle = combineQRCodes(qrCodes);
  const { profile, checksum } = bundle;
  
  if (!verifyChecksum(profile, checksum)) {
    throw new Error('Data integrity check failed');
  }
  
  const decrypted = encryptionService.decryptData(profile);
  await saveToAsyncStorage(decrypted);
}
```

**Option 2: Cloud Sync Transfer**
```
1. User enters recovery phrase on mobile
2. Mobile derives sync ID
3. Pull latest data from cloud
4. Decrypt and store locally
```

**Option 3: Deep Link Transfer**
```
1. Web generates temporary share link
2. User opens link on mobile
3. Mobile app intercepts and imports
4. Automatic cleanup after import
```

### 3.2 Migration Validation
```javascript
interface MigrationValidator {
  validateStructure(data: any): boolean;
  validateEncryption(data: EncryptedPayload): boolean;
  validateChecksum(data: any, checksum: string): boolean;
  validateVersion(version: number): boolean;
}

class DataMigrationService {
  async migrate(sourceData: any): Promise<MigrationResult> {
    // Validate source data
    if (!this.validator.validateStructure(sourceData)) {
      throw new Error('Invalid data structure');
    }
    
    // Transform data for mobile
    const transformed = this.transformForMobile(sourceData);
    
    // Store with version tracking
    await AsyncStorage.setItem(
      'manylla:migration:version',
      CURRENT_MIGRATION_VERSION.toString()
    );
    
    return {
      success: true,
      migratedItems: transformed.entries.length,
      timestamp: Date.now()
    };
  }
}
```

### 3.3 App Update Migration
```javascript
// Migration system for app updates
class AppUpdateMigration {
  migrations = {
    '1.0.0': this.migrateFrom1_0_0,
    '1.1.0': this.migrateFrom1_1_0,
    '2.0.0': this.migrateFrom2_0_0
  };
  
  async runMigrations() {
    const currentVersion = await this.getCurrentVersion();
    const migrations = this.getMigrationsToRun(currentVersion);
    
    for (const migration of migrations) {
      await migration();
      await this.markMigrationComplete(migration.version);
    }
  }
}
```

## 4. Sync Architecture for Mobile

### 4.1 Optimized Sync Strategy

**Adaptive Sync Intervals:**
```javascript
class AdaptiveSyncService {
  getNextSyncInterval(): number {
    const factors = {
      battery: getBatteryLevel(),
      network: getNetworkType(),
      lastActivity: getLastUserActivity(),
      dataChanges: getPendingChanges()
    };
    
    if (factors.battery < 20) return 300000; // 5 minutes
    if (factors.network === 'cellular') return 180000; // 3 minutes
    if (factors.dataChanges > 0) return 30000; // 30 seconds
    return 60000; // Default: 1 minute
  }
}
```

### 4.2 Background Sync Implementation

**iOS Background Fetch:**
```swift
// iOS Native Module
func application(_ application: UIApplication,
                performFetchWithCompletionHandler completionHandler:
                @escaping (UIBackgroundFetchResult) -> Void) {
  
  RNBackgroundSync.performSync { result in
    switch result {
    case .newData:
      completionHandler(.newData)
    case .noData:
      completionHandler(.noData)
    case .failed:
      completionHandler(.failed)
    }
  }
}
```

**Android WorkManager:**
```kotlin
// Android Native Module
class SyncWorker(context: Context, params: WorkerParameters) :
    CoroutineWorker(context, params) {
    
  override suspend fun doWork(): Result {
    return try {
      RNBackgroundSync.performSync()
      Result.success()
    } catch (e: Exception) {
      Result.retry()
    }
  }
}
```

### 4.3 Offline Queue Management
```typescript
interface OfflineQueue {
  id: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE';
  entity: 'PROFILE' | 'ENTRY' | 'CATEGORY';
  data: any;
  timestamp: number;
  retryCount: number;
  lastError?: string;
}

class OfflineQueueService {
  private queue: OfflineQueue[] = [];
  
  async addToQueue(action: OfflineQueue) {
    this.queue.push(action);
    await this.persistQueue();
    this.scheduleRetry();
  }
  
  async processQueue() {
    const pending = [...this.queue];
    
    for (const item of pending) {
      try {
        await this.processItem(item);
        this.removeFromQueue(item.id);
      } catch (error) {
        this.handleRetry(item, error);
      }
    }
  }
  
  private handleRetry(item: OfflineQueue, error: Error) {
    item.retryCount++;
    item.lastError = error.message;
    
    if (item.retryCount > MAX_RETRIES) {
      this.moveToDeadLetter(item);
    } else {
      const backoff = Math.pow(2, item.retryCount) * 1000;
      setTimeout(() => this.processItem(item), backoff);
    }
  }
}
```

### 4.4 Conflict Resolution

**Enhanced Last-Write-Wins with Metadata:**
```javascript
class ConflictResolver {
  resolve(local: Profile, remote: Profile): Profile {
    // Compare timestamps
    if (local.updatedAt > remote.updatedAt) {
      return local;
    }
    
    // If timestamps are equal, use device priority
    if (local.updatedAt === remote.updatedAt) {
      return this.devicePriority(local, remote);
    }
    
    // Remote is newer
    return this.mergeWithLocal(remote, local);
  }
  
  private mergeWithLocal(remote: Profile, local: Profile): Profile {
    // Preserve local offline changes if any
    const offlineChanges = this.getOfflineChanges(local);
    
    return {
      ...remote,
      pendingChanges: offlineChanges,
      mergedAt: Date.now()
    };
  }
}
```

## 5. Performance Optimization

### 5.1 Data Compression
```javascript
import pako from 'pako';

class CompressionService {
  compress(data: string): Uint8Array {
    const bytes = new TextEncoder().encode(data);
    return pako.deflate(bytes, { level: 6 });
  }
  
  decompress(compressed: Uint8Array): string {
    const bytes = pako.inflate(compressed);
    return new TextDecoder().decode(bytes);
  }
  
  shouldCompress(data: string): boolean {
    return data.length > 1024; // Compress if > 1KB
  }
}
```

### 5.2 Lazy Loading Strategy
```javascript
class LazyLoadService {
  async loadProfile(): Promise<Profile> {
    // Load minimal data first
    const metadata = await AsyncStorage.getItem('manylla:profile:metadata');
    const basicInfo = await this.loadBasicInfo();
    
    // Return immediately with basic data
    const profile = { ...basicInfo, loading: true };
    
    // Load full data in background
    this.loadFullProfile().then(fullProfile => {
      this.updateProfile(fullProfile);
    });
    
    return profile;
  }
  
  private async loadFullProfile() {
    const [entries, categories, photos] = await Promise.all([
      this.loadEntries(),
      this.loadCategories(),
      this.loadPhotos()
    ]);
    
    return { entries, categories, photos };
  }
}
```

### 5.3 Cache Management
```javascript
class CacheService {
  private cache = new Map();
  private cacheTimestamps = new Map();
  
  async get(key: string, ttl: number = 300000) {
    const cached = this.cache.get(key);
    const timestamp = this.cacheTimestamps.get(key);
    
    if (cached && Date.now() - timestamp < ttl) {
      return cached;
    }
    
    const fresh = await this.fetchFresh(key);
    this.cache.set(key, fresh);
    this.cacheTimestamps.set(key, Date.now());
    
    return fresh;
  }
  
  invalidate(pattern?: string) {
    if (pattern) {
      for (const key of this.cache.keys()) {
        if (key.includes(pattern)) {
          this.cache.delete(key);
          this.cacheTimestamps.delete(key);
        }
      }
    } else {
      this.cache.clear();
      this.cacheTimestamps.clear();
    }
  }
}
```

## 6. Security Considerations

### 6.1 Memory Management
```javascript
class SecureMemoryService {
  private sensitiveData: WeakMap<object, any> = new WeakMap();
  
  store(key: object, value: any) {
    this.sensitiveData.set(key, value);
    
    // Auto-clear after timeout
    setTimeout(() => {
      this.clear(key);
    }, 300000); // 5 minutes
  }
  
  retrieve(key: object): any {
    const value = this.sensitiveData.get(key);
    this.clear(key); // Clear after retrieval
    return value;
  }
  
  clear(key?: object) {
    if (key) {
      this.sensitiveData.delete(key);
    } else {
      this.sensitiveData = new WeakMap();
    }
  }
}
```

### 6.2 Biometric Protection
```javascript
class BiometricProtection {
  async enableBiometric() {
    const biometryType = await Keychain.getSupportedBiometryType();
    
    if (biometryType) {
      await Keychain.setInternetCredentials(
        'manylla.com',
        'biometric_key',
        generateSecureKey(),
        {
          accessible: Keychain.ACCESSIBLE.WHEN_UNLOCKED,
          authenticatePrompt: 'Unlock Manylla',
          authenticationPromptBiometry: true
        }
      );
    }
  }
  
  async verifyBiometric(): Promise<boolean> {
    try {
      const credentials = await Keychain.getInternetCredentials(
        'manylla.com',
        { authenticationPrompt: 'Access your Manylla data' }
      );
      return !!credentials;
    } catch {
      return false;
    }
  }
}
```

### 6.3 Data Encryption at Rest
```javascript
class EncryptionAtRest {
  async encryptForStorage(data: any): Promise<string> {
    const deviceKey = await this.getDeviceKey();
    const encrypted = await encryptionService.encryptWithKey(
      JSON.stringify(data),
      deviceKey
    );
    return encrypted;
  }
  
  async decryptFromStorage(encrypted: string): Promise<any> {
    const deviceKey = await this.getDeviceKey();
    const decrypted = await encryptionService.decryptWithKey(
      encrypted,
      deviceKey
    );
    return JSON.parse(decrypted);
  }
}
```

## 7. Battery & Data Optimization

### 7.1 Battery-Aware Sync
```javascript
class BatteryAwareSync {
  async shouldSync(): Promise<boolean> {
    const battery = await DeviceInfo.getBatteryLevel();
    const isCharging = await DeviceInfo.isCharging();
    
    if (battery < 15 && !isCharging) return false;
    if (battery < 30 && !isCharging) {
      // Reduce sync frequency
      this.setSyncInterval(300000); // 5 minutes
    }
    
    return true;
  }
}
```

### 7.2 Network-Aware Sync
```javascript
class NetworkAwareSync {
  async optimizeForNetwork() {
    const connectionType = await NetInfo.fetch();
    
    switch (connectionType.type) {
      case 'wifi':
        return { syncInterval: 60000, fullSync: true };
      case 'cellular':
        return { syncInterval: 180000, fullSync: false };
      case 'none':
        return { syncInterval: 0, fullSync: false };
    }
  }
}
```

## 8. Migration Timeline

### Phase 1: Foundation (Week 1)
- [ ] Implement AsyncStorage adapter
- [ ] Port encryption service
- [ ] Create secure storage wrapper
- [ ] Basic data models

### Phase 2: Migration Tools (Week 2)
- [ ] QR code generator (web)
- [ ] QR code scanner (mobile)
- [ ] Migration validator
- [ ] Data transformer

### Phase 3: Sync Implementation (Week 3)
- [ ] Offline queue service
- [ ] Background sync setup
- [ ] Conflict resolver
- [ ] Sync status UI

### Phase 4: Optimization (Week 4)
- [ ] Compression implementation
- [ ] Cache service
- [ ] Battery optimization
- [ ] Network optimization

## 9. Testing Strategy

### 9.1 Migration Testing
```javascript
describe('Data Migration', () => {
  test('Web to mobile migration preserves all data', async () => {
    const webData = generateMockWebData();
    const migrated = await migrationService.migrate(webData);
    
    expect(migrated.profile).toEqual(webData.profile);
    expect(migrated.entries.length).toBe(webData.entries.length);
  });
  
  test('Encryption compatibility between platforms', async () => {
    const webEncrypted = webEncryption.encrypt(testData);
    const mobileDecrypted = mobileEncryption.decrypt(webEncrypted);
    
    expect(mobileDecrypted).toEqual(testData);
  });
});
```

### 9.2 Sync Testing
```javascript
describe('Sync Service', () => {
  test('Handles offline queue correctly', async () => {
    await networkService.goOffline();
    await syncService.pushChanges(changes);
    
    expect(offlineQueue.length).toBe(1);
    
    await networkService.goOnline();
    await syncService.processQueue();
    
    expect(offlineQueue.length).toBe(0);
  });
});
```

## 10. Monitoring & Analytics

### 10.1 Key Metrics
```javascript
interface SyncMetrics {
  syncSuccess: number;
  syncFailures: number;
  averageSyncTime: number;
  dataTransferred: number;
  conflictsResolved: number;
  offlineQueueSize: number;
  migrationSuccess: number;
}
```

### 10.2 Error Tracking
```javascript
class SyncErrorTracker {
  trackError(error: Error, context: any) {
    Sentry.captureException(error, {
      tags: {
        component: 'sync',
        action: context.action
      },
      extra: {
        syncId: context.syncId,
        deviceId: context.deviceId,
        timestamp: Date.now()
      }
    });
  }
}
```

## Conclusion

This data strategy ensures:
1. **Seamless Migration**: Multiple paths from web to mobile
2. **Reliable Sync**: Robust offline-first architecture
3. **Optimal Performance**: Battery and data conscious
4. **Security First**: Encryption at every layer
5. **User Experience**: Fast, responsive, and reliable

The strategy prioritizes data integrity and security while optimizing for mobile constraints. The phased implementation approach allows for iterative development and testing, ensuring a smooth transition from web to mobile platforms.