# 🎯 MANYLLA REACT NATIVE COMPONENT MIGRATION DIRECTIVE

## ⚠️ CRITICAL INSTRUCTIONS FOR LLM
**DO NOT DEVIATE FROM THIS PLAN WITHOUT EXPLICIT PERMISSION**

This document contains the COMPLETE migration strategy for the Manylla app from web to React Native. Follow these instructions EXACTLY. Do not create unnecessary files. Do not change the architecture. Do not make assumptions.

## 🏗️ ARCHITECTURE RULES (MANDATORY)

### Rule 1: Component Separation Strategy
- **UI-Heavy Components**: Material-UI (web) vs React Native (mobile) = SEPARATE FILES
- **Logic Components**: Shared with Platform.OS checks = SINGLE FILE
- **Index Files**: Use Platform.OS to select correct version

### Rule 2: File Naming Convention
```javascript
// For UI-heavy components requiring separation:
ComponentName.tsx         // Web version (Material-UI)
ComponentName.native.tsx  // Mobile version (React Native)
index.tsx                // Platform selector

// index.tsx MUST look like this:
import { Platform } from 'react-native';

export const ComponentName = Platform.OS === 'web'
  ? require('./ComponentName.tsx').ComponentName
  : require('./ComponentName.native.tsx').ComponentName;
```

### Rule 3: When to Use Platform.OS in Single File
ONLY use Platform.OS within a single file when:
- The component has minimal UI differences
- Only styling or small behavioral changes needed
- The core structure remains the same

## 📁 CURRENT PROJECT STATE

### ✅ COMPLETED COMPONENTS (DO NOT MODIFY)
These components are DONE and working. Do NOT recreate them:

1. **UnifiedAddDialog** (.tsx and .native.tsx) ✅
2. **Header** (.tsx and .native.tsx) ✅
3. **OnboardingWizard** (.tsx and .native.tsx) ✅
4. **OnboardingWrapper** (.native.tsx only - mobile specific) ✅
5. **CategorySection** (.tsx and .native.tsx) ✅
6. **ProfileCard** (.native.tsx only - mobile specific) ✅
7. **ProfileOverview** (.tsx and .native.js) ✅
8. **UnifiedCategoryManager** (.tsx and .native.tsx) ✅

### 🚨 COMPONENTS NEEDING MIGRATION

## 📋 CATEGORY A: CREATE SEPARATE .native.tsx FILES

These components use Material-UI heavily and MUST have separate native versions. Create ComponentName.native.tsx for each:

### 1. SyncDialog.native.tsx
**Reference**: `/src/components/Sync/SyncDialog.tsx`
**Required Implementation**:
```typescript
import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  ActivityIndicator,
  Alert,
  Clipboard,
  StyleSheet,
  Platform
} from 'react-native';
import { useSync } from '../../context/SyncContext';

// Key features to implement:
// - Modal presentation with SafeAreaView
// - Recovery phrase display with monospace font
// - Copy to clipboard functionality
// - Enable/disable sync with loading states
// - Join sync with phrase input
// - Error handling with Alert.alert
```

### 2. ShareDialogOptimized.native.tsx
**Reference**: `/src/components/Sharing/ShareDialogOptimized.tsx`
**Required Implementation**:
```typescript
import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Share,
  StyleSheet,
  SafeAreaView,
  Clipboard
} from 'react-native';
import { ChildProfile } from '../../types/ChildProfile';

// Key features to implement:
// - Use native Share API for sharing
// - Generate share links with encryption
// - Expiration time selector (Picker or buttons)
// - Category selection with checkboxes
// - Preview of what will be shared
// - Copy link functionality
```

### 3. ProfileEditDialog.native.tsx
**Reference**: `/src/components/Profile/ProfileEditDialog.tsx`
**Required Implementation**:
```typescript
import React, { useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  ScrollView,
  SafeAreaView,
  StyleSheet
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';
import DateTimePicker from '@react-native-community/datetimepicker';

// Key features to implement:
// - Image picker for profile photo
// - Text inputs for name, preferred name, pronouns
// - Date picker for birth date
// - Age calculation display
// - Save/Cancel buttons
// - Form validation
```

### 4. ProfileCreateDialog.native.tsx
**Reference**: `/src/components/Profile/ProfileCreateDialog.tsx`
**Required Implementation**:
```typescript
// Similar to ProfileEditDialog but for new profiles
// Include:
// - Step-by-step wizard approach
// - Required field validation
// - Default category selection
// - Option to skip optional fields
```

### 5. EntryForm.native.tsx
**Reference**: `/src/components/Dialogs/EntryForm.tsx`
**Required Implementation**:
```typescript
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  ScrollView,
  TouchableOpacity,
  Switch,
  StyleSheet
} from 'react-native';

// Key features to implement:
// - Title and description inputs
// - Category selector (Picker)
// - Privacy level toggle
// - Tags input (comma-separated)
// - Save/Cancel actions
// - Form validation
```

### 6. CategoryManager.native.tsx
**Reference**: `/src/components/Settings/CategoryManager.tsx`
**Required Implementation**:
```typescript
import React from 'react';
import {
  FlatList,
  View,
  Text,
  TouchableOpacity,
  Switch,
  StyleSheet
} from 'react-native';

// Key features to implement:
// - FlatList of categories
// - Enable/disable toggles
// - Add custom category
// - Delete category (with confirmation)
// - Reorder categories (if not using UnifiedCategoryManager)
```

### 7. QuickInfoManager.native.tsx
**Reference**: `/src/components/Settings/QuickInfoManager.tsx`
**Required Implementation**:
```typescript
// Similar to CategoryManager but for quick info items
// Include:
// - List of quick info items
// - Add/edit/delete functionality
// - Reorder items
// - Icon selection for items
```

## 📋 CATEGORY B: MODIFY EXISTING FILES WITH Platform.OS

These components need Platform.OS checks added to existing files. DO NOT create separate files:

### 1. ErrorBoundary.tsx
**Changes Required**:
```typescript
// Add at top of file:
import { Platform, View, Text } from 'react-native';

// In render method:
if (Platform.OS !== 'web') {
  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text>Something went wrong</Text>
      <TouchableOpacity onPress={() => this.setState({ hasError: false })}>
        <Text>Try Again</Text>
      </TouchableOpacity>
    </View>
  );
}
// ... existing Material-UI code for web
```

### 2. LoadingSpinner.tsx
**Changes Required**:
```typescript
import { Platform, ActivityIndicator } from 'react-native';

// In component:
if (Platform.OS !== 'web') {
  return <ActivityIndicator size="large" color="#8B7355" />;
}
// ... existing CircularProgress for web
```

### 3. LoadingOverlay.tsx
**Changes Required**:
```typescript
import { Platform, View, ActivityIndicator, StyleSheet } from 'react-native';

// In component:
if (Platform.OS !== 'web') {
  return (
    <View style={[StyleSheet.absoluteFillObject, styles.overlay]}>
      <ActivityIndicator size="large" color="#8B7355" />
    </View>
  );
}
// ... existing Material-UI overlay for web
```

### 4. ThemedToast.tsx
**Changes Required**:
```typescript
import { Platform } from 'react-native';
// For mobile, use react-native-toast-message
import Toast from 'react-native-toast-message';

// In show method:
if (Platform.OS !== 'web') {
  Toast.show({
    type: severity,
    text1: message,
    position: 'bottom',
  });
  return;
}
// ... existing web toast code
```

### 5. HighlightedText.tsx
**Changes Required**:
```typescript
import { Platform, Text } from 'react-native';

// Simple text highlighting with Platform.OS check for styling
if (Platform.OS !== 'web') {
  return (
    <Text style={{ backgroundColor: '#FFEB3B' }}>
      {text}
    </Text>
  );
}
// ... existing Material-UI highlighted text
```

## 📋 CATEGORY C: PLATFORM-SPECIFIC FEATURES

These need completely different implementations per platform:

### 1. PrintPreview.native.tsx
**Implementation**:
```typescript
import RNPrint from 'react-native-print';

// Generate HTML for print
// Use RNPrint.print({ html: generatedHtml })
// Or share as PDF using Share API
```

### 2. QRCodeModal.native.tsx
**Implementation**:
```typescript
import QRCode from 'react-native-qrcode-svg';

// Display QR code using react-native-qrcode-svg
// Modal wrapper for display
// Share QR code as image option
```

### 3. SharedProfileView.native.tsx & SharedView.native.tsx
**Implementation**:
```typescript
// Handle deep links and navigation
// Parse share tokens from navigation params
// Display shared profile data
// No web routing - use React Navigation
```

## 📋 CATEGORY D: RICH TEXT COMPONENTS

These need special text editing implementations:

### 1. SmartTextInput.native.tsx
**Implementation**:
```typescript
import { TextInput, View, FlatList } from 'react-native';

// Custom keyboard toolbar for suggestions
// Autocomplete dropdown
// Text analysis for smart suggestions
// Integrate with AI service if available
```

### 2. MarkdownField.native.tsx
**Implementation**:
```typescript
import MarkdownEditor from 'react-native-markdown-editor';

// Markdown toolbar (bold, italic, etc.)
// Preview mode toggle
// Live preview split view
```

### 3. MarkdownRenderer.native.tsx
**Implementation**:
```typescript
import Markdown from 'react-native-markdown-display';

// Render markdown content
// Custom styling for markdown elements
// Handle links and images
```

### 4. RichTextInput.native.tsx
**Implementation**:
```typescript
import {RichEditor, RichToolbar} from 'react-native-pell-rich-editor';

// Full rich text editing
// Toolbar with formatting options
// HTML output
```

### 5. HtmlRenderer.native.tsx
**Implementation**:
```typescript
import RenderHtml from 'react-native-render-html';

// Render HTML content safely
// Custom renderers for specific tags
// Handle images and links
```

## 🛠️ IMPLEMENTATION CHECKLIST

### Phase 1: Critical Features (START HERE)
- [ ] Create SyncDialog.native.tsx
- [ ] Create ShareDialogOptimized.native.tsx
- [ ] Create ProfileEditDialog.native.tsx
- [ ] Create ProfileCreateDialog.native.tsx
- [ ] Update Sync/index.tsx with Platform selector
- [ ] Update Sharing/index.tsx with Platform selector
- [ ] Update Profile/index.tsx to include new selectors

### Phase 2: Data Entry
- [ ] Create EntryForm.native.tsx
- [ ] Create SmartTextInput.native.tsx
- [ ] Create MarkdownField.native.tsx
- [ ] Update respective index.tsx files

### Phase 3: Management
- [ ] Create CategoryManager.native.tsx
- [ ] Create QuickInfoManager.native.tsx
- [ ] Update Settings/index.tsx

### Phase 4: Viewing & Sharing
- [ ] Create SharedProfileView.native.tsx
- [ ] Create SharedView.native.tsx
- [ ] Create QRCodeModal.native.tsx
- [ ] Create PrintPreview.native.tsx
- [ ] Update respective index.tsx files

### Phase 5: Utilities
- [ ] Modify LoadingSpinner.tsx with Platform.OS
- [ ] Modify LoadingOverlay.tsx with Platform.OS
- [ ] Modify ThemedToast.tsx with Platform.OS
- [ ] Modify ErrorBoundary.tsx with Platform.OS
- [ ] Modify HighlightedText.tsx with Platform.OS
- [ ] Create MarkdownRenderer.native.tsx
- [ ] Create HtmlRenderer.native.tsx
- [ ] Create RichTextInput.native.tsx
- [ ] Update respective index.tsx files

## 📦 DEPENDENCIES TO INSTALL

Run these commands BEFORE starting implementation:

```bash
cd /Users/adamstack/manylla

# Install all required dependencies
npm install --legacy-peer-deps \
  react-native-qrcode-svg \
  react-native-svg \
  react-native-markdown-display \
  react-native-markdown-editor \
  react-native-render-html \
  react-native-toast-message \
  react-native-share \
  react-native-print \
  react-native-pell-rich-editor \
  react-native-webview

# Install iOS pods
cd ios && pod install && cd ..
```

## 🎨 STYLING CONSTANTS

Use these colors and styles consistently across ALL native components:

```typescript
const manyllaColors = {
  primary: '#8B7355',        // Brown (manila envelope)
  background: '#F4E4C1',     // Light manila
  surface: '#FFFFFF',        
  text: '#333333',
  textSecondary: '#666666',
  border: '#E0E0E0',
  error: '#D32F2F',
  success: '#4CAF50',
  warning: '#FF9800',
  info: '#2196F3'
};

const commonStyles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  primaryButton: {
    backgroundColor: '#8B7355',
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: 'center',
  },
  primaryButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  input: {
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#E0E0E0',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 12,
    fontSize: 16,
    color: '#333',
  },
});
```

## ⚠️ CRITICAL RULES - DO NOT VIOLATE

1. **DO NOT** create .native.tsx files for components in Category B
2. **DO NOT** modify completed components (Category ✅)
3. **DO NOT** use Material-UI imports in .native.tsx files
4. **DO NOT** use React Native imports in .tsx files (except Platform)
5. **DO NOT** create new architectures or patterns
6. **DO NOT** skip creating index.tsx files with Platform selectors
7. **DO NOT** use different color schemes or styling patterns
8. **DO NOT** add emojis unless they already exist in the web version
9. **DO NOT** create files that aren't listed in this document
10. **DO NOT** deviate from the component structure specified

## 🚀 EXECUTION ORDER

1. **START**: Install all dependencies first
2. **PHASE 1**: Complete all Critical Features
3. **TEST**: Ensure app builds and runs
4. **PHASE 2**: Complete Data Entry components
5. **TEST**: Verify data entry works
6. **CONTINUE**: Through remaining phases in order
7. **FINAL TEST**: Full app functionality verification

## 📝 NOTES FOR IMPLEMENTATION

- Each .native.tsx file should mirror the functionality of its .tsx counterpart
- Use React Native's built-in components (Modal, ScrollView, FlatList, etc.)
- Maintain the same props interface for components
- Keep the same state management approach
- Preserve all business logic
- Only UI implementation should differ

## 🏁 DEFINITION OF DONE

A component migration is complete when:
- [ ] Native version exists (if Category A, C, or D)
- [ ] Platform.OS checks added (if Category B)
- [ ] Index.tsx updated with Platform selector
- [ ] Component renders without errors
- [ ] All functionality from web version works
- [ ] Styling matches Manylla design system
- [ ] TypeScript has no errors
- [ ] Component integrates with existing app flow

---

**THIS IS YOUR COMPLETE INSTRUCTION SET. EXECUTE PHASES IN ORDER. DO NOT DEVIATE.**

When you begin, start with:
1. Installing dependencies
2. Creating SyncDialog.native.tsx
3. Continue through Phase 1 systematically

Report progress after each component completion.