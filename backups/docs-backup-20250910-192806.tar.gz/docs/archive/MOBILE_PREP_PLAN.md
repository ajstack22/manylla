# Mobile App Preparation Plan ("Phase 3.5")
*Streamlined 2-day plan to prepare for iOS/Android app development*

## Overview
This plan focuses ONLY on what's actually needed for mobile apps, avoiding enterprise-level features that won't benefit a single-user medical records app.

## Timeline
- **Duration**: 2 days (16 hours)
- **Start Date**: [When ready]
- **Goal**: API-ready for React Native development

## Day 1: API Documentation & Easy Device Pairing

### Task 1.1: Create OpenAPI Documentation (4 hours)
**Purpose**: Mobile developers need clear API specs

#### Implementation
1. Document existing 5 endpoints in OpenAPI 3.0 format
2. Create `api-docs.yaml` with full specifications
3. Include example requests/responses
4. Add authentication flow documentation

#### Deliverables
```yaml
# api-docs.yaml structure
openapi: 3.0.0
info:
  title: Manylla API
  version: 1.0.0
paths:
  /api/sync/push.php:
    post:
      summary: Push encrypted data
      # ... full spec
  /api/sync/pull.php:
    post:
      summary: Pull encrypted data
      # ... etc
```

### Task 1.2: Simple Invite Codes (4 hours)
**Purpose**: Nobody wants to type 32 characters on a phone

#### Current Problem
- Recovery phrase: `8a7f3d2e9b1c4a6d5f8e2b9c1d4a7f3e`
- Typing this on mobile = frustration

#### Simple Solution
```php
// create_invite.php
function generateInviteCode() {
    // 8 characters, easy to type
    // Format: XXXX-XXXX (like: A7B2-M9K4)
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // No confusing chars
    $code = substr(str_shuffle($chars), 0, 4) . '-' . 
            substr(str_shuffle($chars), 0, 4);
    return $code;
}

// Store temporarily with recovery_phrase
// Expires in 24 hours
// Single use only
```

#### Database Addition
```sql
CREATE TABLE invite_codes (
    code VARCHAR(9) PRIMARY KEY,
    recovery_phrase VARCHAR(32),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_at TIMESTAMP NULL,
    expires_at TIMESTAMP
);
```

## Day 2: Mobile Optimizations

### Task 2.1: Add Gzip Compression (2 hours)
**Purpose**: Reduce cellular data usage

#### Implementation
```php
// In sync endpoints
if (strlen($response) > 1000) {
    header('Content-Encoding: gzip');
    $response = gzencode($response, 6);
}
```

#### API Version Headers
```php
// Add to all endpoints
header('API-Version: 1.0.0');
header('Accept-Version: 1.0.0');
```

### Task 2.2: Basic Device Tracking (3 hours)
**Purpose**: Debug sync issues, identify platforms

#### Simple Implementation
```php
// Add to sync_data table
ALTER TABLE sync_data ADD COLUMN device_info VARCHAR(255);
ALTER TABLE sync_data ADD COLUMN last_sync_platform VARCHAR(50);

// Capture from User-Agent
$device_info = $_SERVER['HTTP_USER_AGENT'];
$platform = detectPlatform($device_info); // 'ios', 'android', 'web'
```

### Task 2.3: Rate Limiting (3 hours)
**Purpose**: Prevent API abuse when public

#### Simple Redis-free Solution
```php
// Using database for rate limiting
CREATE TABLE api_rate_limit (
    ip_address VARCHAR(45),
    endpoint VARCHAR(100),
    request_count INT DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (ip_address, endpoint)
);

// Check before processing
function checkRateLimit($ip, $endpoint, $limit = 60) {
    // 60 requests per minute per endpoint
    // Clean implementation without Redis
}
```

## What We're NOT Doing

### ❌ Skip These Phase 4 Items
1. **Complex Conflict Resolution** - Last-write-wins is perfect
2. **Audit Log Encryption** - Basic logging is enough
3. **Multi-version Schema Migration** - Handle in app updates
4. **Advanced Invite Management** - Keep it simple

### ❌ Avoid Premature Optimization
- WebSocket connections (polling works fine)
- GraphQL API (REST is perfect)
- Microservices (monolith is appropriate)
- Kubernetes (shared hosting is fine)

## Mobile App Considerations

### React Native Integration Points
```javascript
// Mobile app will need:
1. Biometric authentication (FaceID/TouchID)
   - Store recovery_phrase in device keychain
   
2. Offline-first sync queue
   - Queue changes when offline
   - Sync when connected
   
3. Push notifications (future)
   - Optional endpoint for tokens
   
4. Background sync (iOS/Android)
   - Handle in React Native
```

### API Response Format
Keep consistent JSON structure:
```json
{
  "success": true,
  "data": { /* encrypted payload */ },
  "version": "1.0.0",
  "timestamp": 1234567890
}
```

## Testing Checklist

### Before Mobile Development
- [ ] API documentation complete and accurate
- [ ] Invite codes work (test with curl)
- [ ] Compression reduces payload size
- [ ] Rate limiting prevents abuse
- [ ] Version headers present
- [ ] CORS configured for mobile

### Quick Test Commands
```bash
# Test invite code
curl -X POST https://manylla.com/qual/api/create_invite.php \
  -H "Content-Type: application/json" \
  -d '{"recovery_phrase":"[phrase]"}'

# Test compression
curl -H "Accept-Encoding: gzip" \
  https://manylla.com/qual/api/sync/pull.php \
  --compressed

# Check version header
curl -I https://manylla.com/qual/api/sync/pull.php | grep API-Version
```

## Implementation Order

### Priority 1 (Do First)
1. **API Documentation** - Mobile devs need this
2. **Simple Invite Codes** - Critical for UX

### Priority 2 (Do Second)  
3. **Version Headers** - For app updates
4. **Device Tracking** - For debugging

### Priority 3 (If Time)
5. **Compression** - Nice to have
6. **Rate Limiting** - Before public launch

## Success Metrics

### Must Have for Mobile Launch
- ✅ API docs mobile devs can follow
- ✅ Easy device pairing (< 30 seconds)
- ✅ Version strategy defined
- ✅ Platform detection working

### Nice to Have
- ✅ Reduced data usage
- ✅ API abuse protection
- ✅ Device-specific debugging

## Migration Path

### From Current to Mobile-Ready
1. No breaking changes to existing APIs
2. Invite codes supplement (don't replace) recovery phrases
3. Version 1.0.0 = current API structure
4. Mobile apps use same encryption (TweetNaCl)

### Database Changes (Non-Breaking)
```sql
-- Run these on qual first, then prod
ALTER TABLE sync_data ADD COLUMN device_info VARCHAR(255);
ALTER TABLE sync_data ADD COLUMN api_version VARCHAR(10) DEFAULT '1.0.0';

CREATE TABLE IF NOT EXISTS invite_codes (
    code VARCHAR(9) PRIMARY KEY,
    recovery_phrase VARCHAR(32),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_at TIMESTAMP NULL,
    expires_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS api_rate_limit (
    ip_address VARCHAR(45),
    endpoint VARCHAR(100),
    request_count INT DEFAULT 1,
    window_start TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (ip_address, endpoint)
);
```

## Next Steps After Mobile Prep

### Phase 5: React Native Development
1. Create React Native project
2. Implement biometric auth
3. Build offline sync queue
4. Test on real devices
5. Submit to app stores

### Not Needed Until Later
- Push notifications (Phase 6)
- Multi-profile support (Phase 7)
- Provider portal (Phase 8)

## Cost-Benefit Summary

### Time Investment
- **2 days** for mobile prep (vs 5 days for full Phase 4)
- **Saves 3 days** of unnecessary work
- **ROI**: High - directly enables mobile apps

### What You Get
- Mobile-ready APIs in 48 hours
- Easy device pairing for families
- Professional API documentation
- Basic monitoring and protection

### What You Avoid
- Over-engineered conflict resolution
- Complex audit systems
- Unnecessary compression overhead
- Feature creep

## Final Notes

This plan gets you mobile-ready without gold-plating. The focus is on what actually improves the user experience for parents managing their child's medical information on phones.

Remember: Your app's value is in organizing medical information, not in having enterprise-grade infrastructure. Keep it simple, secure, and focused on the core mission.

---

*Created: September 7, 2025*
*Estimated Effort: 16 hours*
*Actual Value: HIGH - Directly enables mobile apps*