# Manylla iOS Development Status & Roadmap

## ✅ Completed Work

### 1. Project Setup & Structure
- ✅ Unified codebase at `/Users/adamstack/manylla/`
- ✅ React Native 0.81.1 with React 19.1.0
- ✅ iOS and Android folders integrated
- ✅ Shared business logic with web app
- ✅ Package.json merged for both platforms
- ✅ Git repository connected to GitHub

### 2. Build Configuration
- ✅ Podfile configured with New Architecture disabled
- ✅ React Native Reanimated build errors fixed
- ✅ All dependencies installed with --legacy-peer-deps
- ✅ CocoaPods successfully installed (84 dependencies)
- ✅ Metro bundler running from unified folder
- ✅ babel-plugin-module-resolver configured for path aliases

### 3. Core Infrastructure
- ✅ Navigation setup (React Navigation)
- ✅ Context providers created (Theme, Profile, Sync)
- ✅ Storage service adapted for React Native (AsyncStorage)
- ✅ Basic app structure running on iOS simulator
- ✅ .gitignore updated for unified structure

### 4. Services Already Available
- ✅ Encryption service (manyllaEncryptionService.js)
- ✅ Sync service (manyllaMinimalSyncService.js)
- ✅ Conflict resolver
- ✅ All type definitions from web app
- ✅ All business logic from web app

## 🚧 Remaining Work for Complete iOS App

### Phase 1: Core UI Components (Week 1)
**Goal: Create React Native versions of all web components**

1. **Profile Components** (Priority: HIGH)
   - [ ] ProfileOverview.native.tsx
   - [ ] ProfileCreateDialog.native.tsx → Create as full screen
   - [ ] ProfileEditDialog.native.tsx → Create as full screen
   - [ ] CategorySection.native.tsx

2. **Form Components** (Priority: HIGH)
   - [ ] MarkdownEditor.native.tsx (using react-native-markdown-display)
   - [ ] DatePicker.native.tsx (iOS native date picker)
   - [ ] FormFields.native.tsx (TextInput components)
   - [ ] SearchBar.native.tsx

3. **Layout Components** (Priority: HIGH)
   - [ ] Header.native.tsx with iOS-style navigation
   - [ ] TabBar using @react-navigation/bottom-tabs
   - [ ] LoadingScreen.native.tsx
   - [ ] EmptyState.native.tsx

### Phase 2: iOS-Specific Features (Week 2)
**Goal: Implement iOS platform features**

1. **Security Features** (Priority: CRITICAL)
   - [ ] Keychain integration for recovery phrase
   - [ ] Face ID / Touch ID authentication
   - [ ] App lock timeout settings
   - [ ] Secure screenshot prevention (blur on app switch)

2. **Native Capabilities** (Priority: HIGH)
   - [ ] Native share sheet integration
   - [ ] Document picker for file attachments
   - [ ] Camera integration for photo capture
   - [ ] Native print functionality

3. **iOS UI Polish** (Priority: MEDIUM)
   - [ ] Haptic feedback on interactions
   - [ ] iOS-style modals and transitions
   - [ ] Pull-to-refresh on lists
   - [ ] Keyboard avoiding views

### Phase 3: Data & Sync (Week 3)
**Goal: Full data persistence and sync**

1. **Storage Layer** (Priority: CRITICAL)
   - [ ] Implement secure AsyncStorage wrapper
   - [ ] Migrate from localStorage patterns
   - [ ] Handle iOS UTF-8 encoding issues (manual implementation)
   - [ ] Implement data migration from web

2. **Background Sync** (Priority: HIGH)
   - [ ] Background fetch configuration (30-minute intervals)
   - [ ] Silent push notifications for sync triggers
   - [ ] Conflict resolution UI
   - [ ] Offline mode indicators

3. **Share System** (Priority: HIGH)
   - [ ] Temporary share link generation
   - [ ] QR code display and scanning
   - [ ] Universal Links for share URLs
   - [ ] Share expiration handling

### Phase 4: Advanced Features (Week 4)
**Goal: iOS platform optimizations**

1. **Widgets (iOS 14+)** (Priority: MEDIUM)
   - [ ] Today Widget for quick info view
   - [ ] Lock Screen Widget (iOS 16+)
   - [ ] Widget deep linking

2. **Siri Shortcuts** (Priority: LOW)
   - [ ] "Show medical information" intent
   - [ ] "Add a note" intent
   - [ ] Custom voice commands

3. **Performance Optimization** (Priority: HIGH)
   - [ ] Image lazy loading
   - [ ] List virtualization for large datasets
   - [ ] Memory management for encryption
   - [ ] Startup time optimization

### Phase 5: Testing & Deployment (Week 5)
**Goal: App Store ready**

1. **Testing** (Priority: CRITICAL)
   - [ ] Unit tests for all services
   - [ ] Integration tests for sync
   - [ ] UI tests with Detox
   - [ ] Manual test plan execution
   - [ ] TestFlight beta testing

2. **App Store Preparation** (Priority: CRITICAL)
   - [ ] App Store Connect setup
   - [ ] Screenshots for all device sizes
   - [ ] App Preview video
   - [ ] Privacy policy and terms
   - [ ] App Store description and keywords

3. **Required Info.plist Entries**
   ```xml
   - NSFaceIDUsageDescription
   - NSCameraUsageDescription  
   - NSPhotoLibraryUsageDescription
   - UIBackgroundModes (fetch, remote-notification)
   ```

## 📱 Immediate Next Steps (Do These Now!)

### 1. Create Basic Navigation Structure
```typescript
// src/navigation/AppNavigator.tsx
- Home tab → Profile list
- Add tab → Create profile
- Settings tab → App settings
- Share tab → Share management
```

### 2. Create First Native Component
Start with ProfileCard.native.tsx as it's the simplest:
```typescript
// src/components/Profile/ProfileCard.native.tsx
import { View, Text, TouchableOpacity } from 'react-native';
// Simple card showing child name and age
```

### 3. Fix Theme Context for React Native
Update ThemeContext to provide React Native compatible colors and styles

### 4. Create Native Onboarding Flow
Replace Material-UI onboarding with React Native version

## 🐛 Known Issues to Address

1. **UTF-8 Encoding on iOS**: TweetNaCl-util issues - need manual implementation
2. **AsyncStorage Performance**: Can freeze with large data - implement batching
3. **Background Limitations**: iOS 30-second execution window
4. **Memory Management**: Encryption operations need cleanup
5. **Navigation Reset**: Deep linking not configured

## 📊 Success Metrics

- [ ] App size under 50MB
- [ ] Cold start under 2 seconds  
- [ ] Encryption operations under 100ms
- [ ] Sync completes in under 5 seconds
- [ ] 60 FPS scrolling performance
- [ ] Zero crashes in TestFlight
- [ ] 4.5+ star rating target

## 🔧 Development Commands

```bash
# Start Metro bundler
cd /Users/adamstack/manylla
npx react-native start --reset-cache

# Run on iOS simulator
npx react-native run-ios

# Run on specific simulator
npx react-native run-ios --simulator="iPhone 15 Pro"

# Clean and rebuild
cd ios && rm -rf build && pod install && cd ..
npm run ios

# Deploy to TestFlight
cd ios && fastlane beta
```

## 📝 Component Creation Template

When creating `.native.tsx` versions:

```typescript
// ComponentName.native.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useTheme } from '@context/ThemeContext';

interface ComponentNameProps {
  // Same props as web version
}

const ComponentName: React.FC<ComponentNameProps> = (props) => {
  const { colors } = useTheme();
  
  return (
    <View style={[styles.container, { backgroundColor: colors.background.primary }]}>
      {/* Native implementation */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    // React Native styles
  }
});

export default ComponentName;
```

## 🎯 Priority Order for Implementation

1. **Week 1**: Get basic CRUD working
   - View profiles
   - Create profile
   - Edit profile
   - Delete profile

2. **Week 2**: Add security
   - Face ID lock
   - Keychain storage
   - Recovery phrase

3. **Week 3**: Enable sync
   - Pull from cloud
   - Push to cloud
   - Conflict resolution

4. **Week 4**: Polish
   - iOS animations
   - Performance tuning
   - Error handling

5. **Week 5**: Ship it!
   - TestFlight beta
   - Bug fixes
   - App Store submission

## 🚀 Let's Build This!

The foundation is solid. The business logic is ready. Now we just need to create the native UI layer and iOS-specific features. Start with the simplest components and work up to the complex ones.

Remember: The web app is already working, so use it as the reference implementation. Every feature should work the same way, just with native UI components instead of Material-UI.