# Manylla Mobile Development Master Plan

## Executive Summary

This master plan outlines the complete strategy for developing native iOS and Android apps for Manylla using React Native. The plan is divided into three comprehensive prompt packs that can be executed by fresh LLMs to create detailed project documentation.

## Project Overview

**Current State**: 
- Fully functional React 19 web application
- Zero-knowledge encryption implemented
- Cloud sync operational with 32-char hex recovery phrases
- API endpoints ready with mobile optimizations

**Target State**:
- Native iOS app (iOS 14+)
- Native Android app (API 24+)
- Feature parity with web plus mobile enhancements
- Maintained zero-knowledge encryption
- Biometric authentication
- Offline-first architecture

## Prompt Pack Structure

### 📋 Prompt Pack 1: Pre-Development Analysis
**File**: `MOBILE_PROMPT_PACK_1_PREWORK.md`

**Purpose**: Comprehensive analysis of existing codebase and technology research

**Key Deliverables**:
1. Architecture Analysis - Understanding current implementation
2. Technology Stack Research - React Native compatibility matrix
3. Data Migration Strategy - localStorage to mobile storage
4. Feature Parity Analysis - Web to mobile translation
5. Project Timeline - 12-week development plan

**Critical Insights Needed**:
- React 19 to React Native compatibility
- TweetNaCl.js mobile implementation
- Material-UI to React Native component mapping
- Sync service adaptation requirements

### 📱 Prompt Pack 2: iOS Development
**File**: `MOBILE_PROMPT_PACK_2_IOS.md`

**Purpose**: iOS-specific implementation planning

**Key Deliverables**:
1. Platform Guide - iOS 14+ features and requirements
2. UI Specifications - Human Interface Guidelines compliance
3. Data Architecture - Keychain and Core Data integration
4. Features Roadmap - Widgets, Siri, Apple Watch
5. Deployment Guide - App Store requirements
6. Security Checklist - iOS-specific hardening

**Critical iOS Considerations**:
- UTF-8 encoding bug with TweetNaCl-util
- AsyncStorage performance issues (20+ second freezes)
- Background execution limitations (30-second windows)
- Keychain sharing for future Apple Watch app

### 🤖 Prompt Pack 3: Android Development
**File**: `MOBILE_PROMPT_PACK_3_ANDROID.md`

**Purpose**: Android-specific implementation planning

**Key Deliverables**:
1. Platform Guide - API 24+ features and requirements
2. UI Specifications - Material Design 3 compliance
3. Data Architecture - Android Keystore and Room database
4. Features Roadmap - Widgets, Google Assistant, Wear OS
5. Deployment Guide - Google Play requirements
6. Security Checklist - Android-specific hardening
7. Compatibility Matrix - Device fragmentation handling

**Critical Android Considerations**:
- Doze mode and battery optimizations
- Scoped storage restrictions (Android 11+)
- Background execution limits with WorkManager
- 64-bit requirement for Google Play

## Execution Strategy

### Phase 0: Pre-Development (Week 0)
**Execute Prompt Pack 1**
- Run all 5 prompts sequentially
- Create `/docs/mobile/` directory structure
- Generate all analysis documents
- Review and refine recommendations

### Phase 1: Project Setup (Week 1)
**Based on Prompt Pack 1 outputs**
```bash
# Initialize React Native project
npx react-native init ManyllaApp --template react-native-template-typescript
cd ManyllaApp

# Install core dependencies
npm install @react-navigation/native @react-navigation/stack
npm install react-native-keychain react-native-biometrics
npm install @react-native-async-storage/async-storage
npm install tweetnacl tweetnacl-util
```

### Phase 2: Platform Planning (Week 2)
**Execute Prompt Packs 2 & 3 in parallel**
- iOS team uses Prompt Pack 2
- Android team uses Prompt Pack 3
- Identify shared vs platform-specific code
- Plan component architecture

### Phase 3-10: Development Sprints (Weeks 3-10)
**Weekly Sprint Structure**:
- Monday: Sprint planning from generated docs
- Tuesday-Thursday: Development
- Friday: Testing and documentation updates

### Phase 11-12: Launch Preparation (Weeks 11-12)
- Beta testing via TestFlight and Play Console
- App store optimization
- Marketing materials preparation
- Launch strategy execution

## Key Technical Decisions

### 1. React Native vs Expo
**Decision**: Bare React Native
**Rationale**: 
- Need native module access for encryption
- Custom native code for biometrics
- Smaller app size without Expo overhead
- More control over build process

### 2. State Management
**Decision**: Context API (matching web)
**Rationale**:
- Consistency with web codebase
- Simpler migration path
- Sufficient for app complexity
- No additional dependencies

### 3. Navigation Library
**Decision**: React Navigation
**Rationale**:
- Most mature and stable
- Best documentation
- Native feel on both platforms
- TypeScript support

### 4. Encryption Library
**Decision**: TweetNaCl with manual UTF-8
**Rationale**:
- Consistency with web implementation
- Known iOS UTF-8 fix from StackMap
- Proven security model
- Small library size

## Critical Success Factors

### 1. Security Maintenance
- Zero-knowledge encryption must be preserved
- Biometric authentication properly implemented
- Keychain/Keystore secure storage
- No plaintext data in logs or analytics

### 2. Performance Targets
- App launch: < 2 seconds
- Encryption operations: < 100ms
- Sync operations: < 5 seconds
- Memory usage: < 200MB
- Battery impact: < 3% per hour

### 3. User Experience
- Feature parity with web
- Platform-native feel
- Offline functionality
- Smooth animations (60 FPS)
- Intuitive navigation

### 4. Code Sharing
- 70%+ shared code between platforms
- Reusable business logic from web
- Consistent data models
- Unified API integration

## Risk Mitigation

### High-Risk Areas
1. **iOS UTF-8 Encoding**: Use StackMap's proven manual implementation
2. **AsyncStorage Performance**: Implement debouncing and batching
3. **Background Sync**: Design for platform limitations
4. **App Store Rejection**: Follow guidelines strictly, especially for medical apps
5. **Data Migration**: Provide clear web-to-mobile migration path

### Mitigation Strategies
- Early prototype of encryption on both platforms
- Performance testing from Week 1
- Regular TestFlight/Internal Test builds
- Security audit in Week 10
- User testing throughout development

## Resource Requirements

### Team Composition
- 1 React Native Lead Developer
- 1 iOS Specialist (part-time)
- 1 Android Specialist (part-time)
- 1 QA Engineer
- 1 UI/UX Designer (consulting)

### Infrastructure
- Apple Developer Account ($99/year)
- Google Play Developer Account ($25 one-time)
- Physical test devices (minimum 4 iOS, 4 Android)
- CI/CD pipeline (GitHub Actions recommended)
- Crash reporting (Sentry or Crashlytics)

### Timeline
- **Total Duration**: 12 weeks
- **Development**: 10 weeks
- **Testing & Launch**: 2 weeks
- **Buffer**: 20% built into estimates

## Monitoring & Success Metrics

### Development Metrics
- Code coverage > 80%
- Build success rate > 95%
- Crash-free rate > 99.5%
- Performance budget adherence

### Post-Launch Metrics
- App store rating > 4.0
- Monthly active users
- Sync success rate > 99%
- User retention (30-day)
- Feature adoption rates

## Next Steps

1. **Immediate Actions**:
   - Execute Prompt Pack 1 for analysis
   - Set up development environments
   - Create React Native project
   - Configure CI/CD pipeline

2. **Week 1 Goals**:
   - Complete all analysis documents
   - Finalize technology choices
   - Set up project structure
   - Implement basic navigation

3. **First Milestone (Week 4)**:
   - Core encryption working on both platforms
   - Basic profile CRUD operations
   - Offline storage implemented
   - Initial UI components

## Appendix: File References

### Critical Web Files to Port
```
src/services/sync/manyllaEncryptionService.js
src/services/sync/manyllaMinimalSyncService.js
src/types/ChildProfile.ts
src/context/SyncContext.tsx
src/components/Sharing/ShareDialog.tsx
```

### StackMap References for iOS Issues
```
/Users/adamstack/StackMap/StackMap/src/services/sync/encryptionServiceFixed.ts
- Manual UTF-8 implementation
- iOS-specific fixes
```

### API Documentation
```
api/api-docs.yaml
- Complete OpenAPI specification
- Mobile-specific headers documented
```

## Conclusion

This master plan provides a comprehensive roadmap for developing Manylla's mobile apps. By executing the three prompt packs sequentially, any LLM can generate the detailed documentation needed for successful implementation. The plan prioritizes security, performance, and user experience while maintaining the zero-knowledge encryption that is core to Manylla's value proposition.

---

*Document Version: 1.0*
*Created: January 2025*
*Last Updated: January 2025*