# Prompt Pack 1: Pre-Development Analysis & Planning

## Context for LLM
You are tasked with creating a comprehensive mobile app development plan for Manylla, a zero-knowledge encrypted medical information management app for parents of children with special needs. The web app is already built with React 19 and fully operational. Your goal is to analyze the existing codebase and create a detailed project plan for React Native mobile apps.

## Prompt 1: Codebase Analysis & Architecture Review

```
Please perform a comprehensive analysis of the Manylla web application codebase located at /Users/adamstack/manylla/manylla-app/. Create a detailed report covering:

1. **Architecture Analysis**
   - Review src/ directory structure
   - Identify core business logic components
   - Map data flow patterns
   - Document state management approach (Context API usage)
   - Analyze component hierarchy and relationships

2. **Encryption Implementation Review**
   - Examine src/services/sync/manyllaEncryptionService.js
   - Document key derivation methods
   - Review TweetNaCl.js usage patterns
   - Identify iOS UTF-8 compatibility considerations (see StackMap's manual implementation)
   - Map encryption/decryption touchpoints

3. **Data Models & Types**
   - Review src/types/ChildProfile.ts
   - Document all TypeScript interfaces
   - Identify data validation patterns
   - Map localStorage usage (for migration planning)

4. **API Integration Points**
   - Review all API calls in src/services/
   - Document endpoint usage patterns
   - Identify authentication mechanisms (recovery phrase based)
   - Review error handling patterns

5. **UI Components Analysis**
   - Catalog all Material-UI components used
   - Identify custom components that need React Native equivalents
   - Document modal/dialog patterns
   - Review responsive design breakpoints

6. **Critical Features to Port**
   - List all features by priority
   - Identify web-specific features that need mobile alternatives
   - Document offline functionality requirements
   - Map share system implementation

Create a structured document titled "MANYLLA_MOBILE_ARCHITECTURE_ANALYSIS.md" with findings.
```

## Prompt 2: Technology Stack Research & Compatibility Matrix

```
Research and document the optimal technology stack for Manylla React Native apps. Create a comprehensive compatibility matrix covering:

1. **React & React Native Versions**
   - Current web app uses React 19.0.0
   - Research React Native compatibility with React 19
   - Document any breaking changes or considerations
   - Recommend specific React Native version

2. **Platform Requirements**
   - iOS minimum version (recommend iOS 14+)
   - Android minimum API level (recommend API 24+)
   - Document platform-specific limitations

3. **Encryption Library Compatibility**
   - Research TweetNaCl.js alternatives for React Native
   - Document react-native-sodium vs tweetnacl-react-native
   - Address iOS UTF-8 encoding issues (critical - see StackMap's experience)
   - Plan for secure key storage (Keychain/Keystore)

4. **Essential React Native Libraries**
   Research and recommend libraries for:
   - Navigation: @react-navigation/native vs react-native-navigation
   - State Management: Can Context API work or need Redux/Zustand?
   - Async Storage: @react-native-async-storage/async-storage
   - Biometric Auth: react-native-biometrics vs react-native-touch-id
   - Camera/Documents: react-native-image-picker
   - File System: react-native-fs
   - Networking: Built-in fetch vs axios
   - UI Components: React Native Elements vs NativeBase vs custom

5. **Development Environment Setup**
   - macOS requirements for iOS development
   - Xcode version requirements
   - Android Studio setup
   - React Native CLI vs Expo (recommend bare React Native for encryption needs)
   - Testing device requirements

Create "MANYLLA_MOBILE_TECH_STACK.md" with recommendations and justifications.
```

## Prompt 3: Data Migration & Sync Strategy

```
Develop a comprehensive data migration and synchronization strategy for moving from web localStorage to mobile persistent storage:

1. **Current Web Implementation Review**
   - Analyze current localStorage usage in web app
   - Document data structure and size estimates
   - Review sync service implementation (60-second pull interval)
   - Understand recovery phrase management

2. **Mobile Storage Strategy**
   - Design AsyncStorage schema
   - Plan for data migration from web
   - Document backup strategies
   - Plan for app update data migrations

3. **Sync Architecture for Mobile**
   - Adapt minimalSyncService.js for React Native
   - Plan for background sync (iOS Background Fetch, Android WorkManager)
   - Handle offline queue implementation
   - Design conflict resolution (last-write-wins is current approach)

4. **Security Considerations**
   - Keychain (iOS) / Keystore (Android) for recovery phrase
   - Biometric authentication flow
   - Data encryption at rest
   - Memory management for sensitive data

5. **Performance Optimization**
   - Plan for lazy loading strategies
   - Image and document caching
   - Sync data compression
   - Battery usage optimization

Create "MANYLLA_MOBILE_DATA_STRATEGY.md" with detailed implementation plan.
```

## Prompt 4: Feature Parity & Mobile-Specific Enhancements

```
Create a feature comparison matrix and plan for mobile-specific enhancements:

1. **Feature Parity Analysis**
   Review existing web features and categorize as:
   - Direct port (works as-is)
   - Needs adaptation (different UX pattern)
   - Not applicable (web-only)
   - Mobile-only opportunity

2. **Mobile-Specific Features to Add**
   - Push notifications for share access
   - Biometric authentication
   - Camera integration for document capture
   - Voice notes for entries
   - Native share sheet integration
   - Widgets (iOS 14+, Android)
   - Siri/Google Assistant shortcuts
   - Apple Watch companion app consideration

3. **UX Adaptation Requirements**
   - Navigation pattern changes (tab bar vs drawer)
   - Modal presentation differences
   - Gesture support planning
   - Keyboard avoidance strategies
   - Platform-specific UI guidelines

4. **Offline-First Architecture**
   - Complete offline functionality
   - Smart sync when connected
   - Queue management for changes
   - Conflict resolution UI

Create "MANYLLA_MOBILE_FEATURES.md" with prioritized feature list.
```

## Prompt 5: Project Timeline & Resource Planning

```
Create a detailed project plan with timeline and resource requirements:

1. **Phase 1: Foundation (Weeks 1-2)**
   - Development environment setup
   - React Native project initialization
   - Core navigation structure
   - Basic authentication flow

2. **Phase 2: Core Features (Weeks 3-6)**
   - Encryption service implementation
   - Data models and storage
   - Profile management
   - Entry CRUD operations

3. **Phase 3: Sync & Sharing (Weeks 7-8)**
   - Sync service implementation
   - Share functionality
   - Offline queue management

4. **Phase 4: Platform-Specific (Weeks 9-10)**
   - iOS-specific features
   - Android-specific features
   - Platform testing

5. **Phase 5: Polish & Launch (Weeks 11-12)**
   - Performance optimization
   - Security audit
   - App store preparation
   - Beta testing

Create "MANYLLA_MOBILE_PROJECT_PLAN.md" with Gantt chart and milestones.
```

## Key Files to Examine

Point the LLM to these critical files:
- `/src/services/sync/manyllaEncryptionService.js` - Encryption implementation
- `/src/services/sync/manyllaMinimalSyncService.js` - Sync logic
- `/src/context/SyncContext.tsx` - Sync state management
- `/src/types/ChildProfile.ts` - Data models
- `/src/components/Sharing/ShareDialog.tsx` - Share implementation
- `/api/api-docs.yaml` - API documentation
- `/CLAUDE.md` - Project context
- `/docs/05_LLM_TOOLSETS.md` - Development practices

## Expected Deliverables

The LLM should create a `/docs/mobile/` directory with:
1. MANYLLA_MOBILE_ARCHITECTURE_ANALYSIS.md
2. MANYLLA_MOBILE_TECH_STACK.md
3. MANYLLA_MOBILE_DATA_STRATEGY.md
4. MANYLLA_MOBILE_FEATURES.md
5. MANYLLA_MOBILE_PROJECT_PLAN.md

## Success Criteria

- Comprehensive analysis with no critical features missed
- Clear migration path from web to mobile
- Specific library recommendations with justifications
- Realistic timeline with buffer for unknowns
- Security-first approach maintained
- Platform-specific considerations addressed