# Manylla Mobile Features & Enhancement Plan

## Executive Summary

This document provides a comprehensive feature comparison between the existing web application and planned mobile apps, categorizing features by implementation approach and identifying mobile-specific enhancements that will provide superior user experience for parents managing special needs information on the go.

## 1. Feature Parity Matrix

### 1.1 Core Features Classification

| Feature | Web Implementation | Mobile Approach | Priority | Complexity |
|---------|-------------------|-----------------|----------|------------|
| **Profile Management** |
| Create/Edit Profile | Dialog-based | Full screen forms | P0 | Low |
| Profile Photo | File upload | Camera/Gallery | P0 | Medium |
| Multiple Profiles | Tab switching | Navigation stack | P1 | Low |
| Profile Export | Download JSON | Share sheet | P2 | Medium |
| **Entry Management** |
| Add/Edit Entry | Modal dialog | Screen navigation | P0 | Low |
| Markdown Editor | @uiw/react-md-editor | Native editor | P0 | High |
| Entry Categories | Dropdown select | Native picker | P0 | Low |
| Entry Visibility | Checkbox group | Toggle switches | P0 | Low |
| Entry Search | Text filter | Native search bar | P1 | Medium |
| Entry Attachments | File upload | Document picker | P2 | Medium |
| **Category Management** |
| View Categories | Grid layout | List/Grid toggle | P0 | Low |
| Reorder Categories | Drag & drop | Drag or edit mode | P1 | Medium |
| Custom Categories | Modal form | Screen form | P1 | Low |
| Category Colors | Color picker | Native picker | P1 | Low |
| **Encryption & Security** |
| Zero-knowledge | TweetNaCl | react-native-sodium | P0 | High |
| Recovery Phrase | Text display | Secure clipboard | P0 | Medium |
| Biometric Lock | N/A | Face ID/Touch ID | P0 | Medium |
| Auto-lock | Tab timeout | App background | P1 | Low |
| **Sync & Backup** |
| Multi-device Sync | 60-sec pull | Background sync | P0 | High |
| Recovery Phrase | Manual entry | QR scan option | P0 | Medium |
| Offline Mode | localStorage | AsyncStorage | P0 | Medium |
| Conflict Resolution | Last-write-wins | Same + UI | P1 | Medium |
| **Sharing** |
| Create Share | Modal wizard | Step screens | P1 | Medium |
| QR Code Share | Display QR | Display + scan | P1 | Low |
| Time-limited Links | URL generation | Deep links | P1 | Medium |
| Print Preview | Browser print | PDF generation | P2 | High |
| **UI/UX** |
| Theme Toggle | Light/Dark | Light/Dark/Auto | P0 | Low |
| Responsive Layout | Breakpoints | Native layouts | P0 | Medium |
| Loading States | Skeletons | Native indicators | P0 | Low |
| Toast Messages | Snackbar | Native toast | P0 | Low |
| **Onboarding** |
| Welcome Wizard | Multi-step modal | Screen flow | P1 | Medium |
| Sample Data | Pre-loaded | Same | P1 | Low |
| Feature Tips | Tooltips | Coach marks | P2 | Medium |

### 1.2 Feature Implementation Categories

**Direct Port (Minimal Changes)**
- Profile data structure
- Entry CRUD operations
- Category configuration
- Encryption algorithms
- Sync protocol
- Visibility controls

**Needs Adaptation (Platform Differences)**
- Navigation patterns (modal → stack)
- File handling (upload → picker)
- Drag & drop (web → native gestures)
- Keyboard handling
- Form layouts
- Print functionality

**Not Applicable (Web-Only)**
- Browser history manipulation
- Right-click context menus
- Hover states
- Keyboard shortcuts (Ctrl+S, etc.)
- Browser extensions
- Web-specific URL handling

**Mobile-Only Opportunities**
- Biometric authentication
- Push notifications
- Camera integration
- Voice notes
- Native share sheet
- Widgets
- Offline-first design
- Background sync
- App shortcuts

## 2. Mobile-Specific Enhancements

### 2.1 Biometric Authentication
```typescript
interface BiometricAuth {
  type: 'FaceID' | 'TouchID' | 'Fingerprint' | 'Face';
  enabled: boolean;
  fallbackToPasscode: boolean;
  lockOnBackground: boolean;
  lockTimeout: number; // seconds
}

// Implementation
class BiometricService {
  async enable(): Promise<void> {
    const isSupported = await LocalAuthentication.hasHardwareAsync();
    if (isSupported) {
      await this.storeWithBiometric();
    }
  }
  
  async authenticate(): Promise<boolean> {
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'Access your Manylla data',
      fallbackLabel: 'Use Recovery Phrase',
      disableDeviceFallback: false
    });
    return result.success;
  }
}
```

### 2.2 Push Notifications
```typescript
interface NotificationFeatures {
  shareAccess: boolean;      // Someone accessed your share
  syncComplete: boolean;      // Sync from another device
  reminders: boolean;         // Entry reminders
  securityAlerts: boolean;    // Failed access attempts
}

// Rich notifications with actions
{
  title: "Share Accessed",
  body: "Dr. Smith viewed Ellie's medical summary",
  data: { shareId: "abc123" },
  actions: [
    { id: "revoke", title: "Revoke Access" },
    { id: "extend", title: "Extend Time" }
  ]
}
```

### 2.3 Camera Integration
```typescript
interface CameraFeatures {
  profilePhoto: {
    source: 'camera' | 'gallery';
    crop: boolean;
    compress: boolean;
    maxSize: number;
  };
  documentScan: {
    multiPage: boolean;
    ocr: boolean;
    autoEnhance: boolean;
  };
  quickCapture: {
    widget: boolean;
    shortcut: boolean;
  };
}
```

### 2.4 Voice Notes
```typescript
interface VoiceNoteFeature {
  maxDuration: number;        // seconds
  format: 'mp3' | 'aac';
  transcription: boolean;     // Auto-transcribe
  attachToEntry: boolean;
  
  // UI Integration
  quickRecord: boolean;       // Long-press to record
  waveformDisplay: boolean;
  playbackSpeed: number[];    // [0.5, 1, 1.5, 2]
}

// Implementation
class VoiceNoteService {
  async startRecording(entryId: string) {
    await Audio.requestPermissionsAsync();
    await Audio.setAudioModeAsync({
      allowsRecordingIOS: true,
      playsInSilentModeIOS: true
    });
    
    const recording = new Audio.Recording();
    await recording.prepareToRecordAsync(RECORDING_OPTIONS);
    await recording.startAsync();
    
    return recording;
  }
}
```

### 2.5 Native Share Sheet
```typescript
interface ShareSheetIntegration {
  // Share TO Manylla
  acceptTypes: ['text', 'image', 'pdf'];
  quickAdd: boolean;  // Add without opening app
  
  // Share FROM Manylla
  exportFormats: ['pdf', 'text', 'image'];
  includeQR: boolean;
  customMessage: boolean;
}

// Implementation
Share.share({
  title: 'Ellie\'s Medical Summary',
  message: customMessage,
  url: shareLink,
  type: 'application/pdf'
});
```

### 2.6 iOS Widgets
```typescript
interface WidgetTypes {
  quickInfo: {
    size: 'small' | 'medium' | 'large';
    content: ['medical', 'contacts', 'allergies'];
    tapAction: 'openApp' | 'openProfile';
  };
  quickAdd: {
    size: 'small';
    defaultCategory: string;
  };
  photoGallery: {
    size: 'medium' | 'large';
    profileId: string;
  };
}
```

### 2.7 Android Widgets
```typescript
interface AndroidWidgets {
  homeScreen: {
    resizable: boolean;
    updateFrequency: number;
    interactive: boolean;
  };
  lockScreen: {
    emergencyInfo: boolean;
    quickAccess: boolean;
  };
}
```

### 2.8 Siri/Google Assistant Shortcuts
```typescript
interface VoiceAssistantShortcuts {
  phrases: {
    'Show Ellie\'s medical info': 'openMedical',
    'Add note to Manylla': 'quickAdd',
    'Share emergency info': 'shareEmergency'
  };
  
  // Siri Shortcuts
  siriIntents: [
    'ViewProfile',
    'AddEntry',
    'ShareInfo'
  ];
  
  // Google Assistant
  appActions: [
    'actions.intent.OPEN_APP_FEATURE',
    'actions.intent.CREATE_THING'
  ];
}
```

### 2.9 Apple Watch Companion
```typescript
interface WatchAppFeatures {
  complications: {
    modular: 'quickInfo';
    circular: 'profilePhoto';
  };
  
  screens: {
    emergencyInfo: boolean;
    contactList: boolean;
    quickNotes: boolean;
    medications: boolean;
  };
  
  sync: {
    automatic: boolean;
    dataSubset: string[];  // Only essential data
  };
}
```

## 3. UX Adaptation Requirements

### 3.1 Navigation Pattern Changes

**Web Navigation:**
```
Header → Modal Dialogs → Inline Editing
```

**Mobile Navigation:**
```
Tab Bar → Stack Navigation → Full Screen Forms
         → Drawer (Settings)
```

**Implementation:**
```typescript
// Bottom Tab Navigation
const TabNavigator = () => (
  <Tab.Navigator>
    <Tab.Screen name="Profile" component={ProfileScreen} />
    <Tab.Screen name="Entries" component={EntriesScreen} />
    <Tab.Screen name="Add" component={AddScreen} />
    <Tab.Screen name="Share" component={ShareScreen} />
    <Tab.Screen name="Settings" component={SettingsScreen} />
  </Tab.Navigator>
);

// Stack Navigation for Details
const ProfileStack = () => (
  <Stack.Navigator>
    <Stack.Screen name="ProfileList" component={ProfileListScreen} />
    <Stack.Screen name="ProfileDetail" component={ProfileDetailScreen} />
    <Stack.Screen name="EntryDetail" component={EntryDetailScreen} />
    <Stack.Screen name="CategoryEdit" component={CategoryEditScreen} />
  </Stack.Navigator>
);
```

### 3.2 Modal Presentation Differences

**Web Modals:**
- Overlay with backdrop
- Centered dialog
- Multiple open simultaneously

**Mobile Modals:**
- Full screen or sheet
- Platform-specific animations
- Single modal at a time
- Gesture dismissal

### 3.3 Gesture Support

```typescript
interface GestureMapping {
  swipeRight: 'back' | 'openDrawer';
  swipeLeft: 'delete' | 'archive';
  swipeDown: 'refresh' | 'dismiss';
  longPress: 'select' | 'contextMenu';
  pinch: 'zoom';
  doubleTap: 'like' | 'zoom';
  
  // 3D Touch / Force Touch (iOS)
  forceTouch: 'preview' | 'quickActions';
}

// Implementation with react-native-gesture-handler
const EntryCard = () => {
  return (
    <Swipeable
      renderLeftActions={renderArchiveAction}
      renderRightActions={renderDeleteAction}
      onSwipeableOpen={handleSwipe}
    >
      <LongPressGestureHandler
        onHandlerStateChange={handleLongPress}
        minDurationMs={800}
      >
        <Animated.View>
          {/* Entry content */}
        </Animated.View>
      </LongPressGestureHandler>
    </Swipeable>
  );
};
```

### 3.4 Keyboard Avoidance

```typescript
// Automatic keyboard avoidance
import { KeyboardAvoidingView, Platform } from 'react-native';

const EntryForm = () => (
  <KeyboardAvoidingView
    behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    style={styles.container}
    keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
  >
    <ScrollView>
      {/* Form fields */}
    </ScrollView>
  </KeyboardAvoidingView>
);
```

### 3.5 Platform-Specific UI Guidelines

**iOS (Human Interface Guidelines):**
- Navigation bar with large titles
- SF Symbols for icons
- Haptic feedback for actions
- Pull-to-refresh
- Segmented controls
- Action sheets for options

**Android (Material Design 3):**
- Material You theming
- FAB for primary action
- Bottom sheets
- Snackbar for feedback
- Navigation drawer
- Chips for filters

## 4. Offline-First Architecture

### 4.1 Complete Offline Functionality

```typescript
interface OfflineCapabilities {
  features: {
    viewProfile: true;
    editProfile: true;
    addEntry: true;
    editEntry: true;
    deleteEntry: true;
    reorderCategories: true;
    search: true;
    generateShare: false;  // Requires server
  };
  
  dataSync: {
    queueChanges: true;
    conflictResolution: 'lastWriteWins' | 'manual';
    autoSync: true;
    backgroundSync: true;
  };
  
  storage: {
    maxOfflineData: '100MB';
    compressionEnabled: true;
    encryptionEnabled: true;
  };
}
```

### 4.2 Smart Sync When Connected

```typescript
class SmartSyncService {
  async syncWhenOptimal() {
    const conditions = await this.getOptimalConditions();
    
    if (conditions.met) {
      await this.performSync({
        priority: this.calculatePriority(),
        compression: conditions.network !== 'wifi',
        batchSize: this.calculateBatchSize(conditions)
      });
    }
  }
  
  private async getOptimalConditions() {
    return {
      met: battery > 20 && network !== 'none',
      network: await this.getNetworkType(),
      battery: await this.getBatteryLevel(),
      dataUsage: await this.getDataUsage()
    };
  }
}
```

### 4.3 Queue Management

```typescript
interface QueuedOperation {
  id: string;
  type: 'CREATE' | 'UPDATE' | 'DELETE';
  entity: string;
  data: any;
  timestamp: number;
  attempts: number;
  priority: 'high' | 'normal' | 'low';
}

class OfflineQueueManager {
  private queue: QueuedOperation[] = [];
  
  async processQueue() {
    const sorted = this.queue.sort((a, b) => {
      // Priority first, then timestamp
      if (a.priority !== b.priority) {
        return this.priorityValue(b.priority) - this.priorityValue(a.priority);
      }
      return a.timestamp - b.timestamp;
    });
    
    for (const operation of sorted) {
      await this.processOperation(operation);
    }
  }
}
```

## 5. Feature Priority Roadmap

### 5.1 Priority 0 - MVP (Weeks 1-4)
Essential features for basic functionality:
- [ ] Profile creation and editing
- [ ] Entry management (CRUD)
- [ ] Basic categories
- [ ] Encryption service
- [ ] Local storage
- [ ] Basic theme support
- [ ] Simple navigation

### 5.2 Priority 1 - Core Features (Weeks 5-8)
Features needed for production release:
- [ ] Multi-device sync
- [ ] Recovery phrase management
- [ ] Biometric authentication
- [ ] Share functionality
- [ ] Custom categories
- [ ] Search and filter
- [ ] Offline mode
- [ ] Onboarding flow

### 5.3 Priority 2 - Enhancements (Weeks 9-12)
Features that improve user experience:
- [ ] Push notifications
- [ ] Camera integration
- [ ] Voice notes
- [ ] Widgets (iOS)
- [ ] Document attachments
- [ ] Advanced sharing options
- [ ] Performance optimizations
- [ ] Accessibility features

### 5.4 Priority 3 - Advanced (Post-Launch)
Features for future releases:
- [ ] Apple Watch app
- [ ] Android Wear app
- [ ] Siri/Google Assistant
- [ ] Family sharing
- [ ] Multi-language support
- [ ] Advanced analytics
- [ ] Cloud backup options
- [ ] Integration APIs

## 6. Platform-Specific Implementation

### 6.1 iOS-Specific Features

```swift
// iOS Native Module for Special Features
@objc(ManyllaIOSFeatures)
class ManyllaIOSFeatures: NSObject {
  
  @objc
  func enableFaceID(_ resolver: RCTPromiseResolveBlock,
                     rejecter: RCTPromiseRejectBlock) {
    let context = LAContext()
    var error: NSError?
    
    if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                                 error: &error) {
      context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics,
                           localizedReason: "Access your Manylla data") {
        success, error in
        if success {
          resolver(true)
        } else {
          rejecter("AUTH_FAILED", error?.localizedDescription, error)
        }
      }
    }
  }
  
  @objc
  func createWidget(_ data: NSDictionary) {
    // Widget creation logic
    WidgetCenter.shared.reloadAllTimelines()
  }
}
```

### 6.2 Android-Specific Features

```kotlin
// Android Native Module
package com.manylla.features

class ManyllaAndroidFeatures(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {
    
  @ReactMethod
  fun enableFingerprint(promise: Promise) {
    val biometricManager = BiometricManager.from(reactApplicationContext)
    
    when (biometricManager.canAuthenticate(BIOMETRIC_STRONG)) {
      BiometricManager.BIOMETRIC_SUCCESS -> {
        val biometricPrompt = BiometricPrompt(
          currentActivity as FragmentActivity,
          ContextCompat.getMainExecutor(reactApplicationContext),
          authenticationCallback
        )
        biometricPrompt.authenticate(promptInfo)
      }
      else -> promise.reject("BIOMETRIC_ERROR", "Biometric not available")
    }
  }
  
  @ReactMethod
  fun createWidget(data: ReadableMap) {
    // Widget creation logic
    val appWidgetManager = AppWidgetManager.getInstance(reactApplicationContext)
    appWidgetManager.updateAppWidget(widgetId, views)
  }
}
```

## 7. Performance Targets

### 7.1 Launch Performance
- Cold start: < 2 seconds
- Warm start: < 1 second
- First meaningful paint: < 1.5 seconds
- Time to interactive: < 2.5 seconds

### 7.2 Runtime Performance
- Screen transition: < 300ms
- List scrolling: 60 FPS
- Search results: < 500ms
- Encryption/decryption: < 200ms
- Image loading: < 1 second

### 7.3 Resource Usage
- Memory: < 100MB typical, < 200MB peak
- Battery: < 2% per hour active use
- Storage: < 50MB app, < 500MB data
- Network: < 1MB per sync typical

## 8. Accessibility Features

### 8.1 Required Accessibility
```typescript
interface AccessibilityFeatures {
  // Screen reader support
  voiceOver: true;           // iOS
  talkBack: true;           // Android
  
  // Visual
  dynamicType: true;        // Font scaling
  highContrast: true;       // Increased contrast
  reduceMotion: true;       // Simplified animations
  colorBlindMode: true;     // Alternative colors
  
  // Motor
  assistiveTouch: true;     // Larger touch targets
  voiceControl: true;       // Voice commands
  switchControl: true;      // External switches
  
  // Cognitive
  simplifiedUI: boolean;    // Reduced complexity
  guidedAccess: boolean;    // Restrict areas
}
```

### 8.2 Implementation
```typescript
// Accessibility labels and hints
<TouchableOpacity
  accessible={true}
  accessibilityLabel="Add new entry"
  accessibilityHint="Double tap to create a new entry for this profile"
  accessibilityRole="button"
  accessibilityState={{ disabled: false }}
>
  {/* Button content */}
</TouchableOpacity>

// Dynamic font scaling
const styles = StyleSheet.create({
  text: {
    fontSize: PixelRatio.getFontScale() * 16
  }
});
```

## 9. Success Metrics

### 9.1 User Engagement
- Daily active users (DAU)
- Session duration
- Features used per session
- Sync frequency
- Share creation rate

### 9.2 Technical Metrics
- Crash-free rate (> 99.5%)
- ANR rate (< 0.5%)
- Sync success rate (> 95%)
- Encryption performance
- App size growth

### 9.3 Business Metrics
- User retention (Day 1, 7, 30)
- Feature adoption rates
- Platform distribution (iOS/Android)
- App store ratings
- Support ticket volume

## Conclusion

The mobile feature set for Manylla balances faithful reproduction of core web functionality with native platform enhancements that provide superior mobile user experience. The prioritized roadmap ensures rapid delivery of MVP features while building toward a comprehensive mobile solution that leverages platform-specific capabilities like biometric authentication, camera integration, and offline-first architecture.

Key differentiators for the mobile app include:
1. **Security**: Biometric authentication and secure enclave storage
2. **Convenience**: Camera capture, voice notes, and widgets
3. **Reliability**: Offline-first with intelligent sync
4. **Integration**: Native share sheets and voice assistants
5. **Performance**: Optimized for battery and data usage

This feature plan provides a clear path from MVP to a full-featured mobile application that serves the unique needs of parents managing special needs information on the go.