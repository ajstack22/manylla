# PHASE 3: POLISH FEATURES
## Print Preview, QR Code Sharing, and Markdown Support

### 🎯 OBJECTIVES
1. Add Print functionality to profile
2. Integrate QR codes with Share Dialog
3. Implement Markdown in entry descriptions
4. Complete advanced feature set

**Time Estimate:** 2-3 hours  
**Priority:** LOWER - Advanced features

---

## 🔧 TASK 1: ADD PRINT PREVIEW

### Current Problem
PrintPreview component is imported but there's no way to trigger it. Users can't print profiles.

### Changes Required

#### Step 1: Add Print Button to Header
**Location:** Header component props (Line ~493-502)
```javascript
<Header
  onSyncClick={() => setSyncDialogOpen(true)}
  onCloseProfile={handleLogout}
  onShare={() => setShareDialogOpen(true)}
  onCategoriesClick={() => setCategoriesOpen(true)}
  onQuickInfoClick={() => setQuickInfoOpen(true)}  // From Phase 2
  onPrintClick={() => setPrintPreviewOpen(true)}    // ADD THIS
  syncStatus={syncStatus}
  onThemeToggle={toggleTheme}
  theme={theme}
  colors={colors}
/>
```

#### Step 2: Add Print Icon to IconProvider
Check if PrintIcon exists in Common/IconProvider.js. If not, add it:
```javascript
// In IconProvider.js exports
export const PrintIcon = createIcon('print', 'Print');
```

#### Step 3: Wire Up PrintPreview Component
**Location:** After other dialogs (Line ~593)
```javascript
{/* Print Preview */}
{printPreviewOpen && (
  <PrintPreview
    visible={printPreviewOpen}
    onClose={() => setPrintPreviewOpen(false)}
    profile={profile}
    categories={unifiedCategories}
    entries={profile?.entries || []}
  />
)}
```

#### Step 4: Update Header Menu
Add print option to Header.js menu items:
```javascript
{
  label: 'Print',
  icon: PrintIcon,
  onPress: () => {
    onPrintClick();
    setMenuOpen(false);
  }
}
```

### Print Styling Considerations
- Manila theme colors for headers
- Clean black & white for accessibility
- Page break handling for categories
- Include/exclude photo options

---

## 🔧 TASK 2: INTEGRATE QR CODE WITH SHARING

### Current Problem
QRCodeModal exists but is isolated. Should be integrated with ShareDialogOptimized.

### Changes Required

#### Option 1: Add QR Button in Share Dialog (RECOMMENDED)
The ShareDialogOptimized should have a QR code button that opens QRCodeModal.

**Approach:** Modify ShareDialogOptimized to include QR option
- This requires modifying the ShareDialogOptimized component
- Add "Show QR Code" button that sets qrCodeOpen state

#### Option 2: Standalone QR in Header Menu
Add QR code as separate menu option.

**Location:** Header props (Line ~493-502)
```javascript
<Header
  // ... existing props
  onQRClick={() => setQRCodeOpen(true)}  // ADD THIS
/>
```

#### Step 3: Update QRCodeModal Props
**Location:** QRCodeModal component (Line ~596-603)
**Current Code:**
```javascript
{qrCodeOpen && (
  <QRCodeModal
    visible={qrCodeOpen}
    onClose={() => setQRCodeOpen(false)}
    data={profile ? JSON.stringify(profile) : ''}
    title="Share Profile"
  />
)}
```

**Improvement:** Generate share link instead of raw profile:
```javascript
{qrCodeOpen && (
  <QRCodeModal
    visible={qrCodeOpen}
    onClose={() => setQRCodeOpen(false)}
    data={shareLink || ''}  // Use generated share link
    title="Scan to View Profile"
  />
)}
```

**Need to add:** shareLink state that gets set when share dialog generates a link.

---

## 🔧 TASK 3: ADD MARKDOWN SUPPORT

### Current Problem
Markdown components exist but aren't used. Entries use plain text.

### Changes Required

#### Step 1: Import Markdown Components
**Location:** Top of App.js (Line ~35)
```javascript
import { MarkdownField, MarkdownRenderer } from './src/components/Forms';
```

#### Step 2: Update EntryForm to Use Markdown
The EntryForm component needs to use MarkdownField for descriptions.

**Note:** This requires modifying UnifiedApp.js EntryForm component:
1. Replace TextInput for description with MarkdownField
2. Add markdown preview toggle
3. Support basic formatting (bold, italic, lists)

#### Step 3: Render Markdown in ProfileOverview
**Location:** ProfileOverview entry display (Line ~226-230)
**Current Code:**
```javascript
{entry.description && (
  <Text style={styles.entryDescription} numberOfLines={2}>
    {entry.description.replace(/<[^>]*>/g, '')}
  </Text>
)}
```

**Fix:** Use MarkdownRenderer:
```javascript
{entry.description && (
  <MarkdownRenderer 
    content={entry.description}
    style={styles.entryDescription}
    numberOfLines={2}
  />
)}
```

#### Step 4: Support Markdown in Print/Share
Ensure PrintPreview and share views properly render markdown:
- Convert markdown to HTML for web print
- Strip formatting for plain text shares
- Preserve formatting in PDF export

### Markdown Features to Support
- **Bold** text
- *Italic* text
- - Bullet lists
- 1. Numbered lists
- > Quotes
- Links (but sanitize for security)

---

## 📝 IMPLEMENTATION SEQUENCE

### Step 1: Print Feature (1 hour)
1. Add onPrintClick to Header props
2. Update Header.js with print menu item
3. Wire up PrintPreview component
4. Test print CSS and page breaks
5. Add print-specific styles

### Step 2: QR Integration (1 hour)
1. Decide integration approach (with Share or standalone)
2. Add QR trigger button
3. Generate proper share links for QR
4. Test QR code scanning
5. Ensure cross-platform compatibility

### Step 3: Markdown Support (1 hour)
1. Import Markdown components
2. Update EntryForm for markdown input
3. Update ProfileOverview for markdown display
4. Test formatting options
5. Ensure security (sanitize HTML)

---

## ✅ SUCCESS CRITERIA

### Print Preview
- [ ] Print button visible in header menu
- [ ] Preview shows formatted profile
- [ ] Categories properly paginated
- [ ] Print CSS optimized
- [ ] Works on both platforms
- [ ] Manila theme in preview

### QR Code Sharing
- [ ] QR accessible from share flow or menu
- [ ] QR contains valid share link
- [ ] QR scannable by standard readers
- [ ] Shows profile when scanned
- [ ] Includes encryption key in URL
- [ ] Mobile devices can scan

### Markdown Support
- [ ] Entry descriptions support markdown
- [ ] Preview available while typing
- [ ] Basic formatting works (bold, italic, lists)
- [ ] Renders properly in profile view
- [ ] Exports correctly in print/share
- [ ] Security: HTML sanitized

---

## 🐛 TROUBLESHOOTING

### Print Issues
```javascript
// Platform-specific handling
if (Platform.OS === 'web') {
  window.print();
} else {
  // Use react-native-print
  await Print.print({ html: generatedHTML });
}
```

### QR Code Problems
```javascript
// Ensure data is string
const qrData = typeof data === 'string' 
  ? data 
  : JSON.stringify(data);

// Limit QR data size (URLs are better than full JSON)
const maxQRLength = 2000; // characters
```

### Markdown Rendering
```javascript
// Sanitize markdown to prevent XSS
import DOMPurify from 'dompurify';
const sanitized = DOMPurify.sanitize(markdownHTML);

// For React Native, use react-native-markdown-display
```

---

## 📊 TESTING SEQUENCE

### Print Testing
1. Open print preview
2. Check layout and formatting
3. Test actual print (or PDF save)
4. Verify page breaks
5. Test with/without photos
6. Check mobile print options

### QR Testing
1. Generate QR code
2. Scan with phone camera
3. Verify link opens
4. Check profile loads correctly
5. Test encryption/decryption
6. Verify cross-device scanning

### Markdown Testing
1. Type **bold** and *italic* text
2. Create bullet lists
3. Test numbered lists
4. Add quotes
5. Preview while typing
6. Check render in profile view

---

## 🎨 STYLING GUIDELINES

### Print Styles
```css
@media print {
  .no-print { display: none; }
  .page-break { page-break-after: always; }
  body { 
    font-family: 'Atkinson Hyperlegible', sans-serif;
    color: black;
    background: white;
  }
  .header {
    background-color: #F4E4C1 !important;
    color: #8B7355 !important;
  }
}
```

### QR Code Display
- Center QR code in modal
- Include profile name as title
- Show share link below QR
- Copy button for link
- Download QR as image option

### Markdown Editor
- Split view: Edit | Preview
- Toolbar for formatting buttons
- Manila theme for toolbar
- Monospace font for editor
- Preview matches profile style

---

## 🚨 ARCHITECTURE REMINDERS

### Component Patterns
- PrintPreview follows UnifiedModal pattern
- QRCodeModal uses same structure
- MarkdownField consistent with other inputs
- All use IconProvider icons
- Manila brown headers (#8B7355)

### State Management
- Keep print state in App.js
- Share link state for QR reuse
- Markdown preview state local to form
- No new contexts needed

### Platform Considerations
- Web: window.print() and CSS @media
- iOS: react-native-print component
- QR: react-native-qrcode-svg (native)
- QR: qrcode.js (web)
- Markdown: Different libraries per platform

---

## 🎯 ADVANCED FEATURES (BONUS)

### If Time Permits
1. **PDF Export:** Generate downloadable PDF
2. **Email Share:** Send profile via email
3. **Markdown Tables:** Support table formatting
4. **Custom Print Templates:** Multiple layout options
5. **QR Customization:** Logo in center, colors

### Future Enhancements
- Cloud print services
- Batch printing multiple profiles
- Markdown templates/snippets
- QR code analytics
- Print history tracking

---

## 🎯 NEXT STEPS

Once Phase 3 is complete:
1. Commit: "Phase 3: Add Print, QR, and Markdown support"
2. Run full test suite on both platforms
3. Move to testing: [04_TESTING_CHECKLIST.md](./04_TESTING_CHECKLIST.md)
4. Deploy to qual for UAT

---

**CURRENT STATUS:** All components exist but need integration. Print and QR are straightforward. Markdown requires component updates but foundation exists!