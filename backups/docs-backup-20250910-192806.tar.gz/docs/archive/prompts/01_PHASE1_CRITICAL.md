# PHASE 1: CRITICAL FEATURES
## Share Dialog, Sync Dialog, and Theme Integration

### 🎯 OBJECTIVES
1. Fix Share Dialog button triggers
2. Fix Sync Dialog profile prop
3. Complete Theme color integration
4. Remove ALL hardcoded colors

**Time Estimate:** 2-3 hours  
**Priority:** HIGH - Core functionality

---

## 🔧 TASK 1: FIX SHARE DIALOG TRIGGERS

### Current Problem
Share buttons exist but don't open the dialog. The dialog is imported and state exists, but buttons aren't wired.

### Changes Required

#### Location 1: Header Share Button (Line ~496)
**Current Code:**
```javascript
onShare={() => setShareDialogOpen(true)}
```

**Status:** ✅ Already correct! Check if Header component is receiving this prop.

#### Location 2: ProfileOverview Share Button (Line ~509)
**Current Code:**
```javascript
onShare={() => setShareDialogOpen(true)}
```

**Status:** ✅ Already correct! 

#### Issue Investigation:
The problem might be in ProfileOverview component not calling the onShare prop.

**Check ProfileOverview (Line ~110-250):**
Look for where share button should trigger and ensure it calls `props.onShare()` or `onShare()`.

### Testing Share Dialog
1. Click share button in header
2. Click share button in profile
3. Dialog should open with:
   - Manila brown header
   - Share presets (Education, Support, Medical)
   - Category selection
   - Link generation

---

## 🔧 TASK 2: FIX SYNC DIALOG INTEGRATION

### Current Problem
SyncDialog is missing the profile prop but it doesn't actually need it based on the component interface.

### Changes Required

#### Location: Sync Dialog Component (Line ~566-572)
**Current Code:**
```javascript
{syncDialogOpen && (
  <SyncDialog
    open={syncDialogOpen}
    onClose={() => setSyncDialogOpen(false)}
    profile={profile}  // This line might not be needed
  />
)}
```

**Fix:** Remove the profile prop if SyncDialog doesn't use it:
```javascript
{syncDialogOpen && (
  <SyncDialog
    open={syncDialogOpen}
    onClose={() => setSyncDialogOpen(false)}
  />
)}
```

### Testing Sync Dialog
1. Click sync button in header (cloud icon)
2. Dialog should open with:
   - Recovery phrase display/input
   - Device pairing options
   - Sync status indicators

---

## 🔧 TASK 3: COMPLETE THEME INTEGRATION

### Current Problem
Colors are partially from theme but many are still hardcoded.

### Changes Required

#### Location 1: Remove Hardcoded Colors (Line ~87-106)
**Current Code:**
```javascript
// Default color constants (will be overridden by theme)
const defaultColors = {
  primary: '#8B7355',
  secondary: '#6B5D54',
  // ... more colors
};
```

**Fix:** This is fine as defaults, but ensure ALL components use theme colors.

#### Location 2: ProfileOverview Component (Line ~110-250)
**Current Issue:** May be using hardcoded styles

**Fix:** Ensure ProfileOverview receives and uses colors prop:
```javascript
<ProfileOverview
  // ... other props
  colors={colors}  // Line ~513 - already there ✅
/>
```

#### Location 3: Check ALL StyleSheet.create() calls
**Search for:** `backgroundColor:`, `color:`, `borderColor:`

**Replace patterns:**
```javascript
// ❌ WRONG
style={{ backgroundColor: '#8B7355' }}

// ✅ CORRECT
style={{ backgroundColor: colors.primary }}
```

### Key Color Replacements
| Hardcoded | Theme Variable |
|-----------|---------------|
| #8B7355 | colors.primary |
| #6B5D54 | colors.secondary |
| #F4E4C1 | colors.background.manila |
| #FDFBF7 | colors.background.default |
| #333333 | colors.text.primary |
| #666666 | colors.text.secondary |
| #4CAF50 | colors.success |
| #F44336 | colors.error |

---

## 🔧 TASK 4: VERIFY THEME TOGGLE

### Current State
Theme toggle button exists in Header but may not be working.

### Changes Required

#### Location: Header Component (Line ~493-502)
**Current Code:**
```javascript
<Header
  // ... other props
  onThemeToggle={toggleTheme}  // Line ~499
  theme={theme}                // Line ~500
  colors={colors}              // Line ~501
/>
```

**Status:** ✅ Props are passed correctly

#### Verify Header Implementation
Check that Header component:
1. Has theme toggle button
2. Calls `onThemeToggle` when clicked
3. Updates icon based on `theme` prop

### Testing Theme Toggle
1. Find theme toggle in header menu
2. Click to switch between light/dark/manila
3. All colors should update immediately
4. No hardcoded colors should remain

---

## 📝 COMPLETE IMPLEMENTATION CHECKLIST

### Step 1: Verify Share Dialog
```bash
# In App.js, check lines 557-563
# Ensure ShareDialogOptimized renders when shareDialogOpen is true
# Test: Click share buttons, dialog should open
```

### Step 2: Fix Sync Dialog
```bash
# In App.js, line 570
# Remove profile prop if not needed
# Test: Click sync button, dialog should open
```

### Step 3: Theme Colors
```bash
# Search entire App.js for color hex codes
# Replace ALL with theme variables
# Test: Toggle theme, ALL colors should change
```

### Step 4: Test Integration
```bash
# Run on web: npm run web
# Run on iOS: npm run ios
# Test all three features on both platforms
```

---

## ✅ SUCCESS CRITERIA

### Share Dialog
- [ ] Opens from header button
- [ ] Opens from profile button
- [ ] Shows share presets
- [ ] Generates encrypted links
- [ ] Copy link works
- [ ] QR code option visible

### Sync Dialog
- [ ] Opens from header sync button
- [ ] Shows recovery phrase
- [ ] Allows entering existing phrase
- [ ] Shows sync status
- [ ] No console errors

### Theme System
- [ ] Theme toggle button visible
- [ ] Switches between light/dark/manila
- [ ] NO hardcoded colors remain
- [ ] All components update instantly
- [ ] Colors persist on reload

---

## 🐛 TROUBLESHOOTING

### Dialog Won't Open
1. Check console for errors
2. Verify state variable name matches
3. Add console.log in button handler
4. Check if component is receiving props

### Theme Not Updating
1. Verify useTheme() is called in AppContent
2. Check createStyles() uses colors param
3. Search for hardcoded hex colors
4. Ensure styles are recreated on theme change

### Platform-Specific Issues
1. iOS: Check GestureHandlerRootView wrapper
2. Web: Check Material-UI theme provider
3. Both: Verify Platform.OS checks

---

## 📊 TESTING COMMANDS

### Quick Test Sequence
```bash
# 1. Start web dev
npm run web

# 2. Test features:
# - Click share button → dialog opens
# - Click sync button → dialog opens  
# - Click theme toggle → colors change

# 3. Start iOS dev
npm run ios

# 4. Repeat same tests on iOS
```

### Verification Checklist
```javascript
// Add temporary logging to verify
console.log('Share dialog state:', shareDialogOpen);
console.log('Sync dialog state:', syncDialogOpen);
console.log('Current theme:', theme);
console.log('Theme colors:', colors);
```

---

## 🎯 NEXT STEPS

Once Phase 1 is complete:
1. Commit changes with message: "Phase 1: Fix Share, Sync, and Theme integration"
2. Test thoroughly on both platforms
3. Move to Phase 2: [02_PHASE2_ENHANCED_UX.md](./02_PHASE2_ENHANCED_UX.md)

---

## 🚨 IMPORTANT REMINDERS

### DO:
- Use existing IconProvider icons
- Follow UnifiedModal pattern
- Test on BOTH platforms
- Use theme colors everywhere
- Keep all logic in App.js

### DON'T:
- Import Material-UI directly in App.js
- Create new color constants
- Add Cancel buttons to dialogs
- Split App.js into multiple files
- Skip Platform.OS checks

---

**CURRENT STATUS:** Components are imported and state exists. Just need to verify connections and remove hardcoded colors. This should be a quick fix!