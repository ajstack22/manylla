# Manylla Mobile Technology Stack & Compatibility Matrix

## Executive Summary

This document outlines the recommended technology stack for Manylla React Native mobile applications, ensuring compatibility with the existing React 19 web application while addressing critical requirements like zero-knowledge encryption, iOS UTF-8 compatibility, and offline-first architecture.

## 1. React & React Native Version Strategy

### 1.1 Current Web Stack
- **React**: 19.1.0 (Latest stable)
- **React DOM**: 19.1.0
- **React Scripts**: 5.0.1
- **TypeScript**: 4.9.5

### 1.2 Recommended React Native Version

**Primary Recommendation: React Native 0.76.x (Latest Stable)**

```json
{
  "react": "18.3.1",
  "react-native": "0.76.6"
}
```

**Rationale:**
- React Native 0.76 doesn't yet support React 19
- React 18.3.1 maintains compatibility with most React 19 patterns
- Stable ecosystem with mature libraries
- Full TypeScript 5.x support
- New Architecture (Fabric/TurboModules) enabled

**Migration Path:**
- Maintain React 19 on web
- Use React 18.3.1 for mobile (minimal API differences)
- Share business logic and types
- Upgrade to React 19 when RN supports it (estimated Q2 2025)

### 1.3 Breaking Changes & Considerations

| Feature | React 19 (Web) | React 18.3 (Mobile) | Impact |
|---------|---------------|-------------------|---------|
| Suspense | Full support | Full support | None |
| Server Components | Yes | No | Not needed for mobile |
| use() hook | Yes | No | Use alternatives |
| Concurrent Features | Enhanced | Available | Minimal difference |
| Automatic Batching | Default | Default | None |
| StrictMode | Double render | Double render | None |

## 2. Platform Requirements

### 2.1 iOS Requirements

**Minimum iOS Version: iOS 14.0**
- **Rationale**: 
  - 95%+ device coverage
  - Supports critical features (Widgets, App Clips)
  - Modern Swift/Objective-C runtime
  - Improved privacy features

**Xcode Requirements:**
- Xcode 15.0+ (required for iOS 17 SDK)
- macOS Sonoma 14.0+ recommended
- Swift 5.9+

### 2.2 Android Requirements

**Minimum API Level: 24 (Android 7.0 Nougat)**
- **Rationale**:
  - 94%+ device coverage
  - Native support for multi-window
  - Improved security features
  - Better performance for encryption

**Android Studio Requirements:**
- Android Studio Hedgehog (2023.1.1) or newer
- Gradle 8.0+
- Kotlin 1.9+

### 2.3 Platform-Specific Limitations

| Feature | iOS | Android | Solution |
|---------|-----|---------|----------|
| Background Sync | Limited (3-10 min) | WorkManager | Optimize sync intervals |
| Push Notifications | APNs required | FCM required | Implement both |
| Biometric Auth | Face ID/Touch ID | Fingerprint/Face | Unified API |
| File System | Sandboxed | Scoped Storage | Use proper APIs |
| Deep Linking | Universal Links | App Links | Configure both |

## 3. Encryption Library Compatibility

### 3.1 Critical Requirements
Based on StackMap's experience and Manylla's implementation:
- **MUST** support XSalsa20-Poly1305
- **MUST** handle manual UTF-8 encoding (iOS TextEncoder issues)
- **MUST** match web's 100,000 iteration key derivation
- **MUST** maintain bit-perfect encryption compatibility

### 3.2 Recommended: react-native-sodium

**Primary Choice: react-native-sodium**

```json
{
  "react-native-sodium": "^0.4.0"
}
```

**Advantages:**
- Native libsodium implementation (faster than JS)
- Supports all TweetNaCl operations
- Hardware acceleration where available
- Battle-tested in production apps
- Active maintenance

**Implementation Strategy:**
```javascript
// Wrapper to match web API exactly
class MobileEncryptionService {
  // Use react-native-sodium for crypto operations
  // BUT keep manual UTF-8 encoding from web
  encodeUTF8(str) {
    // Exact copy from web implementation
  }
  
  deriveKey(phrase) {
    // Use sodium.crypto_hash for iterations
    // Match web's 100,000 iterations exactly
  }
}
```

### 3.3 Fallback Option: tweetnacl-js

```json
{
  "tweetnacl": "^1.0.3",
  "tweetnacl-util": "^0.15.1"
}
```

**When to use:**
- Development/testing phase
- If native modules cause issues
- Exact same library as web (guaranteed compatibility)

### 3.4 iOS UTF-8 Encoding Solution

**Critical Implementation:**
```javascript
// MUST use this exact implementation from web
encodeUTF8(str) {
  const bytes = [];
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    if (char < 0x80) {
      bytes.push(char);
    } else if (char < 0x800) {
      bytes.push(0xc0 | (char >> 6));
      bytes.push(0x80 | (char & 0x3f));
    } else if (char < 0x10000) {
      bytes.push(0xe0 | (char >> 12));
      bytes.push(0x80 | ((char >> 6) & 0x3f));
      bytes.push(0x80 | (char & 0x3f));
    }
  }
  return new Uint8Array(bytes);
}
```

### 3.5 Secure Key Storage

**iOS: Keychain Services**
```json
{
  "react-native-keychain": "^8.2.0"
}
```

**Android: Android Keystore**
- Handled by react-native-keychain
- Hardware-backed encryption when available
- Biometric protection optional

## 4. Essential React Native Libraries

### 4.1 Navigation

**Recommended: React Navigation v6**
```json
{
  "@react-navigation/native": "^6.1.18",
  "@react-navigation/stack": "^6.4.1",
  "@react-navigation/bottom-tabs": "^6.6.1",
  "react-native-screens": "^3.35.0",
  "react-native-safe-area-context": "^4.14.0"
}
```

**Rationale:**
- JavaScript-based (easier debugging)
- Excellent TypeScript support
- Extensive documentation
- Large community
- Deep linking support built-in

### 4.2 State Management

**Recommended: Context API + Zustand (optional)**

```json
{
  "zustand": "^4.5.5"  // Optional for complex state
}
```

**Architecture:**
- Keep Context API for compatibility with web
- Add Zustand for complex offline queue management
- Share Context interfaces between web/mobile

### 4.3 Async Storage

**Recommended: @react-native-async-storage/async-storage**
```json
{
  "@react-native-async-storage/async-storage": "^2.1.0"
}
```

**Features:**
- 6MB limit on Android (unlimited on iOS)
- Automatic data migration
- Encrypted storage option
- AsyncStorage.multiSet for batch operations

### 4.4 Biometric Authentication

**Recommended: react-native-biometrics**
```json
{
  "react-native-biometrics": "^3.0.1"
}
```

**Features:**
- Unified API for Face ID/Touch ID/Fingerprint
- Fallback to device passcode
- Secure key generation
- Simple Promise-based API

### 4.5 Camera & Documents

**Recommended: react-native-image-picker + react-native-document-picker**
```json
{
  "react-native-image-picker": "^7.1.2",
  "react-native-document-picker": "^9.3.1",
  "react-native-vision-camera": "^4.6.1"  // For advanced camera features
}
```

### 4.6 File System

**Recommended: react-native-fs**
```json
{
  "react-native-fs": "^2.20.0"
}
```

**Features:**
- Read/write files
- Directory management
- Base64 encoding
- Progress callbacks

### 4.7 Networking

**Recommended: Built-in Fetch API**
- No additional library needed
- Compatible with web code
- Supports all required features

**Optional for advanced features:**
```json
{
  "react-native-background-fetch": "^4.2.5"  // Background sync
}
```

### 4.8 UI Component Libraries

**Recommended: Custom Components + React Native Elements**
```json
{
  "react-native-elements": "^3.4.3",
  "react-native-vector-icons": "^10.2.0",
  "react-native-paper": "^5.12.5"  // Alternative with MD3 support
}
```

**Strategy:**
- Build custom components matching Manylla's design
- Use library components for complex widgets
- Maintain visual consistency with web

### 4.9 Additional Essential Libraries

```json
{
  // Forms & Input
  "react-hook-form": "^7.54.2",
  "react-native-keyboard-aware-scroll-view": "^0.9.5",
  
  // Markdown & Rich Text
  "react-native-markdown-display": "^7.0.2",
  "@10play/react-native-rich-text-editor": "^1.0.0",
  
  // QR Codes
  "react-native-qrcode-svg": "^6.3.3",
  "react-native-camera": "^4.2.1",
  
  // Dates
  "react-native-date-picker": "^5.0.8",
  "date-fns": "^4.1.0",  // Same as web
  
  // Gestures & Animations
  "react-native-gesture-handler": "^2.22.0",
  "react-native-reanimated": "^3.17.0",
  "react-native-draggable-flatlist": "^4.0.1",
  
  // Development
  "react-native-flipper": "^0.212.0",
  "reactotron-react-native": "^5.1.10"
}
```

## 5. Development Environment Setup

### 5.1 Required Software

**macOS (for iOS development):**
- macOS Sonoma 14.0+
- Xcode 15.0+
- CocoaPods 1.15+
- Node.js 20 LTS
- Watchman (via Homebrew)
- Ruby 3.0+ (for CocoaPods)

**Windows/Linux (Android only):**
- Node.js 20 LTS
- Android Studio Hedgehog+
- Java 17 (Temurin recommended)
- Android SDK 34
- Watchman (recommended)

### 5.2 Recommended VS Code Extensions
```json
{
  "React Native Tools",
  "React Native Snippets",
  "TypeScript React Native Snippets",
  "Prettier",
  "ESLint",
  "GitLens"
}
```

### 5.3 React Native CLI vs Expo

**Recommendation: Bare React Native (No Expo)**

**Rationale:**
- Full control over native modules
- Required for custom encryption implementation
- Better performance for crypto operations
- No OTA update limitations
- Direct access to native APIs

**Development Workflow:**
```bash
# Initialize project
npx react-native init ManyllaMobile --template react-native-template-typescript

# iOS setup
cd ios && pod install

# Run development
npx react-native run-ios
npx react-native run-android
```

### 5.4 Testing Device Requirements

**Physical Devices (Recommended):**
- iPhone 12 or newer (iOS 14+)
- Android device with API 24+ 
- At least one tablet (iPad/Android)

**Emulators/Simulators:**
- iOS Simulator (comes with Xcode)
- Android Emulator (AVD with Google Play)
- Configure multiple screen sizes
- Test both light/dark modes

## 6. Build & Deployment Configuration

### 6.1 Build Tools

```json
{
  // package.json scripts
  "scripts": {
    "android": "react-native run-android",
    "ios": "react-native run-ios",
    "build:ios": "cd ios && xcodebuild -workspace Manylla.xcworkspace -scheme Manylla -configuration Release",
    "build:android": "cd android && ./gradlew assembleRelease",
    "bundle:android": "cd android && ./gradlew bundleRelease"
  }
}
```

### 6.2 CI/CD Recommendations

**Recommended: Fastlane + GitHub Actions**
```ruby
# Fastfile
platform :ios do
  lane :beta do
    build_app(scheme: "Manylla")
    upload_to_testflight
  end
end

platform :android do
  lane :beta do
    gradle(task: "bundle")
    upload_to_play_store(track: "internal")
  end
end
```

### 6.3 Code Signing & Distribution

**iOS:**
- Apple Developer Account ($99/year)
- Provisioning profiles
- App Store Connect
- TestFlight for beta testing

**Android:**
- Google Play Console ($25 one-time)
- Keystore for signing
- Play App Signing recommended
- Internal testing track

## 7. Performance Optimization Libraries

```json
{
  // Image Optimization
  "react-native-fast-image": "^8.6.3",
  
  // List Performance
  "react-native-super-grid": "^6.0.1",
  "@shopify/flash-list": "^1.7.2",
  
  // Memory Management
  "react-native-mmkv": "^3.1.0",  // Faster than AsyncStorage
  
  // Bundle Optimization
  "react-native-bundle-visualizer": "^3.1.3",
  "metro-minify-terser": "^0.80.12"
}
```

## 8. Security & Compliance Libraries

```json
{
  // Security
  "jail-monkey": "^2.8.0",  // Jailbreak/root detection
  "react-native-privacy-snapshot": "^1.0.0",  // Hide sensitive content
  "react-native-ssl-pinning": "^1.5.0",  // Certificate pinning
  
  // Compliance
  "react-native-permissions": "^4.2.0",  // Permission management
}
```

## 9. Library Compatibility Matrix

| Category | Web Library | Mobile Library | Compatibility |
|----------|------------|----------------|---------------|
| Encryption | tweetnacl | react-native-sodium | Wrapper needed |
| Storage | localStorage | AsyncStorage | API adapter required |
| Routing | React Router | React Navigation | Different paradigm |
| UI Framework | Material-UI | Native Elements | Custom components |
| Date Handling | date-fns | date-fns | 100% compatible |
| Markdown | @uiw/react-md-editor | react-native-markdown | Different API |
| HTTP | Fetch API | Fetch API | 100% compatible |
| State | Context API | Context API | 100% compatible |

## 10. Shared Code Strategy

### 10.1 Shareable Modules
```
shared/
├── types/           # 100% shareable
├── utils/           # 95% shareable
├── services/        # 80% shareable (with platform adapters)
├── constants/       # 100% shareable
└── validators/      # 100% shareable
```

### 10.2 Platform Adapters
```javascript
// Platform-specific implementations
interface StorageAdapter {
  getItem(key: string): Promise<string | null>;
  setItem(key: string, value: string): Promise<void>;
  removeItem(key: string): Promise<void>;
}

// Web implementation
class WebStorage implements StorageAdapter {
  async getItem(key) { return localStorage.getItem(key); }
  // ...
}

// Mobile implementation
class MobileStorage implements StorageAdapter {
  async getItem(key) { return AsyncStorage.getItem(key); }
  // ...
}
```

## 11. Development Tools & Debugging

### 11.1 Debugging Tools
- **Flipper**: Comprehensive debugging platform
- **React DevTools**: Component inspection
- **Reactotron**: State & API monitoring
- **Chrome DevTools**: Network & console
- **Safari Web Inspector**: iOS WebView debugging

### 11.2 Performance Monitoring
```json
{
  "react-native-performance": "^5.1.2",
  "@sentry/react-native": "^6.5.0",  // Error & performance tracking
}
```

## 12. Risk Mitigation

### 12.1 High-Risk Areas
1. **UTF-8 Encoding**: Must exactly match web implementation
2. **Key Derivation**: 100,000 iterations must be identical
3. **Encryption Compatibility**: Test extensively with web data
4. **Background Sync**: iOS limitations require careful design

### 12.2 Mitigation Strategies
- Create comprehensive test suite for encryption
- Build platform adapter layer for storage
- Implement progressive enhancement for features
- Use feature flags for gradual rollout
- Maintain web compatibility test suite

## Conclusion

This technology stack prioritizes:
1. **Compatibility**: Maximum code sharing with web
2. **Security**: Military-grade encryption maintained
3. **Performance**: Native performance where needed
4. **Reliability**: Battle-tested libraries only
5. **Maintainability**: Clear upgrade path

The recommended stack enables 70-80% code reuse from the web application while providing native performance and platform-specific optimizations. Critical attention must be paid to encryption compatibility, particularly the UTF-8 encoding implementation that caused issues in StackMap's iOS deployment.