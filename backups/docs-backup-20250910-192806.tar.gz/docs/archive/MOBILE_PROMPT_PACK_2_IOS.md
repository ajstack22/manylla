# Prompt Pack 2: iOS Native Development Master Plan

## Context for LLM
You are creating a comprehensive iOS development plan for Manylla using React Native. The app must maintain zero-knowledge encryption while leveraging iOS-specific features. You have access to the web codebase and the pre-work analysis from Prompt Pack 1.

## Prompt 1: iOS Platform Deep Dive

```
Create a comprehensive iOS platform analysis and implementation plan for Manylla:

1. **iOS Version & Device Support Matrix**
   - Minimum iOS version: iOS 14.0 (covers 95%+ of devices)
   - Document features available in iOS 14, 15, 16, 17, 18
   - Device compatibility: iPhone 6s and newer
   - iPad support requirements
   - Apple Watch companion app feasibility

2. **iOS-Specific Security Implementation**
   - Keychain Services integration for recovery phrase
   - Face ID / Touch ID implementation plan
   - App Transport Security configuration
   - iOS Data Protection classes usage
   - Secure Enclave utilization opportunities

3. **Critical iOS Libraries & Pods**
   Required CocoaPods:
   - react-native-keychain (recovery phrase storage)
   - react-native-biometrics (Face ID/Touch ID)
   - react-native-share (native share sheet)
   - react-native-document-picker (iCloud Drive integration)
   - Background Fetch configuration
   - Push notification setup (APNS)

4. **iOS App Architecture**
   - App Groups for data sharing (future Watch app)
   - Universal Links setup for share links
   - Widget Extension planning (iOS 14+)
   - Siri Shortcuts integration
   - iCloud sync considerations (as backup to custom sync)

Create "MANYLLA_IOS_PLATFORM_GUIDE.md" with implementation details.
```

## Prompt 2: iOS UI/UX Implementation

```
Design iOS-native UI patterns while maintaining Manylla's brand identity:

1. **Navigation Architecture**
   - Tab bar vs Navigation Controller patterns
   - Modal presentation styles (iOS 13+ card style)
   - SwiftUI interop possibilities
   - Safe area handling
   - Dynamic Island support (iPhone 14 Pro+)

2. **iOS Design Guidelines Compliance**
   - Human Interface Guidelines adherence
   - SF Symbols usage for icons
   - iOS-specific animations and transitions
   - Haptic feedback implementation
   - Dark mode / Light mode with system preference

3. **iOS-Specific UI Components**
   - Native action sheets vs custom modals
   - iOS date/time pickers
   - Context menus (iOS 13+)
   - Pull-to-refresh patterns
   - Keyboard toolbar implementation

4. **Accessibility Features**
   - VoiceOver support
   - Dynamic Type support
   - Reduce Motion support
   - Voice Control compatibility
   - Switch Control support

Create "MANYLLA_IOS_UI_SPECIFICATIONS.md" with component library.
```

## Prompt 3: iOS Data & Storage Strategy

```
Implement iOS-specific data management and storage:

1. **Keychain Services Implementation**
   ```swift
   // Example structure for Keychain storage
   - Recovery phrase (kSecAttrAccessibleWhenUnlockedThisDeviceOnly)
   - Biometric protection settings
   - Auto-lock timeout preferences
   ```

2. **Core Data vs AsyncStorage**
   - Evaluate Core Data for complex queries
   - AsyncStorage for React Native compatibility
   - File system for document storage
   - CloudKit for backup (optional)

3. **iOS Background Modes**
   - Background Fetch implementation (sync every 30 min)
   - Silent push notifications for sync triggers
   - Background URL sessions for large uploads
   - Location updates (if relevant for medical appointments)

4. **iOS Memory Management**
   - Implement proper memory cleanup for encryption
   - Image caching strategies
   - Document preview optimization
   - Memory pressure handling

Create "MANYLLA_IOS_DATA_ARCHITECTURE.md" with code examples.
```

## Prompt 4: iOS-Specific Features Implementation

```
Develop iOS-exclusive features that enhance the Manylla experience:

1. **iOS 14+ Widgets**
   - Today Widget: Quick view of important info
   - Lock Screen Widgets (iOS 16+)
   - Interactive Widgets (iOS 17+)
   - Widget deep linking to app sections

2. **Siri Shortcuts & Intents**
   - "Show my child's medical information"
   - "Add a note about [child's name]"
   - "Share information with doctor"
   - Custom voice commands setup

3. **Apple Watch Companion App**
   - Read-only view of critical information
   - Emergency contact display
   - Medication reminders
   - Sync via WatchConnectivity

4. **SharePlay & Collaboration (iOS 15+)**
   - Screen sharing during telehealth
   - Collaborative viewing with family
   - FaceTime integration possibilities

5. **Live Activities (iOS 16+)**
   - Appointment reminders
   - Medication schedules
   - Share link active status

Create "MANYLLA_IOS_FEATURES_ROADMAP.md" with implementation priorities.
```

## Prompt 5: iOS Testing & Deployment Strategy

```
Create comprehensive iOS testing and deployment plan:

1. **Testing Strategy**
   - Unit tests with Jest
   - UI tests with Detox or Appium
   - Manual test cases for iOS-specific features
   - TestFlight beta testing plan
   - Device testing matrix (various iPhones/iPads)

2. **Performance Benchmarks**
   - App launch time (< 2 seconds)
   - Encryption/decryption performance
   - Memory usage targets
   - Battery impact measurements
   - Network efficiency metrics

3. **App Store Optimization**
   - App Store Connect configuration
   - Screenshot requirements (all device sizes)
   - App Preview video planning
   - Keywords and description optimization
   - Age rating justification

4. **Release Strategy**
   - Phased rollout plan
   - A/B testing capabilities
   - Crash reporting (Crashlytics/Sentry)
   - Analytics implementation (privacy-focused)
   - Update adoption strategy

5. **iOS App Configuration**
   ```
   Info.plist requirements:
   - NSFaceIDUsageDescription
   - NSCameraUsageDescription
   - NSPhotoLibraryUsageDescription
   - UIBackgroundModes
   - Privacy nutrition labels
   ```

Create "MANYLLA_IOS_DEPLOYMENT_GUIDE.md" with checklist.
```

## Prompt 6: iOS Security Hardening

```
Implement iOS-specific security measures:

1. **Jailbreak Detection**
   - Implement jailbreak detection
   - Response strategy (warn vs block)
   - Anti-tampering measures

2. **Certificate Pinning**
   - SSL pinning implementation
   - Certificate rotation strategy
   - Fallback mechanisms

3. **App Integrity Checks**
   - Binary validation
   - Code signing verification
   - Anti-debugging measures

4. **Secure Communication**
   - End-to-end encryption maintenance
   - Man-in-the-middle prevention
   - Secure WebSocket implementation

Create "MANYLLA_IOS_SECURITY_CHECKLIST.md" with implementation code.
```

## Critical iOS Considerations

Point the LLM to these iOS-specific issues:

1. **UTF-8 Encoding Bug**: TweetNaCl-util returns strings instead of Uint8Arrays on iOS WebView. Must use manual UTF-8 implementation (see StackMap's encryptionServiceFixed.ts)

2. **AsyncStorage Performance**: Can freeze for 20+ seconds on iOS with large data. Implement debouncing and batch operations.

3. **Background Limitations**: iOS strictly limits background execution. Plan around 30-second windows.

4. **Keychain Sharing**: If planning Apple Watch app, configure Keychain sharing via App Groups early.

5. **Push Notifications**: Requires Apple Developer Program membership ($99/year).

## Key iOS Files to Reference

From StackMap implementation:
- `/Users/adamstack/StackMap/StackMap/ios/` - iOS-specific code
- Manual UTF-8 implementation for iOS compatibility
- Keychain integration patterns
- Background fetch configuration

## Expected iOS Deliverables

The LLM should create:
1. MANYLLA_IOS_PLATFORM_GUIDE.md
2. MANYLLA_IOS_UI_SPECIFICATIONS.md  
3. MANYLLA_IOS_DATA_ARCHITECTURE.md
4. MANYLLA_IOS_FEATURES_ROADMAP.md
5. MANYLLA_IOS_DEPLOYMENT_GUIDE.md
6. MANYLLA_IOS_SECURITY_CHECKLIST.md

## iOS Success Metrics

- App size under 50MB
- Cold start under 2 seconds
- Encryption operations under 100ms
- Battery drain less than 2% per hour active use
- 4.5+ star App Store rating target
- 99.9% crash-free rate