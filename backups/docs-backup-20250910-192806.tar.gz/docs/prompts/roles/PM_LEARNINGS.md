# PM Role - Learnings & Best Practices

## Last Updated: 2025-09-10

### 🎯 Purpose
Capture institutional knowledge from PM role sessions to guide future project management.

---

## ✅ Successful Patterns

### Prompt Pack Management
- Use priority prefixes: `01-critical`, `02-high`, `03-medium`, `04-low`
- Archive completed packs immediately after validation
- Include specific file paths and line numbers in prompts
- Always define clear acceptance criteria

### Work Assignment
- **Developer**: Application code, bug fixes, feature implementation
- **Admin**: Scripts, deployment, infrastructure, process improvements
- **Peer Reviewer**: Critical changes, architecture decisions, security-sensitive code
- Fresh context per task is better than accumulated history

### Priority Management
- Production bugs always take precedence
- Rename files to reorder priorities (e.g., 02 → 03 when inserting urgent work)
- Keep no more than 7 active prompt packs
- Low priority (07+) for research/future enhancements

### Quality Gates
```bash
# Must pass before marking complete
find src -name "*.tsx" -o -name "*.ts" | wc -l          # Must be 0
find src -name "*.native.*" -o -name "*.web.*" | wc -l  # Must be 0
npm run build:web                                        # Must succeed
npx prettier --check 'src/**/*.js'                      # Must pass
```

---

## ⚠️ Common Pitfalls

### Deployment Process
- Never bypass validation checks
- Deploy script requires committed changes
- GitHub push should happen BEFORE qual deployment (being fixed)
- Build outputs to `web/build/` not `build/`

### Prompt Pack Creation
- Don't create packs without clear acceptance criteria
- Avoid combining unrelated changes in one pack
- Remember to assign role explicitly in pack
- Update time estimates realistically

### Communication
- Over-communication is better than under
- Document decisions in prompt packs
- Update DEPLOYMENT_STATUS.md after major changes
- Keep release notes current

---

## 🔧 Useful Commands

### Status Monitoring
```bash
# Check active work
ls docs/prompts/active/

# Count TypeScript contamination
find src -name "*.tsx" -o -name "*.ts" | wc -l

# Material-UI usage
grep -r "@mui/material" src/ | wc -l

# Recent commits
git log --oneline -10
```

### Prompt Pack Operations
```bash
# Create new pack
./scripts/create-prompt-pack.sh [priority] [name]

# Archive completed
mv docs/prompts/active/[file].md docs/prompts/archive/

# Reorder priorities
cd docs/prompts/active
mv 02-task.md 03-task.md  # Demote priority
```

---

## 📝 Session Notes

### 2025-09-10 - Production Deployment
- Successful TypeScript cleanup unblocked deployment
- Discovered missing demo data in production
- Found 404 errors for resources
- Created emergency fix packs for production issues

### 2025-09-10 - Process Improvement
- Identified GitHub push should precede deployment
- Created role learnings documentation process
- Evaluated Claude Swarm for future automation

---

## 🚀 Decision Framework

### When to Escalate to User
- Major architecture changes
- Production deployment approval
- Budget/resource decisions
- Feature removal
- Breaking changes

### When to Request Peer Review
- Critical bug fixes
- Security-sensitive changes
- Architecture modifications
- Process changes affecting team
- Deployment script modifications

### When to Fast-Track
- Production down
- Security vulnerabilities
- Data loss risk
- User-facing critical bugs
- Deployment blockers

---

## 📊 Metrics to Track

### Health Indicators
- Zero TypeScript files ✅
- Zero platform-specific files ✅
- Build succeeds ✅
- All tests pass
- < 20 TODOs in codebase
- < 5 console.logs in src/

### Process Metrics
- Time from pack creation to completion
- Number of validation failures
- Rollback frequency
- Active pack count (target < 7)

---

## 🎯 Strategic Priorities

### Phase 3 (Current)
1. Stabilize production deployment
2. Fix all critical bugs
3. Complete UI consistency
4. Remove Material-UI completely

### Phase 4 (Next)
1. Performance optimization
2. Enhanced sync features
3. Mobile app deployment
4. Consider automation tools (Claude Swarm)

---

## 📚 Reference Documents
- `/docs/WORKING_AGREEMENTS.md` - Team standards
- `/docs/prompts/active/` - Current work queue
- `/docs/prompts/archive/` - Completed work
- `/DEPLOYMENT_STATUS.md` - System health