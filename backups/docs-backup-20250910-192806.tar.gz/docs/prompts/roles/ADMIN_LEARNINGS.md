# Admin Role - Learnings & Best Practices

## Last Updated: 2025-09-10

### 🎯 Purpose
Capture institutional knowledge from Admin role sessions for infrastructure and deployment management.

---

## ✅ Successful Patterns

### Deployment Process
- **Script location**: `./scripts/deploy-qual.sh`
- **Build directory**: `web/build/` (NOT `build/`)
- **Correct .htaccess**: Use `.htaccess.manylla-qual` not `.htaccess.qual`
- Always commit before deploying (script requirement)
- Maximum 20 TODOs and 5 console.logs allowed

### SSH & Server Access
```bash
# SSH alias configured
ssh stackmap-cpanel

# Deployment path
~/public_html/manylla/qual/  # NOT ~/public_html/qual/

# Database
stachblx_manylla_sync_qual
```

### Environment Management
- Qual URL: https://manylla.com/qual/
- API endpoints: https://manylla.com/qual/api/
- RewriteBase: `/manylla/qual/` in .htaccess

---

## ⚠️ Common Pitfalls

### Deployment Issues
- Wrong build directory (`build/` instead of `web/build/`)
- Wrong .htaccess file (StackMap's instead of Manylla's)
- Uncommitted changes blocking deployment
- Missing NODE_OPTIONS for large builds

### Server Configuration
- Manylla is subfolder of StackMap's hosting
- Different .htaccess files for different projects
- Path confusion between `/qual/` and `/manylla/qual/`

### Script Failures
```bash
# If build fails with memory error
NODE_OPTIONS=--max-old-space-size=8192 npm run build:web

# If rsync fails
Check SSH key: ~/.ssh/config for stackmap-cpanel

# If validation fails
Fix issues first, don't bypass checks
```

---

## 🔧 Useful Commands

### Deployment Operations
```bash
# Full deployment with validation
./scripts/deploy-qual.sh

# Manual deployment (emergency only)
npm run build:web
rsync -avz web/build/ stackmap-cpanel:~/public_html/manylla/qual/

# Check deployment
curl https://manylla.com/qual/api/sync_health.php
```

### Server Management
```bash
# SSH to server
ssh stackmap-cpanel

# Check error logs
ssh stackmap-cpanel "tail -f ~/public_html/manylla/qual/error_log"

# Database access
mysql -h localhost -u stachblx_manylla -p stachblx_manylla_sync_qual
```

### Validation Checks
```bash
# Pre-deployment validation
grep -r "console.log" src/ | grep -v "^//" | wc -l  # Max 5
grep -r "TODO" src/ | wc -l  # Max 20
find src -name "*.tsx" -o -name "*.ts" | wc -l  # Must be 0
```

---

## 📝 Session Notes

### 2025-09-10 - Deployment Path Issues
- Discovered Manylla deploys to subfolder not root
- Different .htaccess files for different projects
- Build output confusion between `build/` and `web/build/`

### Infrastructure Setup
- Database: stachblx_manylla_sync_qual
- Tables: sync_data, shares, sync_backups, active_shares, audit_log
- API endpoints operational at /qual/api/

---

## 🚀 Process Improvements

### Current Deployment Flow
1. Developer commits changes locally
2. Run `./scripts/deploy-qual.sh`
3. Script validates (lint, TypeScript, security)
4. Build production bundle
5. Deploy to qual server
6. (Optional) Push to GitHub

### Proposed Improvement (In Progress)
1. Developer commits locally
2. Run validations
3. **Push to GitHub** (checkpoint)
4. Deploy to qual
5. Rollback available from GitHub if needed

---

## 🔐 Security Considerations

### Never Deploy
- Files with console.log in production paths
- Uncommitted changes
- Failed validation checks
- Secrets or API keys in code

### Always Check
- No sensitive data in commits
- API endpoints properly secured
- Database credentials in config only
- Error logs don't expose system info

---

## 📊 System Health Monitoring

### Health Check Endpoints
```bash
# API health
curl https://manylla.com/qual/api/sync_health.php

# Full system check
./scripts/health-check.sh
```

### Key Metrics
- Build size (check if growing unexpectedly)
- Deployment time (should be < 2 minutes)
- API response times
- Error log frequency

---

## 🛠️ Troubleshooting Guide

### Build Failures
| Error | Solution |
|-------|----------|
| Out of memory | `NODE_OPTIONS=--max-old-space-size=8192 npm run build:web` |
| Module not found | `npm install` then rebuild |
| Prettier fails | `npx prettier --write 'src/**/*.js'` |

### Deployment Failures
| Error | Solution |
|-------|----------|
| Uncommitted changes | Commit or stash changes |
| SSH key error | Check `~/.ssh/config` for stackmap-cpanel |
| rsync fails | Verify server path and permissions |
| Wrong directory | Use `web/build/` not `build/` |

### Server Issues
| Error | Solution |
|-------|----------|
| 404 errors | Check .htaccess RewriteBase |
| 500 errors | Check error_log on server |
| API fails | Verify database connection |

---

## 📚 Reference Documents
- `/scripts/deploy-qual.sh` - Deployment script
- `/CLAUDE.md` - Deployment instructions
- `/public/.htaccess.manylla-qual` - Correct htaccess
- `/docs/WORKING_AGREEMENTS.md` - Standards