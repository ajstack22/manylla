<?php
/**
 * Production Health Check Endpoint
 * Returns API status and database connection test
 */

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");

require_once __DIR__ . "/config/config.prod.php";

$response = [
    "status" => "healthy",
    "timestamp" => time(),
    "environment" => API_ENV,
    "version" => API_VERSION,
    "database" => "unknown"
];

// Test database connection
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    
    // Test a simple query
    $stmt = $pdo->query("SELECT COUNT(*) as table_count FROM information_schema.tables WHERE table_schema = 'stachblx_manylla_sync_prod'");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $response["database"] = "connected";
    $response["database_name"] = DB_NAME;
    $response["tables_count"] = (int)$result["table_count"];
    
} catch (PDOException $e) {
    $response["database"] = "error";
    $response["status"] = "unhealthy";
    // Don't expose error details in production
    if (API_DEBUG) {
        $response["database_error"] = $e->getMessage();
    }
}

http_response_code($response["status"] === "healthy" ? 200 : 503);
echo json_encode($response, JSON_PRETTY_PRINT);
?>
