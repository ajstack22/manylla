/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.8-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: stachblx_manylla_sync_prod
-- ------------------------------------------------------
-- Server version	11.4.8-MariaDB-cll-lve-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `share_links`
--

DROP TABLE IF EXISTS `share_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `share_links` (
  `access_code` varchar(16) NOT NULL,
  `encrypted_data` mediumtext NOT NULL,
  `recipient_type` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `access_count` int(11) DEFAULT 0,
  `last_accessed` timestamp NULL DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  PRIMARY KEY (`access_code`),
  KEY `idx_expires_shares` (`expires_at`),
  KEY `idx_recipient` (`recipient_type`),
  KEY `idx_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `share_links`
--

LOCK TABLES `share_links` WRITE;
/*!40000 ALTER TABLE `share_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `share_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_backups`
--

DROP TABLE IF EXISTS `sync_backups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_backups` (
  `backup_id` int(11) NOT NULL AUTO_INCREMENT,
  `sync_id` varchar(32) NOT NULL,
  `device_id` varchar(32) NOT NULL,
  `encrypted_blob` mediumtext NOT NULL,
  `blob_hash` varchar(64) NOT NULL,
  `version` int(11) NOT NULL,
  `timestamp` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `is_auto_backup` tinyint(1) DEFAULT 0,
  `backup_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`backup_id`),
  KEY `idx_sync_backups` (`sync_id`,`created_at`),
  KEY `idx_device_backups` (`device_id`),
  KEY `idx_version_backups` (`version`),
  CONSTRAINT `fk_backup_sync_group` FOREIGN KEY (`sync_id`) REFERENCES `sync_groups` (`sync_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_backups`
--

LOCK TABLES `sync_backups` WRITE;
/*!40000 ALTER TABLE `sync_backups` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_backups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_data`
--

DROP TABLE IF EXISTS `sync_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_data` (
  `sync_id` varchar(32) NOT NULL,
  `device_id` varchar(32) NOT NULL,
  `encrypted_blob` mediumtext NOT NULL,
  `blob_hash` varchar(64) NOT NULL,
  `version` int(11) NOT NULL DEFAULT 1,
  `timestamp` bigint(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`sync_id`),
  KEY `idx_sync_timestamp` (`sync_id`,`timestamp`),
  KEY `idx_device` (`device_id`),
  KEY `idx_version` (`version`),
  KEY `idx_hash` (`blob_hash`),
  CONSTRAINT `fk_sync_group` FOREIGN KEY (`sync_id`) REFERENCES `sync_groups` (`sync_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_data`
--

LOCK TABLES `sync_data` WRITE;
/*!40000 ALTER TABLE `sync_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_groups`
--

DROP TABLE IF EXISTS `sync_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_groups` (
  `sync_id` varchar(32) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  PRIMARY KEY (`sync_id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_updated` (`updated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_groups`
--

LOCK TABLES `sync_groups` WRITE;
/*!40000 ALTER TABLE `sync_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_invites`
--

DROP TABLE IF EXISTS `sync_invites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sync_invites` (
  `invite_code` varchar(16) NOT NULL,
  `sync_id` varchar(32) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `expires_at` timestamp NULL DEFAULT NULL,
  `max_uses` int(11) DEFAULT 1,
  `uses_count` int(11) DEFAULT 0,
  `created_by` varchar(32) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`invite_code`),
  KEY `idx_sync_invites` (`sync_id`),
  KEY `idx_expires` (`expires_at`),
  KEY `idx_active_invites` (`is_active`),
  CONSTRAINT `fk_invite_sync_group` FOREIGN KEY (`sync_id`) REFERENCES `sync_groups` (`sync_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_invites`
--

LOCK TABLES `sync_invites` WRITE;
/*!40000 ALTER TABLE `sync_invites` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_invites` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-10-15 13:41:46
