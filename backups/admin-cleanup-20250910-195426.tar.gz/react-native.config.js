module.exports = {
  project: {
    ios: {},
    android: {},
  },
  // Auto-linking handles fonts now, no manual assets needed
  assets: [],
};