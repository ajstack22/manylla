# Admin Troubleshooting Guide

## Quick Reference - Common Issues

### Deployment Issues

#### 🔴 Critical: Version Mismatch
**Error**: "Release notes not updated for version X"
```bash
# Script auto-increments version - add notes for NEXT version
echo "## Version 2025.09.10.6" >> RELEASE_NOTES.md
echo "Description of changes" >> RELEASE_NOTES.md
```

#### 🔴 Critical: Wrong Directory 
**NEVER** deploy from `build/` - always use `web/build/`
```bash
# Correct
rsync -avz web/build/ stackmap-cpanel:~/public_html/manylla/qual/

# Wrong - will deploy old files
rsync -avz build/ stackmap-cpanel:~/public_html/manylla/qual/
```

#### 🔴 Critical: Wrong .htaccess
```bash
# Manylla uses different paths than StackMap
# Correct for Manylla
scp public/.htaccess.manylla-qual stackmap-cpanel:~/public_html/manylla/qual/.htaccess

# Wrong - StackMap's file
scp public/.htaccess.qual stackmap-cpanel:~/public_html/manylla/qual/.htaccess
```

### Port Conflicts

#### Port 3000 Already in Use
```bash
# Quick fix - find and kill
lsof -ti:3000 | xargs kill -9

# Or use different port
PORT=3001 npm run web
```

#### Multiple Node Processes
```bash
# Nuclear option - kill all Node
pkill -f node

# Check what's running
ps aux | grep node
```

### Memory Issues

#### Build Out of Memory
```bash
# Already set in deploy script, but if manual:
export NODE_OPTIONS=--max-old-space-size=8192
npm run build:web

# Still failing? Go bigger:
NODE_OPTIONS=--max-old-space-size=16384 npm run build:web
```

#### System Running Slow
```bash
# Check memory usage
free -h          # Linux
vm_stat          # macOS

# Clear npm cache
npm cache clean --force

# Remove old builds
rm -rf web/build.old
rm -rf node_modules/.cache
```

### Git Issues

#### Uncommitted Changes Blocking Deploy
```bash
# See what's uncommitted
git status

# Quick stash
git stash push -m "temp for deployment"

# Deploy, then restore
git stash pop
```

#### Can't Push to GitHub
```bash
# Pull first
git pull origin main --rebase

# Force push (careful!)
git push origin main --force
```

### Build Failures

#### Module Not Found
```bash
# Clean reinstall
rm -rf node_modules package-lock.json
npm install
```

#### TypeScript Errors
```bash
# Check errors
npm run typecheck

# Often fixes itself with clean install
rm -rf node_modules
npm install
```

#### Prettier Failures
```bash
# Auto-fix
npx prettier --write "src/**/*.{js,jsx,ts,tsx}"
```

### Server Issues

#### Can't Connect via SSH
```bash
# Check SSH config exists
cat ~/.ssh/config | grep stackmap-cpanel

# Test connection
ssh stackmap-cpanel "echo 'Connected'"

# If fails, check VPN/network
ping manylla.com
```

#### API Returns 404
```bash
# Check if API files deployed
ssh stackmap-cpanel "ls -la ~/public_html/manylla/qual/api/"

# Check .htaccess isn't blocking
ssh stackmap-cpanel "cat ~/public_html/manylla/qual/.htaccess"
```

#### Site Not Loading
```bash
# Check if files deployed
ssh stackmap-cpanel "ls -la ~/public_html/manylla/qual/"

# Check error logs
ssh stackmap-cpanel "tail -50 ~/public_html/manylla/qual/error_log"

# Check permissions
ssh stackmap-cpanel "ls -la ~/public_html/manylla/qual/index.html"
```

## Emergency Procedures

### Site is Down - Quick Recovery

```bash
# 1. Check if server is up
curl -I https://manylla.com/qual/

# 2. If down, SSH and check
ssh stackmap-cpanel
cd ~/public_html/manylla/qual/
ls -la

# 3. If files missing, emergency deploy
cd /Users/adamstack/manylla
NODE_OPTIONS=--max-old-space-size=8192 npm run build:web
rsync -avz web/build/ stackmap-cpanel:~/public_html/manylla/qual/

# 4. Verify
curl https://manylla.com/qual/
```

### Deployment Script Broken

```bash
# Manual deployment (emergency only)
# 1. Build
NODE_OPTIONS=--max-old-space-size=8192 npm run build:web

# 2. Clean remote
ssh stackmap-cpanel "cd ~/public_html/manylla/qual && rm -rf *.js *.css"

# 3. Deploy
rsync -avz --delete web/build/ stackmap-cpanel:~/public_html/manylla/qual/

# 4. Fix .htaccess
scp public/.htaccess.manylla-qual stackmap-cpanel:~/public_html/manylla/qual/.htaccess

# 5. Set permissions
ssh stackmap-cpanel "chmod 755 ~/public_html/manylla/qual/"
```

### Rollback After Bad Deploy

```bash
# 1. Find last good commit
git log --oneline -5

# 2. Revert
git revert HEAD
git push

# 3. Rebuild and deploy
./scripts/deploy-qual.sh
```

### Disk Space Emergency

```bash
# Local cleanup
du -sh */
rm -rf node_modules/.cache
rm -rf web/build.old
npm cache clean --force

# Server cleanup
ssh stackmap-cpanel
du -sh ~/public_html/*/
# Remove old backups if needed
rm -rf ~/backups/manylla/old-*
```

## Validation Bypasses (USE WITH EXTREME CAUTION)

### Skip Specific Checks (NOT RECOMMENDED)

These should NEVER be used in normal circumstances:

```bash
# Force commit despite warnings
git commit --no-verify -m "Emergency fix"

# Skip prettier
touch .prettierignore
echo "src/**" >> .prettierignore

# Ignore lint errors temporarily
# Add to top of problematic file:
/* eslint-disable */

# Skip TypeScript checks
# In tsconfig.json, set:
"skipLibCheck": true
```

**WARNING**: These bypasses compromise code quality. Always fix properly after emergency.

## Quick Health Checks

### Full System Check
```bash
# 1. Local environment
node --version          # Should be 16+
npm --version           # Should be 8+
git status              # Should be clean

# 2. Can build?
npm run build:web

# 3. Can reach server?
ssh stackmap-cpanel "echo 'SSH OK'"

# 4. Site responding?
curl -s -o /dev/null -w "%{http_code}" https://manylla.com/qual/

# 5. API working?
curl https://manylla.com/qual/api/sync_health.php
```

### Pre-Deployment Checklist
```bash
# Run this before deploying
echo "=== Pre-Deploy Check ==="
git status
npm run lint 2>&1 | grep -c "0 errors" && echo "✓ Lint OK" || echo "✗ Lint errors"
npm run typecheck 2>&1 | grep -c "error TS" && echo "✗ TS errors" || echo "✓ TypeScript OK"
grep -r "console\.log" src/ --include="*.js" --include="*.tsx" | wc -l
grep -r "TODO\|FIXME" src/ | wc -l
echo "=== End Check ==="
```

## Common Error Messages Decoded

| Error | Meaning | Fix |
|-------|---------|-----|
| "EADDRINUSE" | Port in use | `lsof -ti:3000 \| xargs kill -9` |
| "EACCES" | Permission denied | Check file ownership |
| "ENOENT" | File not found | Check path exists |
| "ENOMEM" | Out of memory | Increase NODE_OPTIONS |
| "MODULE_NOT_FOUND" | Missing dependency | `npm install` |
| "Cannot find module" | Import path wrong | Check relative paths |
| "Unexpected token" | Syntax error | Check for typos |
| "heap out of memory" | Build too large | Increase memory limit |

## Contact Points

### When to Escalate

Escalate if:
- Deployment blocked > 30 minutes
- Production site down
- Data loss suspected
- Security issue found
- Can't resolve with this guide

### Logs to Check

1. **Build Log**: Terminal output from npm run build
2. **Deploy Log**: Output from ./scripts/deploy-qual.sh
3. **Server Error Log**: `~/public_html/manylla/qual/error_log`
4. **Browser Console**: Check for client-side errors
5. **Network Tab**: Check for failed requests

## Prevention Tips

### Daily Routine
- Start with clean git status
- Pull latest changes
- Clear node_modules weekly
- Update dependencies monthly

### Before Major Changes
- Create backup branch
- Test in development first
- Document changes in RELEASE_NOTES
- Inform team of deployment

### After Deployment
- Test critical paths
- Check error logs
- Monitor for 10 minutes
- Document any issues

---

*Quick Admin Command:*
```bash
alias manylla-health='curl -s https://manylla.com/qual/ > /dev/null && echo "✓ Site OK" || echo "✗ Site Down"'
alias manylla-deploy='cd /Users/adamstack/manylla && ./scripts/deploy-qual.sh'
alias manylla-logs='ssh stackmap-cpanel "tail -f ~/public_html/manylla/qual/error_log"'
```

*Last Updated: 2025-09-10*