# Deployment Process Documentation

## Overview
The Manylla deployment system uses an enhanced validation script (`./scripts/deploy-qual.sh`) that enforces quality checks before deployment. This document captures key learnings and troubleshooting guides.

## Deployment Script Behavior

### Version Management
The deployment script **automatically increments** the version number using the following logic:

1. **Current Version**: Read from `package.json`
2. **Version Format**: `YYYY.MM.DD.BUILD`
3. **Increment Logic**:
   - If deploying on the same day: Increment BUILD number
   - If deploying on a new day: Reset BUILD to 1
4. **Example**: 
   - Current: `2025.09.10.5`
   - Next (same day): `2025.09.10.6`
   - Next (new day): `2025.09.11.1`

### Pre-Deployment Requirements

#### Release Notes
**CRITICAL**: The script expects release notes for the **NEW** version (not current version).

```markdown
## Version 2025.09.10.6
Title/Description of changes

### Changes
- List of changes
```

**Location Priority**:
1. First checks: `docs/RELEASE_NOTES.md`
2. Fallback: `RELEASE_NOTES.md` (root)

**Note**: If `docs/` is gitignored, maintain `RELEASE_NOTES.md` in root.

### Validation Phases

#### Phase 1: Pre-Commit Validation
All checks must pass BEFORE any commits:

1. **Working Directory**: Must be clean (no uncommitted changes)
2. **Release Notes**: Entry for NEW version must exist
3. **Code Formatting**: Prettier check (auto-fixes if needed)
4. **License Compliance**: Checks for outdated license documentation
5. **Security**: No critical vulnerabilities (`npm audit`)
6. **Linting**: ESLint must pass (0 errors allowed)
7. **TypeScript**: Type checking must pass
8. **Code Quality**:
   - Maximum 20 TODO/FIXME comments
   - Maximum 5 console.log statements
   - Zero debugger statements
   - No hardcoded secrets
9. **Dependencies**: Checks for unused/circular dependencies
10. **Bundle Size**: Pre-check warning

#### Phase 2: Version Update & Commit
Only if validation passes:
- Updates `package.json` with new version
- Commits with message: `v{VERSION}: {RELEASE_TITLE}`
- Pushes to GitHub (creates rollback point)

#### Phase 3: Web Deployment
- Builds with `NODE_OPTIONS=--max-old-space-size=8192`
- Uses `web/build/` directory (NOT `build/`)
- Deploys to `https://manylla.com/qual/`
- Copies correct `.htaccess.manylla-qual` file

#### Phase 4: Mobile Deployment (Optional)
- Deploys to running iOS simulators
- Deploys to connected Android devices

## Common Issues & Solutions

### Issue: "Release notes not updated for version X"

**Symptom**: 
```
❌ DEPLOYMENT BLOCKED: Release notes not updated for version 2025.09.10.6
```

**Cause**: Script increments version and expects release notes for the NEW version.

**Solution**:
1. Add release notes for the NEXT version (not current)
2. Include at minimum:
   ```markdown
   ## Version 2025.09.10.6
   Brief description of changes
   ```

### Issue: "Uncommitted changes detected"

**Solution**:
```bash
# Check what's uncommitted
git status

# Option 1: Commit changes
git add .
git commit -m "description"

# Option 2: Stash changes
git stash
```

### Issue: "Too many console.log statements"

**Solution**:
```bash
# Find console.logs
grep -r "console\.log" src/ --include="*.js" --include="*.ts" --include="*.tsx" | grep -v '^\s*//'

# Remove or comment them out
```

### Issue: "ESLint errors detected"

**Solution**:
```bash
# See specific errors
npm run lint

# Auto-fix what's possible
npm run lint -- --fix
```

### Issue: Build Memory Errors

**Symptom**: "JavaScript heap out of memory"

**Solution**: Script already uses `NODE_OPTIONS=--max-old-space-size=8192`

If still failing:
```bash
# Manually build with more memory
NODE_OPTIONS=--max-old-space-size=16384 npm run build:web
```

### Issue: Wrong Build Directory

**CRITICAL**: Manylla uses `web/build/` not `build/`

The deployment script correctly uses:
```bash
rsync -avz web/build/ stackmap-cpanel:~/public_html/manylla/qual/
```

Never deploy from `build/` directory - it contains old static files.

### Issue: Wrong .htaccess File

**CRITICAL**: Use Manylla-specific .htaccess

- ✅ Correct: `public/.htaccess.manylla-qual`
- ❌ Wrong: `public/.htaccess.qual` (that's for StackMap)

Manylla requires `/manylla/qual/` paths, not `/qual/` paths.

## Manual Deployment (Emergency Only)

If the script fails and emergency deployment is needed:

```bash
# 1. Build locally
NODE_OPTIONS=--max-old-space-size=8192 npm run build:web

# 2. Deploy files
rsync -avz web/build/ stackmap-cpanel:~/public_html/manylla/qual/

# 3. Deploy .htaccess
scp public/.htaccess.manylla-qual stackmap-cpanel:~/public_html/manylla/qual/.htaccess

# 4. Verify
curl -I https://manylla.com/qual/
```

**WARNING**: Manual deployment bypasses all quality checks. Use only in emergencies.

## Best Practices

### Before Deployment
1. **Commit all changes** before running deployment script
2. **Write release notes** for the NEXT version
3. **Run local tests**: `npm test`
4. **Check lint**: `npm run lint`
5. **Verify build works**: `npm run build:web`

### Release Notes Format
```markdown
## Version YYYY.MM.DD.N
One-line summary (becomes commit message)

### Changed/Fixed/Added
- Bullet points of changes
- Be specific about what changed
- Include any breaking changes

### Technical (optional)
- Implementation details
- Architecture changes
- Performance improvements
```

### Version Numbering
- Let the script handle version increments
- Don't manually edit version in package.json
- Script will auto-increment based on date/build

### Deployment Frequency
- Deploy completed features, not partial work
- Consolidate small fixes into single deployment
- Always test locally first

## Monitoring Post-Deployment

### Health Checks
```bash
# Web application
curl https://manylla.com/qual/

# API endpoint
curl https://manylla.com/qual/api/sync_health.php

# Check for errors
ssh stackmap-cpanel "tail -20 ~/public_html/manylla/qual/error_log"
```

### Rollback Procedure
Since deployment auto-commits to GitHub:

```bash
# 1. Find last good version
git log --oneline -10

# 2. Revert to previous version
git revert HEAD
git push

# 3. Run deployment again
./scripts/deploy-qual.sh
```

## Script Configuration

### Key Variables
- `MAX_TODO_COUNT=20` - Maximum TODOs allowed
- `MAX_CONSOLE_COUNT=5` - Maximum console.logs allowed
- `NODE_OPTIONS=--max-old-space-size=8192` - Build memory limit

### Directory Structure
```
/Users/adamstack/manylla/
├── scripts/
│   └── deploy-qual.sh         # Main deployment script
├── web/
│   └── build/                 # Build output (correct)
├── build/                     # Old static files (DO NOT USE)
├── public/
│   ├── .htaccess.manylla-qual # Manylla qual htaccess
│   └── .htaccess.qual         # StackMap qual htaccess
└── RELEASE_NOTES.md           # Release notes (root)
```

## Integration with CI/CD

Currently manual deployment only. Future considerations:
- GitHub Actions integration
- Automated testing before deployment
- Staging environment validation
- Automated rollback on failures

## Security Considerations

The deployment script includes:
- Hardcoded secret detection
- Critical vulnerability scanning
- Secure file permissions (chmod 600 for config files)
- No sensitive data in commits
- Audit trail in deployment logs

## Troubleshooting Checklist

When deployment fails:

- [ ] Check git status - all changes committed?
- [ ] Check release notes - entry for NEW version?
- [ ] Check lint errors - run `npm run lint`
- [ ] Check TypeScript - run `npm run typecheck`
- [ ] Check TODOs - under 20?
- [ ] Check console.logs - under 5?
- [ ] Check memory - increase NODE_OPTIONS if needed
- [ ] Check SSH access - `ssh stackmap-cpanel` works?
- [ ] Check disk space - server has room?
- [ ] Check network - can reach server?

## Contact for Issues

If deployment is blocked and cannot be resolved:
- Check deployment logs in terminal
- Review this documentation
- Check `~/public_html/manylla/qual/error_log` on server
- Request human review if validation requirements seem incorrect

---

*Last Updated: 2025-09-10*
*Version: 1.0*