# Role Session Startup Template

## Starting a New Role Session

Copy this template when starting a fresh role session. Provide the role with:

1. **Role Definition** (from `/docs/prompts/roles/[ROLE]-ROLE.md`)
2. **Role Learnings** (from `/docs/prompts/roles/[ROLE]_LEARNINGS.md`)  
3. **Active Prompt Pack** (from `/docs/prompts/active/`)
4. **Current Context** (any specific issues or status)

---

## Session Initialization Message Template

```markdown
You are assuming the [ROLE_NAME] role for the Manylla project.

## Your Role Definition
[Paste from /docs/prompts/roles/[ROLE]-ROLE.md]

## Accumulated Learnings
[Paste relevant sections from [ROLE]_LEARNINGS.md]

## Current Task
[Paste the active prompt pack]

## Additional Context
- Current deployment status: [status]
- Known issues: [list any]
- Priority focus: [what matters most]

Please proceed with the task following the role guidelines and applying the learnings from previous sessions.
```

---

## Example: Starting a Developer Session

```markdown
You are assuming the Developer role for the Manylla project.

## Your Role Definition
[Contents of DEVELOPER-ROLE.md]

## Key Learnings from Previous Sessions
- Build output is in web/build/ NOT build/
- Always validate with prettier before committing
- Import order matters for theme rendering
- Use Platform.select() not .native/.web files

## Current Task
[Contents of 01-critical-missing-demo-data.md]

## Additional Context
- Production deployment completed but has bugs
- Demo data not loading properly
- Need quick fix for user experience

Please fix the demo data initialization issue following our standards.
```

---

## Post-Session Actions

After role completes task:

1. **Review Output**
   - Validate all acceptance criteria met
   - Check compliance with standards
   - Run validation commands

2. **Update Learnings**
   - Add any new discoveries to [ROLE]_LEARNINGS.md
   - Document gotchas or patterns
   - Note useful commands or approaches

3. **Archive Prompt Pack**
   ```bash
   mv docs/prompts/active/[completed].md docs/prompts/archive/
   ```

4. **Report to PM**
   - Task completion status
   - Any blockers or issues
   - Recommendations for next steps

---

## Quick Reference: Role Files

| Role | Definition | Learnings |
|------|------------|-----------|
| PM | `/docs/prompts/roles/01-PM-ROLE.md` | `PM_LEARNINGS.md` |
| Developer | `/docs/prompts/roles/02-DEVELOPER-ROLE.md` | `DEVELOPER_LEARNINGS.md` |
| Peer Reviewer | `/docs/prompts/roles/03-PEER-REVIEWER-ROLE.md` | `PEER_REVIEWER_LEARNINGS.md` |
| Admin | `/docs/prompts/roles/04-ADMIN-ROLE.md` | `ADMIN_LEARNINGS.md` |

---

## Benefits of Fresh Context

1. **No Contamination** - Previous errors don't carry forward
2. **Focused Work** - Only relevant information present
3. **Lower Costs** - Smaller context window
4. **Clear Handoffs** - Explicit starting point
5. **Better Debugging** - Issues isolated to session