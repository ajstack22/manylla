# Role-Based Development Structure

## Overview
The Manylla project uses a role-based structure with four distinct roles to ensure clear responsibilities, quality control, and efficient workflow.

## Quick Role Assignment

When starting a new session, choose your role:

### I need to manage work and priorities
→ **Use PM Role**: `/docs/prompts/roles/01-PM-ROLE.md`
```
"I am taking the PM role for this session."
```

### I need to review code brutally
→ **Use Peer Reviewer Role**: `/docs/prompts/roles/02-PEER-REVIEWER-ROLE.md`
```
"I am taking the Peer Reviewer (Fury) role for this session."
```

### I need to implement code
→ **Use Developer Role**: `/docs/prompts/roles/03-DEVELOPER-ROLE.md`
```
"I am taking the Developer role for this session."
```

### I need help with the system
→ **Use Admin Role**: `/docs/prompts/roles/04-ADMIN-ROLE.md`
```
"I am taking the Admin role for this session."
```

## Role Summary

| Role | Primary Function | Key Responsibility | Cannot Do |
|------|-----------------|-------------------|-----------|
| **PM** | Workflow Management | Create/prioritize prompt packs | Write code directly |
| **Peer Reviewer** | Quality Control | Brutal adversarial reviews | Give partial credit |
| **Developer** | Implementation | Execute prompt packs exactly | Create TypeScript |
| **Admin** | System Support | Manage environment & servers | Modify business logic |

## Typical Workflow

```mermaid
graph LR
    User[User Request] --> PM[PM Creates Prompt Pack]
    PM --> Dev[Developer Implements]
    Dev --> PM2[PM Validates]
    PM2 --> PR[Peer Reviewer Reviews]
    PR -->|Pass| Admin[Admin Deploys]
    PR -->|Fail| Dev
```

## Communication Flow

### For New Features
1. User → **PM**: Request feature
2. **PM** → Creates prompt pack
3. **PM** → **Developer**: Assigns work
4. **Developer** → Implements
5. **Developer** → **PM**: Reports completion
6. **PM** → **Peer Reviewer**: Requests review
7. **Peer Reviewer** → **PM**: Provides verdict

### For System Issues
1. User → **Admin**: "Port 3000 not working"
2. **Admin** → Troubleshoots and fixes
3. **Admin** → **PM**: Reports if code issue found

### For Deployment
1. **PM** → **Admin**: "Ready to deploy"
2. **Admin** → Runs deployment
3. **Admin** → **PM**: Reports status

## Key Commands by Role

### PM Commands
```bash
./scripts/create-prompt-pack.sh [priority] [name]
ls docs/prompts/active/
mv docs/prompts/active/[done].md docs/prompts/archive/
```

### Peer Reviewer Commands
```bash
find src -name "*.tsx" -o -name "*.ts" | wc -l
npm run build:web
npx prettier --check 'src/**/*.js'
grep -r "@mui/material" src/ | wc -l
```

### Developer Commands
```bash
npm run web
npm run build:web
git add . && git commit -m "feat: [description]"
```

### Admin Commands
```bash
lsof -i :3000
npm run web
./scripts/deploy-qual.sh
pkill -f node
```

## Role Boundaries

### ✅ Good Role Usage
- PM creates clear prompt packs
- Developer follows them exactly
- Peer Reviewer rejects violations
- Admin keeps system running

### ❌ Bad Role Usage
- PM writing code
- Developer creating TypeScript
- Peer Reviewer giving partial passes
- Admin changing business logic

## When to Switch Roles

Generally, maintain one role per session. However, you may switch when:
- Task is complete
- Different expertise needed
- Explicit handoff required

Example:
```
"Completing PM role. Switching to Developer role to implement 01-critical prompt pack."
```

## Emergency Protocols

### Deployment Blocked
- **PM**: Create 01-critical prompt
- **Developer**: Fix immediately
- **Peer Reviewer**: Fast review
- **Admin**: Deploy ASAP

### System Down
- **Admin**: Restore service first
- **Admin**: Report to PM
- **PM**: Create prompt if code fix needed

### Major Bug in Production
- **User**: Report to PM
- **PM**: 01-critical prompt
- **Developer**: Emergency fix
- **Peer Reviewer**: Expedited review
- **Admin**: Hot deploy

## Role Documentation

Each role has a comprehensive guide:
1. `01-PM-ROLE.md` - Project management
2. `02-PEER-REVIEWER-ROLE.md` - Quality control (Fury mode)
3. `03-DEVELOPER-ROLE.md` - Code implementation
4. `04-ADMIN-ROLE.md` - System administration

Read your role's full documentation before starting work.

---

**Remember**: Clear roles = Clear responsibilities = Quality output