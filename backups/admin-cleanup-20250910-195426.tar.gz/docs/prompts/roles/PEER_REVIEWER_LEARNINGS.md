# Peer Reviewer (Fury) Role - Learnings & Best Practices

## Last Updated: 2025-09-10

### 🎯 Purpose
Capture institutional knowledge from Peer Reviewer sessions for maintaining code quality through adversarial review.

---

## 🆕 Recent Review Sessions

### 2025-09-10: Webpack Resource Copying Fix
**Review Type**: Minimal Change Review (1 line addition)
**Result**: PASS - Clean fix with no side effects

**Learning Points**:
1. **Build Output Verification**: Always verify files exist in correct build directory (`web/build/` not `build/`)
2. **Source-to-Build Mapping**: Check that webpack CopyPlugin patterns match HTML references
3. **Minimal Change Advantage**: Single-line fixes are easier to verify and less likely to introduce regressions
4. **noErrorOnMissing Flag**: Appropriate for optional resources like favicons
5. **Path References in HTML**: Note that index.html was updated to use relative paths (`./favicon.svg` instead of `/favicon.svg`) - this is important for subdirectory deployments like `/manylla/qual/`

**Effective Review Process**:
- Ran architecture compliance checks first (automated)
- Used `git diff HEAD~1` to see exact changes
- Verified source files exist before checking build output
- Confirmed HTML references match copied files
- Validated build succeeds with changes

**Post-Review Discovery**:
- HTML paths changed from absolute (`/favicon.svg`) to relative (`./favicon.svg`)
- This change is correct for non-root deployments
- Webpack's HtmlWebpackPlugin handles path resolution correctly with relative paths

---

## ✅ Successful Review Patterns

### Code Review Focus Areas
1. **Architecture Compliance**
   - No TypeScript syntax in .js files
   - No platform-specific files (.native.js, .web.js)
   - Proper use of Platform.select()
   - Consistent import ordering

2. **Security Checks**
   - No hardcoded credentials
   - No console.logs with sensitive data
   - Proper input validation
   - XSS prevention in rendered content

3. **Performance Concerns**
   - Unnecessary re-renders
   - Missing memoization
   - Large bundle imports
   - Blocking operations

4. **Edge Cases**
   - Null/undefined handling
   - Empty state management
   - Error boundaries
   - Network failure handling

---

## ⚠️ Common Issues Found

### TypeScript Remnants
- Interface declarations left in code
- Type annotations after colons
- Corrupted syntax (openoolean, stringring)
- Private/public/readonly keywords

### Material-UI Usage
- Direct imports from @mui/material
- Theme references to MUI palette
- Grid system instead of flexbox
- MUI icons instead of React Native

### Path Reference Issues
- Absolute paths in HTML (`/favicon.svg`) breaking subdirectory deployments
- Missing resources in webpack CopyPlugin configuration
- Mismatch between HTML references and build output locations
- Using root paths when app deployed to subdirectory like `/manylla/qual/`

### Async/Promise Issues
- Missing await keywords
- Unhandled promise rejections
- Race conditions in state updates
- Memory leaks from subscriptions

### State Management
- Direct state mutation
- Missing dependency arrays
- Stale closure problems
- Unnecessary state complexity

---

## 🔍 Review Checklist

### Pre-Review Verification
```bash
# Must pass before reviewing
find src -name "*.tsx" -o -name "*.ts" | wc -l  # Must be 0
grep -r "@mui/material" src/ | wc -l  # Should be decreasing
npm run build:web  # Must succeed
npx prettier --check 'src/**/*.js'  # Must pass
```

### Code Quality Checks
- [ ] No TypeScript syntax remains
- [ ] Import order follows standards
- [ ] Error handling in place
- [ ] Loading states handled
- [ ] Accessibility considered
- [ ] Theme properly integrated
- [ ] No hardcoded colors/dimensions
- [ ] Comments explain "why" not "what"

### Testing Scenarios
- [ ] Happy path works
- [ ] Error cases handled
- [ ] Empty states display correctly
- [ ] Large data sets perform well
- [ ] Network failures graceful
- [ ] Cross-platform compatibility

---

## 🎯 Adversarial Testing Strategies

### Input Validation
```javascript
// Try these inputs
null, undefined, "", " ", 0, -1, NaN, Infinity
[], {}, [null], {key: undefined}
Very long strings (>10000 chars)
Special characters: <script>, ', ", \, `
```

### State Manipulation
- Rapid clicking/tapping
- Navigation during loading
- Background/foreground app
- Rotate device mid-operation
- Network disconnect/reconnect

### Performance Testing
- Large lists (1000+ items)
- Rapid scrolling
- Multiple modals opening
- Theme switching under load
- Memory profiling

---

## 📝 Review Notes Examples

### Good Feedback
```markdown
**Issue**: Memory leak in useEffect
**Location**: src/components/Profile/ProfileCard.js:45
**Problem**: Subscription not cleaned up
**Fix**: Return cleanup function from useEffect
**Impact**: High - accumulates over time
```

### Poor Feedback
```markdown
"This code is bad"  ❌
"Doesn't follow best practices"  ❌
"Should be refactored"  ❌
```

---

## 🚀 Review Priorities

### Critical (Block Deployment)
- Security vulnerabilities
- Data loss possibilities  
- Breaking changes
- Crash conditions
- Infinite loops

### High (Fix Before Merge)
- Memory leaks
- Performance regressions
- Accessibility failures
- Missing error handling
- State corruption

### Medium (Track for Later)
- Code duplication
- Missing optimizations
- Inconsistent patterns
- Technical debt
- Test coverage gaps

### Low (Nice to Have)
- Formatting issues
- Variable naming
- Comment updates
- Refactoring opportunities

---

## 🔧 Useful Review Commands

### Find Problems
```bash
# TypeScript contamination
grep -r "interface \|: string\|: boolean\|: number" src/

# Console.logs
grep -r "console.log" src/ | grep -v "//"

# TODOs
grep -r "TODO\|FIXME\|HACK" src/

# Long lines
grep -r ".\{120,\}" src/

# Hardcoded values
grep -r "#[0-9A-Fa-f]\{6\}\|#[0-9A-Fa-f]\{3\}" src/

# Check for missing webpack copy targets
diff <(grep -h "href=\"/[^\"]*\"" public/index.html | sed 's/.*href="\///;s/".*//' | sort -u) \
     <(ls web/build/ 2>/dev/null | sort) | grep "^<"
```

### Performance Analysis
```bash
# Bundle size
npm run build:web && du -sh web/build

# Find large imports
grep -r "import.*from" src/ | grep -v "./"

# Circular dependencies
npx madge --circular src/
```

---

## 📊 Quality Metrics

### Track Over Time
- TypeScript files: 0 (must stay 0)
- Material-UI imports: Decreasing to 0
- Console.logs: < 5 in src/
- TODOs: < 20 total
- Bundle size: Monitor growth
- Build time: < 60 seconds

### Review Effectiveness
- Issues found per review
- Issues that reach production
- Time to review completion
- False positive rate
- Developer acceptance rate

---

## 🎨 Style Guide Enforcement

### JavaScript Patterns
```javascript
// ✅ Good
const Component = ({ prop1, prop2 }) => {
  const { theme } = useTheme();
  
// ❌ Bad  
interface Props { prop1: string }
const Component: React.FC<Props> = (props) => {
```

### Import Order
```javascript
// 1. React
import React, { useState } from 'react';

// 2. React Native
import { View, Text } from 'react-native';

// 3. Third-party
import AsyncStorage from '@react-native-async-storage/async-storage';

// 4. Contexts/Hooks
import { useTheme } from '../../context/ThemeContext';

// 5. Components
import ProfileCard from '../ProfileCard';
```

---

## 📚 Reference Documents
- `/docs/WORKING_AGREEMENTS.md` - Team standards
- `/CLAUDE.md` - Project instructions
- Best practices guides
- Security checklists