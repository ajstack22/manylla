# Active Prompt Packs

## Current Priorities

### 🔴 01-critical-runtime-errors-sync-share.md
**BLOCKING**: Users cannot access Sync or Share features
- Runtime errors due to incorrect theme property references
- Fix: Replace `.main` with correct theme properties
- Time: 15-20 minutes
- **ASSIGN IMMEDIATELY**

### 🟡 02-entryform-category-issues.md
**HIGH**: Core functionality issues
- Missing Quick Info category selector
- Remove unnecessary "Share With" component
- Time: 30-45 minutes

### 🟢 03-working-area-ui-improvements.md
**MEDIUM**: UX improvements
- Add label icons to category headers (replace vertical lines)
- Remove unnecessary "+" buttons from panel headers
- Time: 45-60 minutes

### 🟡 04-material-ui-cleanup.md
**HIGH**: Architecture consistency
- Remove 21 remaining Material-UI imports
- Convert to React Native components
- Time: 2-3 hours

### 🟢 05-modal-theme-consistency.md
**MEDIUM**: Visual polish
- Complete theme integration
- Add hover/focus states
- Ensure dark theme support
- Time: 2-3 hours

## Assignment Process

1. **Always start with lowest number** (highest priority)
2. **Complete one pack before starting next**
3. **Run adversarial review after each completion**
4. **Archive completed packs** when done

## Quick Status Check

```bash
# Check for TypeScript
find src -name "*.tsx" -o -name "*.ts" | wc -l  # Must be 0

# Check for platform files
find src -name "*.native.*" -o -name "*.web.*" | wc -l  # Must be 0

# Check for Material-UI
grep -r "@mui/material" src/ | wc -l  # Goal: 0

# Build check
NODE_OPTIONS=--max-old-space-size=4096 npm run build:web
```

## Notes

- Session 1 & 2 modal work is complete and archived
- Critical runtime errors must be fixed before deployment
- Material-UI cleanup is technical debt but not blocking