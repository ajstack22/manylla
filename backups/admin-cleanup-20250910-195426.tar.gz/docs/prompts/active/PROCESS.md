# Prompt Pack Process

## Creating New Prompt Packs

### Method 1: Using the Script (RECOMMENDED)
```bash
./scripts/create-prompt-pack.sh [priority] [name]

# Examples:
./scripts/create-prompt-pack.sh 01-critical fix-sync-error
./scripts/create-prompt-pack.sh 02-high improve-performance  
./scripts/create-prompt-pack.sh 03-medium add-animations
./scripts/create-prompt-pack.sh 04-low update-icons
```

This automatically:
- Creates properly named file in `/docs/prompts/active/`
- Includes all working agreement requirements
- Adds validation commands
- Includes documentation requirements
- Sets correct severity indicators

### Method 2: Manual from Template
Copy `/docs/prompts/PROMPT_TEMPLATE_GENERATOR.md` and fill in all sections.

## Priority Levels

| Priority | Indicator | Use For | Example |
|----------|-----------|---------|---------|
| 01-critical | 🔴 | Blocking issues | App crashes, deployment blocked |
| 02-high | 🟡 | Major functionality | Core features broken |
| 03-medium | 🟢 | UX improvements | Visual polish, enhancements |
| 04-low | 🔵 | Nice-to-have | Minor tweaks |

## Every Prompt Pack MUST Include

### 1. Architecture Validation
```bash
find src -name "*.tsx" -o -name "*.ts" | wc -l          # Must be 0
find src -name "*.native.*" -o -name "*.web.*" | wc -l  # Must be 0
```

### 2. Import Pattern
```javascript
// 1. React
// 2. React Native  
// 3. Third-party
// 4. Context/Hooks
// 5. Components
```

### 3. Documentation Requirements
- Which docs to update
- Release notes template
- Architecture updates if needed

### 4. Success Criteria
- Acceptance requirements
- Definition of done
- Testing checklist

## Workflow

1. **Create Prompt Pack**
   ```bash
   ./scripts/create-prompt-pack.sh 02-high fix-modal-bug
   ```

2. **Edit to Add Details**
   - Update all [UPDATE THIS] sections
   - Add specific code examples
   - Define clear test cases
   - **Assign to specific role** (Developer, Admin, Peer Reviewer)

3. **Assign to Role with Fresh Context**
   - Start new session for role
   - Provide prompt pack and role definition
   - Reference role's LEARNINGS.md for patterns
   - No need to carry forward previous context

4. **Review Completion**
   - Run adversarial review if critical
   - Check all validations pass
   - Verify docs updated
   - **Update role's LEARNINGS.md** with new insights

5. **Archive When Done**
   ```bash
   mv docs/prompts/active/[file].md docs/prompts/archive/
   ```

## Context Management Strategy

### Fresh Context Per Task
Each role starts with a clean slate for every prompt pack:
- **Benefits**: No accumulated errors, focused attention, lower token usage
- **Process**: New session → Role definition → Prompt pack → Execute

### Knowledge Preservation
Institutional knowledge is captured in LEARNINGS files:
```
/docs/prompts/roles/
├── PM_LEARNINGS.md           # PM discoveries and patterns
├── DEVELOPER_LEARNINGS.md    # Code patterns and gotchas
├── ADMIN_LEARNINGS.md        # Infrastructure knowledge
└── PEER_REVIEWER_LEARNINGS.md # Review focus areas
```

### Role Assignment Guidelines
| Task Type | Assign To | Key Context |
|-----------|-----------|-------------|
| Code changes | Developer | DEVELOPER_LEARNINGS.md |
| Script/deployment | Admin | ADMIN_LEARNINGS.md |
| Process/planning | PM | PM_LEARNINGS.md |
| Critical review | Peer Reviewer | PEER_REVIEWER_LEARNINGS.md |

### Starting a Role Session
1. Open new conversation/session
2. Provide role definition from `/docs/prompts/roles/`
3. Share relevant LEARNINGS.md
4. Provide specific prompt pack
5. Let role execute independently

## Documentation Requirements

### During Development (NOT AFTER)
- Update `/docs/RELEASE_NOTES.md`
- Update component JSDoc
- Update architecture docs if patterns change
- Update WORKING_AGREEMENTS if new standards

### Release Notes Format
```markdown
### 2025.09.10.1 - 2025-09-10

#### Fixed
- Fixed runtime errors in Sync/Share modals
- Resolved TypeScript syntax issues

#### Technical
- Updated SyncDialog.js, ShareDialogOptimized.js
- Removed 18 TypeScript remnants
```

## Common Mistakes to Avoid

1. **Creating TypeScript files** - Use .js only
2. **Platform-specific files** - Use Platform.select()
3. **Material-UI imports** - Use React Native
4. **Forgetting documentation** - Update as you work
5. **Skipping validation** - Run all checks before done
6. **Wrong build directory** - Use web/build/ not build/

## Quick Commands

```bash
# Create new prompt
./scripts/create-prompt-pack.sh 01-critical urgent-fix

# Check architecture compliance
find src -name "*.tsx" -o -name "*.ts" | wc -l
find src -name "*.native.*" -o -name "*.web.*" | wc -l

# Validate before deploy
npx prettier --check 'src/**/*.js'
npm run build:web

# Deploy
./scripts/deploy-qual.sh
```