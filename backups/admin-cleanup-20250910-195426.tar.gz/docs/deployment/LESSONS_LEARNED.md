# Deployment Lessons Learned
*Date: September 9, 2025*

## Critical Issues Discovered

### 1. Build Directory Confusion
**Problem**: The deployment script was deploying from `build/` which contained old static files from September 7, 2025. The actual webpack build output goes to `web/build/`.

**Root Cause**: Webpack configuration specifies:
```javascript
output: {
  path: path.resolve(__dirname, 'web/build'),
  // ...
}
```

**Solution**: Updated deployment script to use `web/build/` as the source directory.

**Prevention**: Always verify webpack output configuration matches deployment scripts.

### 2. Wrong .htaccess File
**Problem**: The deployment script was using `public/.htaccess.qual` which was configured for StackMap (with `/qual/` paths) instead of Manylla (which needs `/manylla/qual/` paths).

**Symptoms**: HTTP 403 Forbidden errors on https://manylla.com/qual/

**Solution**: Created `public/.htaccess.manylla-qual` with correct RewriteBase and paths.

**Prevention**: Each project should have its own clearly named .htaccess file.

### 3. Script Error Handling
**Problem**: The deployment script would exit early when grep commands returned no matches (exit code 1), even though this was not an error condition.

**Examples**:
- `grep -r "debugger" src/` returns 1 when no debuggers found
- `npx madge --circular src/` fails when madge isn't installed

**Solution**: Added `|| true` to commands where no matches is acceptable.

**Prevention**: Test scripts with both positive and negative cases.

## Script Improvements Made

### Fixed Commands
```bash
# Before (would exit on no matches)
DEBUGGER_COUNT=$(grep -r "debugger" src/ | wc -l)

# After (handles no matches gracefully)
DEBUGGER_COUNT=$(grep -r "debugger" src/ 2>/dev/null || true | wc -l)
```

### Path Corrections
```bash
# Before (wrong directory)
rsync -avz build/ stackmap-cpanel:~/public_html/manylla/qual/

# After (correct directory)
rsync -avz web/build/ stackmap-cpanel:~/public_html/manylla/qual/
```

### .htaccess Handling
```bash
# Before (wrong file)
scp public/.htaccess.qual stackmap-cpanel:~/public_html/manylla/qual/.htaccess

# After (correct file)
scp public/.htaccess.manylla-qual stackmap-cpanel:~/public_html/manylla/qual/.htaccess
```

## Key Takeaways

1. **Always verify build output paths** - Check where webpack/build tools actually output files
2. **Test deployment scripts thoroughly** - Include edge cases like "no matches found"
3. **Keep project-specific configs separate** - Don't reuse configs between projects
4. **Document critical paths** - Make it clear in documentation where files should be
5. **Add validation to scripts** - Check that expected directories/files exist before deploying
6. **Use descriptive file names** - `.htaccess.manylla-qual` is clearer than `.htaccess.qual`

## Debugging Checklist for Future Issues

When deployment fails:

1. **Check HTTP status**: Is it 403, 404, or 500?
2. **Verify files deployed**: SSH in and check if index.html exists
3. **Check .htaccess**: Verify RewriteBase and paths are correct
4. **Confirm build directory**: Check where webpack actually outputs files
5. **Test locally first**: Run the build and check the output directory
6. **Review script output**: Look for commands that exit early
7. **Check permissions**: Ensure files have correct permissions on server

## Recommended Script Enhancements

For future improvements to the deployment script:

1. **Add directory validation**:
```bash
if [ ! -d "web/build" ]; then
  echo "Error: web/build directory not found"
  exit 1
fi
```

2. **Verify critical files exist**:
```bash
if [ ! -f "web/build/index.html" ]; then
  echo "Error: index.html not found in build directory"
  exit 1
fi
```

3. **Add rollback functionality**:
```bash
# Backup current deployment before replacing
ssh stackmap-cpanel "cp -r ~/public_html/manylla/qual ~/public_html/manylla/qual.backup"
```

4. **Improve error messages**:
```bash
handle_error "Build failed" \
  "Check if 'web/build/' directory exists and contains index.html"
```

## Documentation Updates Made

1. Created `DEPLOYMENT_PROCESS_v3.md` with corrected paths
2. Created `CATEGORY_SYSTEM_v3.md` documenting the 6-category simplification
3. Updated `RELEASE_NOTES.md` with deployment fixes
4. Updated `CLAUDE.md` with critical warnings about build directory and .htaccess
5. Created this `LESSONS_LEARNED.md` for future reference

## Final Deployment Status

✅ Successfully deployed version 2025.09.09.3 to https://manylla.com/qual/
- 6 simplified categories working correctly
- All TypeScript errors resolved
- Demo data functioning properly
- Deployment script fixed for future use