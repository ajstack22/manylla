<?php
/**
 * Manylla API Configuration - LOCAL Development
 * 
 * This file is for local development only.
 * Copy and modify for your local setup.
 */

// Database Configuration - LOCAL
define('DB_HOST', 'localhost');
define('DB_NAME', 'manylla_sync_local'); // Local database
define('DB_USER', 'root'); // Local user (adjust as needed)
define('DB_PASS', ''); // Local password (adjust as needed)
define('DB_CHARSET', 'utf8mb4');

// API Configuration
define('API_VERSION', '1.0.0');
define('API_DEBUG', true); // Always debug in local
define('API_ENV', 'local'); // Environment identifier

// Rate Limiting (disabled for local)
define('RATE_LIMIT_REQUESTS', 9999); // Effectively unlimited
define('RATE_LIMIT_WINDOW', 60); // seconds

// Data Limits
define('MAX_BLOB_SIZE', 10 * 1024 * 1024); // 10MB for testing
define('MAX_DEVICE_NAME_LENGTH', 100);
define('SYNC_ID_LENGTH', 32);
define('DEVICE_ID_LENGTH', 32);

// Share Configuration
define('SHARE_CODE_LENGTH', 6);
define('DEFAULT_SHARE_EXPIRY_HOURS', 1); // Short expiry for testing
define('MAX_SHARE_EXPIRY_DAYS', 365);
define('SHARE_ACCESS_LOG_ENABLED', true);

// Cleanup Configuration
define('DATA_RETENTION_MONTHS', 1); // Short retention for testing
define('SHARE_CLEANUP_HOURS', 1); // Frequent cleanup for testing
define('CLEANUP_BATCH_SIZE', 100);

// Security Headers (relaxed for local)
define('SECURITY_HEADERS', [
    'X-Content-Type-Options' => 'nosniff'
]);

// CORS Configuration - LOCAL (allow all for development)
define('CORS_ALLOWED_ORIGINS', [
    'http://localhost:3000',
    'http://localhost:3001',
    'http://localhost:8080',
    'http://127.0.0.1:3000',
    'http://127.0.0.1:3001',
    'http://127.0.0.1:8080'
]);

// Error Messages
define('ERROR_MESSAGES', [
    'INVALID_REQUEST' => 'Invalid request format',
    'INVALID_SYNC_ID' => 'Invalid sync ID format',
    'INVALID_DEVICE_ID' => 'Invalid device ID format',
    'INVALID_BLOB' => 'Invalid encrypted data format',
    'SYNC_NOT_FOUND' => 'Sync group not found',
    'SYNC_EXISTS' => 'Sync group already exists',
    'RATE_LIMIT' => 'Too many requests. Please try again later.',
    'PAYLOAD_TOO_LARGE' => 'Encrypted data exceeds size limit',
    'DATABASE_ERROR' => 'Database operation failed',
    'SERVER_ERROR' => 'Internal server error',
    'INVALID_ACCESS_CODE' => 'Invalid or expired access code',
    'SHARE_NOT_FOUND' => 'Shared profile not found',
    'SHARE_EXPIRED' => 'This share has expired',
    'SHARE_VIEW_LIMIT' => 'Maximum views reached for this share',
    'INVALID_SHARE_DATA' => 'Invalid share data format'
]);

// Share Messages
define('SHARE_MESSAGES', [
    'SHARE_CREATED' => 'Share link created successfully',
    'SHARE_ACCESSED' => 'Share accessed successfully',
    'SHARE_DELETED' => 'Share deleted successfully'
]);

// Timezone
date_default_timezone_set('America/New_York'); // Adjust to your local timezone

// Error reporting - full for development
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/local_error.log');
?>