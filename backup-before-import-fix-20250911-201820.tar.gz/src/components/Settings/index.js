// Export web versions for web build
// Metro will handle .native resolution for mobile
export { UnifiedCategoryManager } from "./UnifiedCategoryManager";
export { CategoryManager } from "./CategoryManager";
export { QuickInfoManager } from "./QuickInfoManager";
