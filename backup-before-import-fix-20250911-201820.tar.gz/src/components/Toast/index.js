// Export web version for web build
// Metro will handle .native resolution for mobile
export { ThemedToast } from "./ThemedToast";
