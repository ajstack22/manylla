// Export web version for web build
// Metro will handle .native resolution for mobile
export { SyncDialog } from "./SyncDialog";
